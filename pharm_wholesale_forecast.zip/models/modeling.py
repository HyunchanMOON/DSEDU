import pandas as pd
import matplotlib.pyplot as plt
from xgboost import XGBRegressor
from lightgbm import LGBMRegressor
from sklearn.svm import SVR
from sklearn.ensemble import RandomForestRegressor
from sklearn.multioutput import MultiOutputRegressor
from nn_package.nn_model import *
from nn_package.nn_setup import *


def set_xgb(params=None):
    xgb_model = XGBRegressor(**params) if params is not None else XGBRegressor()  # parameter 수정 된 파라미터가 있을 시 해당 parameter 적용, 아니면 그냥 기본 모델 적용
    return xgb_model

def set_rf(params=None):
    rf_model = RandomForestRegressor(**params) if params is not None else RandomForestRegressor()  # parameter 수정 된 파라미터가 있을 시 해당 parameter 적용, 아니면 그냥 기본 모델 적용
    return rf_model

def set_svr(params=None):
    svr_model = SVR(**params) if params is not None else SVR()  # parameter 수정 된 파라미터가 있을 시 해당 parameter 적용, 아니면 그냥 기본 모델 적용
    return svr_model

def set_lgb(params=None):
    lgb_model = LGBMRegressor(**params) if params is not None else LGBMRegressor()
    return lgb_model

def set_cnn(params=None):
    pass

def set_lstm(train_test_dict, DEVICE):
    train_model = LSTM(input_size=train_test_dict['train_x'].shape[1], hidden_dim=8, n_out=1, layers=1).to(DEVICE)
    return train_model


class Execute_nn():
    def __init__(self, args):
        USE_CUDA = torch.cuda.is_available()
        self.args = args
        self.DEVICE = torch.device("cuda" if USE_CUDA else "cpu")

        self.mode = args.mode
        self.result_plot = args.result_plot
        self.param_tune = args.param_tune

    def parallel_runner(self, p, data_dict):

        out = p.map(self.run_nn, [(k, v) for k, v in data_dict.items()])
        pass

    def run_nn(self, parallel_input):

        label = parallel_input[0]
        dd = parallel_input[1]
        hidden_dim = 4
        output_dim = 1
        learning_rate = 1e-1

        ls_dict = {'learning_rate': learning_rate, 'EPOCHS': 30, 'BATCH_SIZE': 10, 'patience': 5,
                   'hidden_dim': hidden_dim}
        nn_models = {'cnn': set_cnn, 'lstm': set_lstm}

        self.model = nn_models[self.args.nn_model](dd, self.DEVICE)

        net_learning = Model_Learner(DEVICE=self.DEVICE, type='lstm')
        wc_lstm_best = net_learning.nn_learning(nn_model=self.model,ls_dict=ls_dict,data_dict=dd)

        if self.mode== 'test':
            hn, cn = self.model.hn, self.model.cn
            predictions = list()

            for i in range(len(dd['test_x'])):
                X, y = dd['test_x'][i, :], dd['test_y'][i]
                X = X.reshape(1, 1, len(X))
                hypothesis, (hn, cn) = wc_lstm_best(torch.tensor(X, dtype=torch.float32), hn, cn)
                yhat = hypothesis.detach().numpy()[0, 0]
                yhat = self.invert_scale(scaler=dd['scaler'], X=X, value=yhat)
                yhat = self.inverse_difference(dd['rawvalues'], yhat, len(dd['test_x']) + 1 - i)
                predictions.append(yhat)

            y_pred = predictions
            y_true = dd['rawvalues'][dd['train_size']:dd['len_supervised']]
            plt.plot(y_pred, 'r', label='y_pred')
            plt.plot(y_true, 'b', label='y_true')
            plt.title(label+f' , rmse : {np.round(np.sqrt(np.mean(np.square(y_pred-y_true))), 3)}')
            plt.legend(loc='best')
            plt.show()

            return None

        elif self.mode == 'inference':

            hn, cn = self.model.hn, self.model.cn
            predictions = list()
            pred_month = dd['pred_month']
            hn_list, cn_list = [], []

            for i in range(len(dd['test_x'])):
                X, y = dd['test_x'][i, :], dd['test_y'][i]
                X = X.reshape(1, 1, len(X))
                hypothesis, (hn, cn) = wc_lstm_best(torch.tensor(X, dtype=torch.float32), hn, cn)
                hn_list.append(hn)
                cn_list.append(cn)
                yhat = hypothesis.detach().numpy()[0, 0]
                yhat = self.invert_scale(scaler=dd['scaler'], X=X, value=yhat)
                yhat = self.inverse_difference(dd['rawvalues'], yhat, len(dd['test_x']) + 1 - i)
                predictions.append(yhat)

            y_pred = predictions
            initial = dd['test_x'][-1, :]
            
            hn, cn = hn_list[-2], cn_list[-2]
            # hn, cn = self.model.hn, self.model.cn

            prediction = []
            for i in range(pred_month):
                initial = initial.reshape(1, 1, len(initial))
                hypothesis, (hn, cn) = wc_lstm_best(torch.tensor(initial, dtype=torch.float32), hn, cn)
                yhat = hypothesis.detach().numpy()[0, 0]
                yhat = self.invert_scale(scaler=dd['scaler'], X=initial, value=yhat)
                if i == 0:
                    yhat_diff = yhat + dd['rawvalues'][-1]
                else:
                    yhat_diff = yhat + prediction[i - 1]
                prediction.append(yhat_diff)
                initial = np.array([yhat])

            y_true = dd['rawvalues'][dd['train_size']:dd['len_supervised']]

            test_range = list(range(len(y_true) + pred_month))
            plt.plot(test_range[:-pred_month], y_pred, 'r.', label='y_pred')
            plt.plot(test_range[:-pred_month], y_true, 'b.', label='y_true')
            plt.plot(test_range[-pred_month:], prediction, 'k.', label='y_forecast')
            plt.title(label+f' , rmse : {np.round(np.sqrt(np.mean(np.square(y_pred-y_true))), 3)}')
            plt.legend(loc='best')
            plt.show()


    def invert_scale(self, scaler, X, value):
        new_row = [x for x in X] + [value]  # push_back
        array = np.array(new_row)
        array = array.reshape(1, len(array))  # convert to 2d
        inverted = scaler.inverse_transform(array)
        return inverted[0, -1]

    def inverse_difference(self, history, yhat, interval=1):
        return yhat + history[-interval]


class Execute_ml():
    def __init__(self, args):

        ml_models = {'xgbm': set_xgb, 'lgbm': set_lgb, 'rdf': set_rf, 'svm': set_svr}

        self.model = ml_models[args.ml_model]
        self.mode = args.mode
        self.result_plot = args.result_plot
        self.param_tune = args.param_tune

    def parallel_runner(self, p, data_dict):
        out = p.map(self.run_ml, [(k, v) for k, v in data_dict.items()])

        if out[0] is not None:
            out_df = pd.DataFrame()
            for o in out:
                out_df = pd.concat([out_df, o])

            out_df['year'] = out_df['year'].round(0).astype(int)
            out_df['month'] = out_df['month'].round(0).astype(int)

            out_df['Date'] = out_df['year'].astype(str).str.cat(out_df['month'].astype(str), sep='-')
            out_df['Date'] = pd.to_datetime(out_df['Date'],format='%Y-%m')

            out_df.drop(['class','year','month'],axis=1, inplace=True)
            out_df = out_df[['Date', 'Code', 'Rx']]
            out_df.sort_values(['Date'], inplace=True)
            out_df.reset_index(drop=True, inplace=True)

            out_df['Date'] = out_df['Date'].dt.strftime('%Y-%m')

            out_df.to_csv('sales_prediction.csv',index=False)

    def set_new_value(self, data_in, column, rowsize, y_value, norm_param):
        new_test = pd.DataFrame(data_in.reshape(-1, len(column))[-rowsize:], columns=column)
        y_value = y_value*norm_param.loc['Rx', 'std'] + norm_param.loc['Rx', 'mean']
        new_test = new_test*norm_param['std'] + norm_param['mean']
        new_value = list(new_test.iloc[-1, :].values)
        new_value[-1], new_value[1] = new_value[-1] + 1, y_value
        new_test.loc[len(new_test)] = new_value
        new_test = new_test.iloc[1:, :]

        return new_test


    def run_ml(self, parallel_input):
        try:
            label = parallel_input[0]
            dd = parallel_input[1]

            train_x, train_y = dd['train']
            test_x, test_y = dd['test']
            winsize = dd['winsize']
            col = dd['columns']

            pred_month = dd['pred_month']
            norm = dd['norm_param']

            model_xgb = MultiOutputRegressor(self.model()).fit(train_x, train_y)

            if self.mode== 'test':
                y_pred = model_xgb.predict(test_x)
                plt.plot(y_pred, 'r', label='y_pred')
                plt.plot(test_y, 'b', label='y_true')
                plt.title(label+f' , rmse : {np.round(np.sqrt(np.mean(np.square(y_pred-test_y))), 3)}')
                plt.legend(loc='best')
                plt.show()
                return None

            elif self.mode=='inference':

                new_test = self.set_new_value(data_in=test_x, column=col, rowsize=winsize, y_value=test_y[-1][0], norm_param=norm) # 초기값 setting
                output = []

                for m in range(pred_month):
                    tmp_code = new_test['Code'].values
                    tmp_class = new_test['class'].values
                    new_test = (new_test-norm['mean']) / norm['std']
                    new_test['Code'] = tmp_code
                    new_test['class'] = tmp_class

                    new_input = new_test.values.reshape(-1, winsize * len(col))
                    y_pred = model_xgb.predict(new_input)

                    new_test = self.set_new_value(data_in=new_input, column=col, rowsize=winsize, y_value=y_pred[0][0], norm_param=norm)
                    output.append(new_test.iloc[-1, :].values)

                output_df = pd.DataFrame(np.asarray(output),columns=col)

                if self.result_plot:
                    middle = len(dd['test_org'])
                    all_range = list(range(middle + output_df.shape[0]))
                    plt.plot(all_range[:middle], dd['test_org'], 'r')
                    plt.plot(all_range[middle:], output_df.Rx, 'b')
                    plt.suptitle(f'{label}')
                    plt.show()

                output_df['Code'] = label
                return output_df
        except Exception as e:
            print('grid cv :',e)

