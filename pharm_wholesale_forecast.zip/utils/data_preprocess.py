import pandas as pd
import numpy as np
from sklearn.preprocessing import MinMaxScaler

class Preprocessing:

    def __init__(self, config_info):
        self.config_info = config_info

    def run_preprocess(self):

        self.sheet_dict = {'sales': self.run_sales_pp,
                           'inventory': self.run_stock_pp,
                           'UBIST': self.run_ubist_pp}

        self.dir = self.config_info['data_dir']
        self.sht_names = self.config_info['sheet_name']
        self.windowsize = self.config_info['sequence_params']['windowsize']
        self.stepsize = self.config_info['sequence_params']['stepsize']
        self.train_size = self.config_info['sequence_params']['train_size']
        self.pred_month = self.config_info['sequence_params']['pred_month']
        self.sales_df = None
        self.stock_df = None
        self.ubist = None
        self.division = {vv.upper(): k for k, v in self.config_info['division'].items() for vv in v}

        if self.config_info['data_dir'].endswith('.xlsx'): [self.sheet_dict[k](sht_name=v) for k,v in self.sht_names.items()]
        elif self.config_info['data_dir'].endswith('.csv'): self.run_sales_pp_csv()

        return_dict = {}

        if self.sales_df is not None:
            return_dict['type1'] = self.sales_df
            if self.stock_df is not None:
                tmp = pd.merge(left=self.sales_df, right=self.stock_df, how='inner', on=['Date', 'Code', 'class'])
                return_dict['type2'] = tmp
                if self.ubist is not None:
                    tmp2 = pd.merge(left=tmp, right=self.ubist, how='inner', on=['Date','class'])
                    return_dict['type3'] = tmp2

        return return_dict

    def run_sales_pp_csv(self):
        col = ['Date', 'Code', 'Rx']
        try:
            self.sales_df = pd.read_csv(self.dir, index_col=0)
            self.sales_df['saledate'] = pd.to_datetime(self.sales_df['saledate'])
            self.sales_df = self.sales_df.groupby(['saledate', 'itemcd']).sum()
            self.sales_df = self.sales_df.reset_index(drop=False)
            self.sales_df.columns = col

            self.sales_df['Code'] = self.sales_df['Code'].str.upper()

            class_code = [int(self.division[v]) if v in self.division.keys() else 0 for v in self.sales_df.Code.values]
            self.sales_df['class'] = class_code

        except Exception as e:
            print('run sales preprocessing csv ',e)
            self.sales_df = None


    def run_sales_pp(self, sht_name):
        col = ['Date', 'Code', 'Rx']
        try:
            self.sales_df = pd.read_excel(self.dir, sheet_name=sht_name)
            self.sales_df = self.sales_df.iloc[:-1, :]
            self.sales_df.columns = col

            self.sales_df['Date'] = pd.to_numeric(self.sales_df['Date'])
            self.sales_df['Date'] = pd.to_datetime(self.sales_df['Date'], format='%Y%m')

            self.sales_df['Code'] = self.sales_df['Code'].str.upper()
            class_code = [int(self.division[v]) if v in self.division.keys() else 0 for v in self.sales_df.Code.values]
            self.sales_df['class'] = class_code

        except Exception as e:
            print('run sales preprocessing ',e)
            self.sales_df = None

    def run_stock_pp(self, sht_name):
        col = ['Date', 'Code', 'Stock']
        try:
            self.stock_df = pd.read_excel(self.dir, sheet_name=sht_name)
            self.stock_df = self.stock_df.iloc[:-1, :]
            self.stock_df.columns = col
            self.stock_df['Date'] = pd.to_numeric(self.stock_df['Date'])
            self.stock_df['Date'] = pd.to_datetime(self.stock_df['Date'], format='%Y%m')
            self.stock_df['Code'] = self.stock_df['Code'].str.upper()
            class_code = [int(self.division[v]) if v in self.division.keys() else 0 for v in self.stock_df.Code.values]
            self.stock_df['class'] = class_code

        except Exception as e:
            print('run stock preprocessing ', e)
            self.stock_df = None

    def run_ubist_pp(self, sht_name):
        col = ['Date', 'ubist_Code', 'ubist_Rx']
        try:

            self.ubist = pd.read_excel(self.dir, sheet_name=sht_name)
            self.ubist = self.ubist.iloc[:-1, :]
            self.ubist.columns = col
            self.ubist['Date'] = self.ubist['Date'].str.replace("년", '')
            self.ubist['Date'] = self.ubist['Date'].str.replace("월", '')
            self.ubist['Date'] = self.ubist['Date'].str.replace(" ", '')
            self.ubist['Date'] = pd.to_numeric(self.ubist['Date'])
            self.ubist['Date'] = pd.to_datetime(self.ubist['Date'], format='%Y%m')

            self.ubist['ubist_Code'] = self.ubist['ubist_Code'].str.upper()
            class_code = [int(self.division[v]) if v in self.division.keys() else 0 for v in self.ubist.ubist_Code.values]
            self.ubist['class'] = class_code
            self.ubist.sort_values(['Date'], inplace=True)
            self.ubist.reset_index(drop=True, inplace=True)

        except Exception as e:
            print('run ubist preprocessing ', e)
            self.ubist = None


class Input_preprocessor(Preprocessing):

    def __init__(self, config_info, df_type='type1'):
        super().__init__(config_info=config_info)
        self.data_dict = self.run_preprocess()
        self.df_type = df_type
        self.model_type = {'ml': self.set_ml_dataset, 'nn': self.set_nn_dataset}

    def get_sales_data(self, df_type='type1', model_type='nn'):
        '''
            df_type : 모델링을 위한 data frame type을 설정함.
            ex) type1 : 판매데이터만 포함
                type2 : 판매데이터 + 재고데이터
                type3 : 판매데이터 + 재고데이터 + 경쟁사 판매데이터
        '''
        df = self.data_dict[df_type]

        if df_type == 'type1':
            Product_dict = {}

            for i, p in enumerate(df['Code'].unique()): Product_dict[p] = i
            self.Reverse_product = {v: k for k, v in Product_dict.items()}
            emmbedding_product = [Product_dict[v] for v in df.Code]
            df['Code'] = emmbedding_product
            df['year'] = df['Date'].dt.year
            df['month'] = df['Date'].dt.month

            self.cores = len(df.Code.unique())
            self.data_dict = {}

            self.model_type[model_type](input_df=df)

    def set_nn_dataset(self, input_df):

        for c in input_df.Code.unique():
            self.data_dict[self.Reverse_product[c]] = {}

            tmp_df = input_df[input_df['Code'] == c].set_index('Date')
            tmp_df = tmp_df['Rx']
            raw_values = tmp_df.values

            diff_values = self.difference(raw_values, 1)

            supervised = self.timeseries_to_supervised(diff_values, 1)
            supervised_values = supervised.values

            train_size = int(len(supervised_values) * self.train_size)
            train = supervised_values[0:train_size]
            test = supervised_values[train_size:]

            scaler, train_scaled, test_scaled = self.scale(train, test)

            self.data_dict[self.Reverse_product[c]]['train_x'], self.data_dict[self.Reverse_product[c]]['train_y'] = train_scaled[:, 0:-1], train_scaled[:, -1]
            self.data_dict[self.Reverse_product[c]]['test_x'], self.data_dict[self.Reverse_product[c]]['test_y'] = test_scaled[:, 0:-1], test_scaled[:, -1]

            self.data_dict[self.Reverse_product[c]]['rawvalues'] = raw_values
            self.data_dict[self.Reverse_product[c]]['train_size'] = train_size
            self.data_dict[self.Reverse_product[c]]['len_supervised'] = len(supervised_values)
            self.data_dict[self.Reverse_product[c]]['pred_month'] = self.pred_month
            self.data_dict[self.Reverse_product[c]]['scaler'] = scaler


    def set_ml_dataset(self, input_df):

        for c in input_df.Code.unique():
            self.data_dict[self.Reverse_product[c]] = {}

            tmp_df = input_df[input_df['Code'] == c].set_index('Date')

            train_tmp = tmp_df.iloc[:int(tmp_df.shape[0] * self.train_size), :]
            train_des = train_tmp.describe().transpose()
            norm_train = (train_tmp - train_des['mean']) / train_des['std']
            norm_train['Code'] = c
            norm_train['class'] = train_tmp['class'].values
            test_tmp = tmp_df.iloc[int(tmp_df.shape[0] * self.train_size):, :]
            norm_test = (test_tmp - train_des['mean']) / train_des['std']
            norm_test['Code'] = c
            norm_test['class'] = test_tmp['class'].values

            idx_train = self.get_indices_entire_sequence(data=norm_train, window_size=self.windowsize,
                                                         step_size=self.stepsize)
            train_x, train_y = self.get_xgboost_x_y(indices=idx_train, data=norm_train.values, target_sequence_length=1,
                                                    input_seq_len=self.windowsize)
            idx_test = self.get_indices_entire_sequence(data=norm_test, window_size=self.windowsize,
                                                        step_size=self.stepsize)
            test_x, test_y = self.get_xgboost_x_y(indices=idx_test, data=norm_test.values, target_sequence_length=1,
                                                  input_seq_len=self.windowsize)

            self.data_dict[self.Reverse_product[c]]['train'] = (train_x, train_y)
            self.data_dict[self.Reverse_product[c]]['test'] = (test_x, test_y)
            self.data_dict[self.Reverse_product[c]]['test_org'] = test_tmp.Rx.values

            self.data_dict[self.Reverse_product[c]]['columns'] = tmp_df.columns
            self.data_dict[self.Reverse_product[c]]['winsize'] = self.windowsize
            self.data_dict[self.Reverse_product[c]]['pred_month'] = self.pred_month
            self.data_dict[self.Reverse_product[c]]['norm_param'] = train_des


    ## 시계열 data machine learing model input 생성을 위한 함수
    # window size 는 총 학습할 기간에 해당하며, step size는 다음 sequence의 시작 step을 의미한다.
    # 즉 window size 가 10 이라면 10일 치의 과거 데이터가 indexing 되며(0~9), step size가 1 이라면, (1~10), (2~11) 이런식으로 시작 step이 설정된다.

    def get_indices_entire_sequence(self, data: pd.DataFrame, window_size: int, step_size: int) -> list:
        """
        Produce all the start and end index positions that is needed to produce
        the sub-sequences.
        Returns a list of tuples. Each tuple is (start_idx, end_idx) of a sub-
        sequence. These tuples should be used to slice the dataset into sub-
        sequences. These sub-sequences should then be passed into a function
        that slices them into input and target sequences.

        Args:
            data (pd.DataFrame): Partitioned data set, e.g. training data

            window_size (int): The desired length of each sub-sequence. Should be
                               (input_sequence_length + target_sequence_length)
                               E.g. if you want the model to consider the past 100
                               time steps in order to predict the future 50
                               time steps, window_size = 100+50 = 150
            step_size (int): Size of each step as the data sequence is traversed
                             by the moving window.
                             If 1, the first sub-sequence will be [0:window_size],
                             and the next will be [1:window_size].
        Return:
            indices: a list of tuples
        """

        stop_position = len(data) - 1  # 1- because of 0 indexing

        # Start the first sub-sequence at index position 0
        subseq_first_idx = 0

        subseq_last_idx = window_size

        indices = []

        while subseq_last_idx <= stop_position:
            indices.append((subseq_first_idx, subseq_last_idx))

            subseq_first_idx += step_size

            subseq_last_idx += step_size

        return indices

    ## 위 함수에서 생성된 index에 따라 데이터를 추출하는 함수
    # data 는 위에서 전처리된 numpy 형태의 data input이며,
    # target_seqeunce_length 는 예측할 수치의 수이다. ex) 1 일 경우 1일치에 대한 예측, 10 일 경우 10일치에 대한 예측
    # input_seq_len 은 학습 데이터의 기간이다. 이는 위에서 설정한 window size와 동일해야한다.

    def get_xgboost_x_y(self,indices: list, data: np.array, target_sequence_length, input_seq_len: int):

        """
        Args:
            indices: List of index positions at which data should be sliced
            data: A univariate time series
            target_sequence_length: The forecasting horizon, m
            input_seq_len: The length of the model input, n
        Output:
            all_x: np.array of shape (number of instances, input seq len)
            all_y: np.array of shape (number of instances, target seq len)
        """
        all_x, all_y = 0, 0
        # Loop over list of training indices
        for i, idx in enumerate(indices):
            # Slice data into instance of length input length + target length
            x = data[idx[0]:idx[1], :]
            assert len(x) == input_seq_len

            y = data[idx[1] + target_sequence_length - 1, 1]

            # Create all_y and all_x objects in first loop iteration
            if i == 0:
                all_y = y.reshape(1, -1)
                all_x = x.reshape(1, -1)
            else:
                all_y = np.concatenate((all_y, y.reshape(1, -1)), axis=0)
                all_x = np.concatenate((all_x, x.reshape(1, -1)), axis=0)

        return all_x, all_y

    def difference(self, dataset, interval=1):
        diff = list()
        for i in range(interval, len(dataset)):
            value = dataset[i] - dataset[i - interval]
            diff.append(value)
        return pd.Series(diff)

    def timeseries_to_supervised(self,data, lag=1):
        df = pd.DataFrame(data)
        columns = [df.shift(i) for i in range(1, lag + 1)]
        columns.append(df)
        df = pd.concat(columns, axis=1)
        df.fillna(0, inplace=True)
        return df

    def scale(self,train, test):
        # fit scaler
        scaler = MinMaxScaler(feature_range=(-1, 1))
        scaler = scaler.fit(train)
        # transform train
        train_scaled = scaler.transform(train)
        # transform test
        test_scaled = scaler.transform(test)
        return scaler, train_scaled, test_scaled

