import numpy as np
import dtw
from sklearn.cluster import AgglomerativeClustering
from scipy.spatial.distance import pdist, squareform
import matplotlib.pyplot as plt

import pandas as pd






class cal_self_dist:
    def __init__(self, magnet_v, magnet_dict):
        self.magnet_v = magnet_v
        self.magnet_dict = magnet_dict

    def run_modules(self, data_name, index):
        l1_array = self.cal_self_norm(order=1)
        l2_array = self.cal_self_norm(order=2)
        dtw_array = self.cal_self_dtw()
        raw_dict = {f'{data_name}_magnet_{index}': self.magnet_v}
        self.magnet_dict['dd']['magnet_raw'].append(raw_dict)
        self.magnet_dict[f'{data_name}_self_L1_{index}'] = l1_array
        self.magnet_dict[f'{data_name}_self_L2_{index}'] = l2_array
        self.magnet_dict[f'{data_name}_self_dtw_{index}'] = dtw_array
        return self.magnet_dict

    def cal_self_norm(self, order):
        norm_list = []
        for m in self.magnet_v:
            for n in self.magnet_v:
                norm_list.append(np.linalg.norm((m - n), ord=order))
        return np.asarray(norm_list).reshape(3,-1)

    def cal_self_dtw(self):
        dtw_list = []
        for m in self.magnet_v:
            for n in self.magnet_v:
                dist_n = dtw.dtw(m, n, keep_internals=True).distance
                dtw_list.append(dist_n)
        return np.asarray(dtw_list).reshape(3,-1)



class cal_magnets_distance:
    def __init__(self, magnet_df, run_type=None):
        if run_type is None: run_type = ['l1', 'l2', 'dtw']

        self.magnet_df = magnet_df
        self.run_type = run_type
        self.xyz = {'x':0, 'y':1, 'z':2}

    def run_dtw(self):
        result_df = pd.DataFrame()
        for k, ax in self.xyz.items():
            magnet_ax = self.magnet_df.iloc[:, ax::3]
            print(magnet_ax.columns)
            dtw_result = self.cal_dtw(magnet_axis=magnet_ax.values.T)
            dtw_df = pd.DataFrame(dtw_result, columns=magnet_ax.columns, index=magnet_ax.columns)
            result_df = pd.concat([result_df,dtw_df],axis=0)

            print(dtw_df)
            print(dtw_df.shape)
        return result_df

    def run_modules(self):
        result_df = pd.DataFrame()
        for k, ax in self.xyz.items():
            magnet_ax = self.magnet_df.iloc[:, ax::3]
            data_name = magnet_ax.columns

            l1_result = self.cal_norm(magnet_axis=magnet_ax.values.T, order=1)
            l2_result = self.cal_norm(magnet_axis=magnet_ax.values.T, order=2)
            dtw_result = self.cal_dtw(magnet_axis=magnet_ax.values.T)
            self.clustering(magnet_axis=magnet_ax.values.T, labels=magnet_ax.columns)
            l1_df = pd.DataFrame(l1_result, columns='l1_'+data_name, index=data_name)
            l2_df = pd.DataFrame(l2_result, columns='l2_'+data_name, index=data_name)
            dtw_df = pd.DataFrame(dtw_result, columns='dtw_'+data_name, index=data_name)
            result_df = pd.concat([result_df,pd.concat([l1_df,l2_df,dtw_df],axis=1)],axis=0)

        return result_df

    def cal_norm(self, magnet_axis, order):
        norm_list = []
        for m in magnet_axis:
            for n in magnet_axis:
                norm_list.append(np.linalg.norm((m - n), ord=order))

        return np.asarray(norm_list).reshape(magnet_axis.shape[0],-1)

    def cal_dtw(self, magnet_axis):
        dtw_list = []

        for m in magnet_axis:
            for n in magnet_axis:
                dist_n = dtw.dtw(m, n, keep_internals=True).distance
                dtw_list.append(dist_n)
        return np.asarray(dtw_list).reshape(magnet_axis.shape[0],-1)

    def clustering(self, magnet_axis, labels):

        clustering = AgglomerativeClustering(compute_distances=True).fit(magnet_axis)
        dist_mat = squareform(pdist(magnet_axis))
        print(dist_mat)

        plt.figure()
        plt.pcolormesh(dist_mat)
        for y in range(dist_mat.shape[0]):
            for x in range(dist_mat.shape[1]):
                plt.text(x + 0.5, y + 0.5, '%.4f' % dist_mat[y, x],
                         horizontalalignment='center',
                         verticalalignment='center',
                         )

        plt.xlabel(list(labels))
        plt.ylabel(list(labels))
        plt.colorbar()
