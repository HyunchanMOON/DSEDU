clc;
clear;
close all;

% 1. 100mm x 100mm 그리드 생성
gridSize = 100;
grid = zeros(gridSize, gridSize);

% 2. WEG 변수 생성
wegValues = zeros(10000, 10);
for i = 1:10000
    rangeStart = 0.2 + (0.4-0.1)*rand(); % 랜덤 시작점
    wegValues(i, :) = rangeStart + 0.1*rand(1, 10);
end

% 3. 평균 계산
avgWEG = mean(wegValues, 2);

% 4. Defect 변수 계산
% WEG 평균값이 0.2일 때 Defect가 0, WEG 평균값이 0.6일 때 Defect가 1이 되도록 선형 변환 적용
defectValues = (avgWEG - 0.2) / 0.4;

% Defect 값의 범위를 0과 1 사이로 제한
defectValues(defectValues < 0) = 0;
defectValues(defectValues > 1) = 1;

% 5. 그리드 색 채우기
for i = 1:gridSize
    for j = 1:gridSize
        % Defect 값에 따라 색상 결정 (예: 진하기 조절)
        grid(i, j) = defectValues((i-1)*gridSize + j);
    end
end



% 1. 100mm x 100mm 그리드 생성
gridSize = 100;
grid_after = zeros(gridSize, gridSize);

% 2. WEG 변수 생성
wegValues_after = zeros(10000, 10);
for i = 1:10000
    firstValue = 0.2 + 0.4*rand(); % 첫 번째 랜덤 값
    wegValues_after(i, 1) = firstValue;
    for j = 2:10
        nextValue = 0.2 + 0.4*rand(); % 다음 랜덤 값
        if firstValue < 0.3 % 범위가 0.2-0.3이 아닐 경우
            nextValue = nextValue - 0.1; % 0.1을 빼서 생성
        end
        wegValues_after(i, j) = nextValue;
    end
end

% 3. 평균 계산
avgWEG_after = mean(wegValues_after, 2);

% 4. Defect 변수 계산
defectValues_after = (avgWEG_after - 0.2) / 0.4;
defectValues_after(defectValues_after < 0) = 0;
defectValues_after(defectValues_after > 1) = 1;

% 5. 그리드 색 채우기
for i = 1:gridSize
    for j = 1:gridSize
        grid_after(i, j) = defectValues_after((i-1)*gridSize + j);
    end
end







% Plotting
figure;

subplot(1, 2, 1);

% 그리드 표시
imagesc(grid);
colormap(flipud(gray)); % 회색조로 표시
colorbar; % 색상 막대 표시

title('Defect Map (Before)');
xlabel('X-axis');
ylabel('Y-axis');
caxis([0 1]); % 컬러 맵 범위 고정

subplot(1, 2, 2);

imagesc(grid_after);
colormap(flipud(gray));
colorbar;


title('Defect Map (After)');
xlabel('X-axis');
ylabel('Y-axis');
caxis([0 1]); % 컬러 맵 범위 고정