import plotly.graph_objects as go
import plotly.express as px
import pandas as pd
import numpy as np
import os
import math
import re
import plotly.io as pio
import natsort 
import argparse

def get_title(txt_file):
    try:
      with open(txt_file, 'r', encoding='cp949')as fp:
        title = fp.read()
    except UnicodeDecodeError:
      with open(txt_file, 'r', encoding='utf-8')as fp:
        title = fp.read()
    return title

def extract_info(csv_file):
    without_extension = csv_file.split('.')[0]
    split_elements = without_extension.split("_")
    info_num = len(split_elements)
    # 유형, 방향, 모드 지정
    if info_num == 4:
        c_type, ori, mode = split_elements[1:]
    elif info_num == 3:
        c_type, ori = split_elements[1:]
        mode = None  # 모드는 None으로 지정 또는 원하는 기본값 설정
    else:
        c_type = split_elements[1]
        ori, mode= None, None
    return c_type, ori, mode

#### def sorting values 간소화를 위한 함수 ####
def run_sort(df_in, column, pattern=r"(\d{4})년 (\d+)월", 
             extract_val=['Year', 'Month'], replace_val=['Year', 'Month'], sort_val=['Year', 'Month'], 
             fill_target=None):

    out_df = df_in.copy()
    out_df[extract_val] = out_df[str(column)].str.extract(pattern) #열 추출 및 생성
    
    if fill_target is not None:
      [out_df[target].fillna(0, inplace=True) for target in fill_target] # NaN 값을 0으로 대체

    for r_v in replace_val:
        out_df[r_v] = out_df[r_v].apply(lambda x: int(x))
    out_df.sort_values(sort_val, ascending=True, inplace=True)
    out_df.reset_index(drop=True, inplace=True)
    out_df = out_df.drop(sort_val, axis=1)

    return out_df

def sorting_values(df, column):
    pattern1 =  r'\d{4}년 \d+월' #ex. 2018년 3월
    pattern2 = r'\d{4}년 \d+분기' #ex. 2018년 3분기
    pattern3 = r"Q[1-4]\ '\d{2}" #ex. Q3'17

    if any(re.search(pattern1, value) for value in df[str(column)]):
        try:
            sorted_df = run_sort(df_in=df, pattern = r"(\d{4})년 (\d+)월", extract_val=['Year', 'Month'], replace_val=['Year', 'Month'], sort_val=['Year', 'Month'], fill_target=None)
            return sorted_df
        except ValueError:
            sorted_df = run_sort(df_in=df, pattern = r"(\d{4})년 (\d+)월", extract_val=['Year', 'Month'], replace_val=['Year', 'Month'], sort_val=['Year', 'Month'], fill_target=['Year', 'Month'])
            return sorted_df
    elif any(re.search(pattern2, value) for value in df[str(column)]):
        try:
            sorted_df = run_sort(df_in=df, pattern = r"(\d{4})년 (\d+)분기", extract_val=['Year', 'Quarter'], replace_val=['Year', 'Quarter'], sort_val=['Year', 'Quarter'], fill_target=None)
            return sorted_df
        except ValueError:
            sorted_df = run_sort(df_in=df, pattern = r"(\d{4})년 (\d+)분기", extract_val=['Year', 'Quarter'], replace_val=['Year', 'Quarter'], sort_val=['Year', 'Quarter'], fill_target=['Year'])
            return sorted_df
    elif any(re.search(pattern3, value) for value in df[str(column)]):
        try:
            sorted_df = run_sort(df_in=df, pattern = r"(Q[1-4]) '(\d{2})", extract_val=['Quarter', 'Year'], replace_val=['Year'], sort_val=['Year', 'Quarter'], fill_target=None)
            return sorted_df
        except ValueError:
            sorted_df = run_sort(df_in=df, pattern = r"(Q[1-4]) '(\d{2})", extract_val=['Quarter'], replace_val=['Year'], sort_val=['Year', 'Quarter'], fill_target=['Year'])
            return sorted_df
    else:
        return df

### 간소화 함. if else python 식 코드를 통해 간소화 ##
def get_input(df, ori):
  #chart classify(simple이면 0, multi이면 1)
    classify_type = 'multi'if len(df.columns) > 2 else 'simple'

    #x, y input(x축:value, 축:label)
    if classify_type == 'simple': #simple chart 경우
        x_val, y_val = (df.columns[1], df.columns[0]) if ori == '1' else (df.columns[0], df.columns[1])
        if ori =='1':#차트 방향이 '가로'
            if df[str(x_val)].astype(str).str.contains('%').any():
                df[str(x_val)] = df[str(x_val)].str.replace('%', '')  # % 기호 제거
                x_val = x_val

    else:#multi chart의 경우(classification_type = 'multi')
        x_val, y_val = ([], df.columns[0]) if ori == '1' else (df.columns[0], [])
        for idx in range(1, len(df.columns)): #y축 값
            val =df.columns[idx]
            df[str(idx)] = df[str(idx)].str.replace('%', '') if df[str(idx)].astype(str).str.contains('%').any() else df[str(idx)]
            x_val.append(str(val)) if ori == '1' else y_val.append(str(val))

    return classify_type, x_val, y_val

def axes_range(input_list):
    #기존 최솟값, 최댓값
    old_min,old_max = min(input_list), max(input_list)
    #새로운 최솟값,최댓값 선언 (범주용)
    new_min,new_max = 0,0
    # 소수인 경우
    if isinstance(old_min, float) or isinstance(old_max, float):
        int_min, int_max = math.floor(old_min ), math.ceil(old_max )
        try:
            min_digits = int(math.log10(abs(int_min)))
        except ValueError:
            min_digits = 0
        try:
            max_digits = int(math.log10(abs(int_max)))
        except ValueError:
            max_digits = 0
        new_min = old_min
        if max_digits == 0 and old_max < 5:
            new_max = 5
        elif max_digits == 0 and old_max >5:
            new_max = 10
        else:
            new_max = (int(int_max / (10 ** max_digits)) + 1) * (10 ** max_digits)
        return(new_min, new_max)
    else:
        #로그오류 경우
        try:
            min_digits = int(math.log10(abs(old_min)))
        except ValueError:
            min_digits = 0
        try:
            max_digits = int(math.log10(abs(old_max)))
        except ValueError:
            max_digits = 0

        # digits가 모두 0인 경우
        if min_digits == 0 and max_digits == 0:
            if old_min < 0 :  # 음수/0인 경우
                #old_min = -1
                #new_min = (int(old_min / (10 ** min_digits))) * (10 ** (min_digits+1))
                new_min = old_min
                new_max = 0 if old_max < 0 or old_max == 0 else 10

            elif old_min == 0:
                new_min = 0
                new_max = 0 if old_max < 0 or old_max == 0 else 10
            else:
                new_min = old_min
                new_max = 0 if old_max < 0 or old_max == 0 else 10

        elif min_digits != 0 and max_digits == 0:
            new_min = (int(old_min / (10 ** min_digits)) -1 ) * (10 ** (min_digits))
            new_max = 0 if old_max < 0 or old_max == 0 else 10

        elif min_digits == 0 and max_digits != 0:
            if old_min < 0:  # 음수/0인 경우
                new_min = old_min
                new_max = (int(old_max / (10 ** max_digits)) +1 ) * (10 ** (max_digits))
            elif old_min == 0:
                new_min = 0
                new_max = (int(old_max / (10 ** max_digits)) +1 ) * (10 ** (max_digits))
            else:
                new_min = old_min
                new_max = (int(old_max / (10 ** max_digits)) +1 ) * (10 ** (max_digits))

        else:# min_digits != 0 and max_digits != 0
            new_min = (int(old_min / (10 ** min_digits)) -1 ) * (10 ** (min_digits))
            new_max = (int(old_max / (10 ** max_digits)) +1 ) * (10 ** (max_digits))

        return(new_min, new_max)

### remove special characters 간소화를 위한 함수
def replace_str(val_in, _type, rm_chr, _from=None, _to=None, removed_checkpoint=0):
    type_dict = {'int': int, 'float':float}
    val_out = val_in
    val_out = type_dict[_type](val_out.replace(_from, _to)) if _from is not None else type_dict[_type](val_out)
    rm_chr.append(val_out)
    return removed_checkpoint

## 반복형태 코드 함수를 통한 간소화 ##
def remove_special_characters(range_list):
    removed_chr  =[]
    removed_checkpoint = 0
    for val in range_list:
        if isinstance(val, str) and '%' in val:
            try:
                removed_checkpoint = replace_str(val_in=val, _type='int', rm_chr=removed_chr, _from='%', _to='', removed_checkpoint=1)# % 기호 제거
            except ValueError: #소수인 경우
                removed_checkpoint = replace_str(val_in=val, _type='float', rm_chr=removed_chr, _from='%', _to='', removed_checkpoint=1)# % 기호 제거
        elif isinstance(val, list) and '%' in val:
            try:
                removed_checkpoint = replace_str(val_in=val, _type='int', rm_chr=removed_chr, _from='%', _to='', removed_checkpoint=1)# % 기호 제거
            except ValueError: #소수인 경우
                removed_checkpoint = replace_str(val_in=val, _type='float', rm_chr=removed_chr, _from='%', _to='', removed_checkpoint=removed_checkpoint)# % 기호 제거
        else:
            try:
                removed_checkpoint = replace_str(val_in=val, _type='float', rm_chr=removed_chr, _from=None, _to=None, removed_checkpoint=removed_checkpoint)# % 기호 제거
            except ValueError: #문자만 있는 경우
                val = 0
                removed_chr.append(val)
    return removed_chr, removed_checkpoint

## 폴더 생성 부분 간소화 ##
def mk_dir(target_path):
    if not os.path.exists(target_path):
        os.mkdir(target_path) #폴더 생성

## figure 생성 부 간소화를 위한 함수 ##
def set_figure(df, y_val, x_val, title,out_path, update='x', orientation = None):
    sorted_df = sorting_values(df, y_val) if update == 'x' else sorting_values(df, x_val) #정렬
    range_list=sorted_df[str(x_val)].tolist() if update == 'x' else sorted_df[str(y_val)].tolist()
    new_min, new_max = axes_range(range_list)
    chart = go.Bar(x=sorted_df[str(x_val)], y=sorted_df[str(y_val)],orientation=orientation) if orientation is not None else go.Bar(x=sorted_df[str(x_val)], y=sorted_df[str(y_val)])
    layout = go.Layout(title=title)
    fig = go.Figure(data=chart, layout=layout)
    fig.update_xaxes(range=[new_min, new_max]) if update == 'x' else fig.update_yaxes(range=[new_min, new_max])
    fig.update_layout( font=dict({'family':'nanum'}))
    fig.update_traces(text=df[str(x_val)], textposition='outside', textfont=dict(color='black')) if update == 'x' else fig.update_traces(text=df[str(y_val)], textposition='outside', textfont=dict(color='black'))
    pio.write_image(fig, f"{out_path}/{img_name}", engine="kaleido", format="png")


parser = argparse.ArgumentParser()
parser.add_argument("-data", dest="data_path", action="store", default="/Users/angsubeng/Downloads/Chart2text_datasets/data_ko/")
parser.add_argument("-title", dest="tit_path", action="store", default="/Users/angsubeng/Downloads/Chart2text_datasets/tit_ko/")
args = parser.parse_args()

csv_list = natsort.natsorted([file for file in os.listdir(args.data_path)])
err_list = []

#output 경로 생성(bar-1, line-2, pie-3, table-4)
g_type = ['bar', 'line', 'pie', 'table']
[mk_dir(target_path=args.data_path+g) for g in g_type]
output_list =  [args.data_path+g for g in g_type]

for csv_file in csv_list:
    csv_path = f'{args.data_path}{str(csv_file)}'
    txt_path1 = f'{args.tit_path}{str(csv_file)}'
    txt_path = os.path.splitext(txt_path1)[0]+'.txt'
    img_name = os.path.splitext(csv_file)[0]

    try:
        df = pd.read_csv(csv_path, encoding='cp949')
        encoding_method = 'cp949'
    except UnicodeEncodeError:
        df = pd.read_csv(csv_path, encoding='utf-8')
        encoding_method = 'utf-8'
    except pd.errors.EmptyDataError:
        err_list.append(csv_file)
        pass
    try:
        title = get_title(txt_path)
        c_type, ori, mode = extract_info(csv_file) #c_type: 차트 유형, ori:방향, mode: 차트 모드
        print(csv_file)
        classify_type, x_val, y_val= get_input(df, ori)

        output_check =  np.array([os.path.exists(f"{args.data_path+g}/{img_name}") for g in g_type]).sum()
        if output_check < 4:
            if c_type =='1':#bar
                if classify_type =='simple':
                      #axes_range 파악
                    if ori =='1':
                        set_figure(df=df, y_val=y_val, x_val=x_val, title=title, out_path=output_list[0], update='x', orientation='h')
                    else:
                        set_figure(df=df, y_val=y_val, x_val=x_val, title=title, out_path=output_list[0], update='y', orientation='h')
            elif c_type =='3':
                sorted_df = sorting_values(df, x_val) #정렬
                fig = px.pie(sorted_df, values=y_val, names=x_val, title=title)
                fig.show()#차트 시각
                fig.update_layout( font=dict({'family':'nanum'}))
                pio.write_image(fig, f"{output_list[2]}/{img_name}", engine="kaleido", format="png")
            elif c_type =='4':
                if classify_type =='simple':
                    sorted_df = sorting_values(df, x_val) #정렬
                    layout = go.Layout(title=title)
                    fig = go.Figure(layout=layout)
                    fig.add_trace(go.Table(header = dict(values=[x_val,y_val]),
                      cells = dict(values=[sorted_df[str(x_val)],sorted_df[str(y_val)]])))
                    fig.update_layout( font=dict({'family':'nanum'}))
                    pio.write_image(fig, f"{output_list[3]}/{img_name}", engine="kaleido", format="png")

    except (IndexError, TypeError, ValueError):
        err_list.append(csv_file)
        pass

'''
except TypeError:
err_list.append(csv_file)
pass
except ValueError:
err_list.append(csv_file)
pass
except KeyError:
err_list.append(csv_file)
pass
except FileNotFoundError:
err_list.append(csv_file)
pass
'''

#t생성한 이미지 수
print(5000-len(err_list))
# 빈 DataFrame 생성
err_df = pd.DataFrame(columns=['err_idx'])
# 리스트 요소를 하나씩 셀에 넣기
for i, value in enumerate(err_list):
    err_df.loc[i, 'err_idx'] = value
# DataFrame 출력
#print(err_df)
err_df.to_csv('err_output.csv', index=False)
