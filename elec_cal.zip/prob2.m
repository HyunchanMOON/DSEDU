clear;
clc;
close all;

% x1, x2 범위 설정
x1 = linspace(0, pi, 100);
x2 = linspace(pi, 3*pi, 100);

% x1, x2 메쉬그리드 생성
[X1, X2] = meshgrid(x1, x2);

% f(x1, x2) 계산
F = sin(X1) + cos(X2);

% 시각화
figure;

% surf plot
subplot(2, 1, 1);
surf(x1, x2, F);
xlabel('x1');
ylabel('x2');
zlabel('f(x1, x2)');
title('f(x1, x2)의 surf plot');

% contour plot
subplot(2, 1, 2);
contour(x1, x2, F);
xlabel('x1');
ylabel('x2');
title('f(x1, x2)의 등고선도');

% 그리드 보이기
grid on;


%%
% 최적화할 함수 정의
f = @(x) - (sin(x(1)) + cos(x(2))); % 최대값을 구하기 위해 -f(x)를 사용

% 초기값 설정
x0 = [pi, pi];

% 최적화 실행
x_max = fminsearch(f, x0);

% 최대값 출력
f_max = -f(x_max);

% 결과 출력
fprintf('최대값 x1: %.6f\n', x_max(1));
fprintf('최대값 x2: %.6f\n', x_max(2));
fprintf('최대값 f(x1, x2): %.6f\n', f_max);

