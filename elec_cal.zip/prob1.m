clear;
clc;
close all;
% 변수 설정
a = 1; % 원형 코일의 반지름
I = 1; % 전류의 세기
z = linspace(-0.1, 0.1, 100); % -0.1m부터 0.1m까지 100개의 등간격으로 z 범위 설정

% H 계산
H = (I*a^2) ./ (2.*(a^2 + z.^2).^(3/2)); % H 계산식 적용

% 그래프 그리기
plot(z, H, 'b', 'LineWidth', 2);
xlabel('z (m)');
ylabel('H');
title('z에 따른 자계의 세기');
grid on;

%%

% 함수 정의
f = @(z) -((I*a^2) ./ (2.*(a^2 + z.^2).^(3/2))); % 최대값을 구하기 위해 -H를 사용

% 황금분할탐색법 설정
epsilon = 1e-6; % 수렴 조건 설정
phi = (1 + sqrt(5)) / 2; % 황금비율

% 초기 구간 설정
a = -0.1; % 시작점
b = 0.1; % 종료점

% 황금분할탐색법 알고리즘
while abs(b - a) > epsilon
    % 내부 점 설정
    x1 = b - (b - a) / phi;
    x2 = a + (b - a) / phi;
    
    % 함수 값 계산
    f1 = f(x1);
    f2 = f(x2);
    
    % 구간 업데이트
    if f1 >= f2
        a = x1;
    else
        b = x2;
    end
end

% 최대값 위치와 최대값 계산
z_max = (a + b) / 2;
H_max = -f(z_max);

% 결과 출력
fprintf('H가 최대가 되는 z 위치: %.6f m\n', z_max);
fprintf('최대값 H: %.6f\n', H_max);

