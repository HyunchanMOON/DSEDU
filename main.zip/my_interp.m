function x_interp = my_interp(x)

missing_idx = find(isnan(x));

x_interp = x;

for i = 1 :length(missing_idx)
    idx = missing_idx(i);
    if idx == 1
        x_interp(idx) = x(idx);
    elseif idx == length((x))
        x_interp(idx) = x(idx-1);
    else
        x_interp(idx) = (x(idx-1) + x(idx+1)) / 2;
    end
end
end

