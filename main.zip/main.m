clear;
clc;
close all;

fid = fopen('project_data.csv');
data = textscan(fid, '%s %f %f', 'Delimiter', ',', 'HeaderLines', 1);
fclose(fid);

date = data(:, 1);
date = date{1};

date = datetime(date);
length(find(isnat(date)))
date = my_interp_time(date);


load = cell2mat(data(:, 2));
power_gen = cell2mat(data(:, 3));

length(find(isnat(date)))
length(find(isnan(load)))
length(find(isnan(power_gen)))

load_total = my_interp(load);
res_out = my_interp(power_gen);

length(find(isnan(load_total)))
length(find(isnan(res_out)))

subplot(2, 1, 1)
plot(date, load_total)
xlabel('min')
ylabel('MW')
xtickformat("mm:ss")
subplot(2,1,2)
plot(date, res_out)

xlabel('min')
ylabel('MW')
xtickformat("mm:ss")



%%
net_load = load_total - res_out;
months = month(date);
is_summer = months >= 4 & months <= 10;  % 4월부터 10월까지를 하계로 설정
is_winter = ~is_summer;  % 하계를 제외한 나머지를 동계로 설정

% 동계와 하계 데이터 분리
winter_load_data = net_load(is_winter);
summer_load_data = net_load(is_summer);

winter_hour_load = mean(reshape(winter_load_data, 12, []))';
winter_date = date(is_winter);
winter_date = winter_date(1:12:length(winter_load_data));

summer_hour_load = mean(reshape(summer_load_data, 12, []))';
summer_date = date(is_summer);
summer_date = summer_date(1:12:length(summer_load_data));

% 그래프 그리기
figure

% 동계
subplot(2, 1, 1)

plot(winter_date, winter_hour_load)
xlabel('시간(hour)')
ylabel('평균 순부하(MW)')

%xticks(winter_date)
xtickangle(45)
xtickformat("HH:mm:ss")
title('동계')
% 하계
subplot(2, 1, 2)

plot(summer_date, summer_hour_load)
xlabel('시간(hour)')
ylabel('평균 순부하(MW)')
title('하계')
%xticks(summer_date)
xtickformat("HH:mm:ss")
xtickangle(45)
% 그래프 간격 조정
sgtitle('2021년 시간대별 평균 순부하')
%%

clear;
clc;
close all;
% 2-1
% 데이터 불러오기
% Syldavia 데이터 불러오기

fid = fopen('project_data.csv');
data = textscan(fid, '%s %f %f', 'Delimiter', ',', 'HeaderLines', 1);
fclose(fid);

date = data(:, 1);
date = date{1};

date = datetime(date, 'Format','yyyy-MM-dd HH:mm');
length(find(isnat(date)))
date = my_interp_time(date);

load = cell2mat(data(:, 2));
power_gen = cell2mat(data(:, 3));

load_total = my_interp(load);
res_out = my_interp(power_gen);

% 날짜별로 그룹화하여 일간 합계 계산
unique_dates = unique(dateshift(date, 'start', 'day'));
generation_2021_daily = zeros(size(unique_dates));
for i = 1:length(unique_dates)
    date_mask = date >= unique_dates(i) & date < unique_dates(i) + days(1);
    generation_2021_daily(i) = sum(res_out(date_mask));
end

% 그래프 그리기
plot(unique_dates, generation_2021_daily);
xlabel('날짜');
ylabel('일간 재생에너지 발전량 (MW)');
title('2021년 연평균 일간 재생에너지 발전량');
xtickformat("mm:ss")


%%
% 2-2
clear;
clc;
close all;

% 데이터 로드

fid = fopen('project_data.csv');
data = textscan(fid, '%s %f %f', 'Delimiter', ',', 'HeaderLines', 1);
fclose(fid);

date = data(:, 1);
date = date{1};

date = datetime(date, 'Format','yyyy-MM-dd HH:mm');

date = my_interp_time(date);

load = cell2mat(data(:, 2));
power_gen = cell2mat(data(:, 3));

load_total = my_interp(load);
res_out = my_interp(power_gen);

% 연도별 재생에너지 발전량 증가율 로드
increase_data = readtable('res_increase.csv');
years_list = table2array(increase_data(:,1));
rates = table2array(increase_data(:,2));

% 초기값 설정
net_load = load_total - res_out;
now_year = min(years_list);
zero_net_load_year = [];
start_time = [];
end_time = [];
% 순부하가 0이 되는 지점 계산
while isempty(zero_net_load_year)
    year_idx = now_year - 2020; % res_increase 행 인덱스
    x_growth_rate = rates(year_idx); % 재생에너지 발전량 성장률
    
    if now_year > 2021
        load_total = load_total * (1 - 0.02); % 총 부하 2% 감소
    end

    res_out = res_out * (1 + x_growth_rate / 100);

    net_load = load_total - res_out;
    zero_net_load_idx = find(net_load <= 0, 1); % 순부하가 0 이하인 첫 인덱스
    
    if ~isempty(zero_net_load_idx)
        zero_net_load_year = now_year;
        start_time = date(zero_net_load_idx);
        end_time = date(zero_net_load_idx + 1);
    end
    
    now_year = now_year + 1;
end

% 결과 출력
fprintf('순부하가 0이 되는 지점:\n');
fprintf('년도: %d\n', zero_net_load_year);
fprintf('발생 시간: %s ~ %s\n', start_time, end_time);

%%
%2-3
clear;
clc;
close all;

% 데이터 로드

fid = fopen('project_data.csv');
data = textscan(fid, '%s %f %f', 'Delimiter', ',', 'HeaderLines', 1);
fclose(fid);

date = data(:, 1);
date = date{1};

date = datetime(date, 'Format','yyyy-MM-dd HH:mm');

date = my_interp_time(date);

load = cell2mat(data(:, 2));
power_gen = cell2mat(data(:, 3));

load_total = my_interp(load);
res_out = my_interp(power_gen);

% 연도별 재생에너지 발전량 증가율 로드
increase_data = readtable('res_increase.csv');
years_list = table2array(increase_data(:,1));
rates = table2array(increase_data(:,2));

% 초기값 설정
net_load = load_total - res_out;
now_year = 2021;
time_range = [];

negative_net_load_range = [];
max_restriction = 0;

% 순부하가 음의 값을 갖는 시간 범위 계산 및 최대 제한 출력 확인
while now_year <= 2040
    year_idx = now_year - 2020; % res_increase 행 인덱스
    x_growth_rate = rates(year_idx); % 재생에너지 발전량 성장률
    
    if now_year > 2021
        load_total = load_total * (1 - 0.02); % 총 부하 2% 감소
    end
    
    res_out = res_out + (res_out * (x_growth_rate / 100)); % 재생에너지 발전량 성장

    net_load = load_total - res_out;

    negative_net_load_idx = find(net_load < 0); % 순부하가 음의 값을 갖는 인덱스
    

    if now_year == 2040
        negative_net_load_idx = find(net_load < 0);
        if ~isempty(negative_net_load_idx)
            negative_net_load_range = date(negative_net_load_idx);
        end
    end

    %%2-4

    % 총부하의 최소값을 음수로 만들기 위한 재생에너지 출력 제한 찾기
    % 최대 제한 출력 확인
    max_restriction = max(max_restriction, abs(min(net_load)));
    
    now_year = now_year + 1;
end

% 결과 출력
fprintf('2040년에 순부하가 음의 값을 갖는 시간 범위:\n');
fprintf('%s ~ %s\n', negative_net_load_range(1), negative_net_load_range(end));
fprintf('재생에너지 출력제한 조치로 설정할 수 있는 최대 재생에너지 발전량: %.2f MW\n', max_restriction);

% 배터리 용량 계산
time_interval = 5; % 시간 간격 (분 단위)
total_energy_deficit = sum(net_load(net_load < 0)) * time_interval / 60; % 에너지 결손량 (MWh)

battery_power_capacity = max_restriction; % MW
battery_energy_capacity = abs(total_energy_deficit); % MWh

disp(['배터리의 MW 용량: ', num2str(battery_power_capacity), 'MW']);
disp(['배터리의 MWh 용량: ', num2str(battery_energy_capacity), 'MWh']);
