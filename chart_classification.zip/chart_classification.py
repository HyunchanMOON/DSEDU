#!/usr/bin/env python
# coding: utf-8

# In[4]:


import os
import shutil
import argparse


def get_title(txt_file):
    try:
        with open(txt_file, "r", encoding="cp949")as fp:
            title = fp.read()
    except UnicodeDecodeError:
        with open(txt_file, 'r', encoding="utf-8")as fp:
            title = fp.read()
    return title


def extract_info(file):
    '''
    param : 
        file : 
    output :
        c_type, ori, mode : (순서대로) 유형, 방향, 모드 지정
    '''
    without_extension = file.split('.')[0]
    split_elements = without_extension.split("_")
    info_num = len(split_elements)
    
    if info_num == 4:
        c_type, ori, mode = split_elements[1:]
    elif info_num == 3:
        c_type, ori = split_elements[1:]
        # 모드는 None으로 지정 또는 원하는 기본값 설정
        mode = None 
    else:
        c_type = split_elements[1]
        ori= None
        mode = None
    return c_type, ori, mode


def path_creating(base_path):
    '''
    param : 
        base_path : 
    output :
         dst_path : 
    '''
    dst_path = {
        'bar': f'{base_path}/bar/',
        'line': f'{base_path}/line/',
        'pie': f'{base_path}/pie/',
        'table': f'{base_path}/table/'
    }
    for path in dst_path.values():
        os.makedirs(path, exist_ok=True)
    return dst_path


def saving_new_path(file_list, src_path, dst_path):
    '''
    param : 
        file_list : 
        src_path  :
        dst_path  :
    output :
        bar = 1 , line = 2, pie = 3, table = 4
    '''
    for file in file_list:
        file_path = f'{src_path}/{file}'
        c_type, ori, mode = extract_info(file)  
        
    if c_type == '1':  
        if ori == '1':
            src = file_path
            dst = dst_path['bar']
            shutil.move(src, dst)
    elif c_type == '2':  
        src = file_path
        dst = dst_path['line']
        shutil.move(src, dst)
    elif c_type == '3':  
        src = file_path
        dst = dst_path['pie']
        shutil.move(src, dst)
    elif c_type == '4':  
        src = file_path
        dst = dst_path['table']
        shutil.move(src, dst)
    return 


parser = argparse.ArgumentParser()
parser.add_argument("-data", dest="d_path", action="store", default="data_ko")
parser.add_argument("-caption", dest="c_path", action="store", default="cap_ko")
parser.add_argument("-title", dest="t_path", action="store", default="tit_ko")
parser.add_argument("-image", dest="i_path", action="store", default="image")
parser.add_argument("-root", dest="root_path", action="store")
args = parser.parse_args()


data_path = f'{args.root_path}/{args.d_path}'
cap_path = f'{args.root_path}/{args.c_path}'
tit_path = f'{args.root_path}/{args.t_path}'
img_path = f'{args.root_path}/{args.i_path}'

path_list = [data_path,cap_path,tit_path,img_path]

path_files = [[file for file in os.listdir(pl)] for pl in path_list]

dst_paths = [path_creating(pl) for pl in path_list]

[saving_new_path(pf, pl, dst) for (pf, pl, dst) in zip(path_files, path_list, dst_paths)]



# In[ ]:




