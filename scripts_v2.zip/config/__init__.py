import argparse
import os
import datetime

def get_config(argv=None):

    abs_path = os.path.abspath(__file__).split('\\')[:-1]

    parser = argparse.ArgumentParser(
        description='ml config')

    today = datetime.datetime.now().strftime("%Y%m%d")

    parser.add_argument("--today", type=str, default=today)

    parser.add_argument("--ml_cfg_path", type=str, default=os.path.join('/'.join(abs_path), "config.yaml"),
                        help="yaml cfg path ")
    
    parser.add_argument("--main_path", type=str, default="/data001/projects/thd_return/data/")

    parser.add_argument("--save_path", type=str, default="result_files/",
                        help="learning result save path ")

    parser.add_argument("--logging_path", type=str, default=os.path.join('/'.join(abs_path[:-2]), "log"),
                        help="logging_path path ")               
    
    return parser


def str2bool(v):
    if v.lower() in ('yes', 'true', 't', 'y', '1'):
        return True
    elif v.lower() in ('no', 'false', 'f', 'n', '0'):
        return False
    else:
        raise argparse.ArgumentTypeError('Boolean value expected.')
