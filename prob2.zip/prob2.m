clear;
clc;
close all;
% 2-1
% 데이터 불러오기
% Syldavia 데이터 불러오기

fid = fopen('project_data.csv');
data = textscan(fid, '%s %f %f', 'Delimiter', ',', 'HeaderLines', 1);
fclose(fid);

date = data(:, 1);
date = date{1};

date = datetime(date, 'Format','yyyy-MM-dd HH:mm');
length(find(isnat(date)))
date = my_interp_time(date);

load = cell2mat(data(:, 2));
power_gen = cell2mat(data(:, 3));

load_total = my_interp(load);
res_out = my_interp(power_gen);

% 날짜별로 그룹화하여 일간 합계 계산
unique_dates = unique(dateshift(date, 'start', 'day'));
generation_2021_daily = zeros(size(unique_dates));
for i = 1:length(unique_dates)
    date_mask = date >= unique_dates(i) & date < unique_dates(i) + days(1);
    generation_2021_daily(i) = sum(res_out(date_mask));
end

% 그래프 그리기
plot(unique_dates, generation_2021_daily);
xlabel('날짜');
ylabel('일간 재생에너지 발전량 (MW)');
title('2021년 연평균 일간 재생에너지 발전량');
xtickformat("mm:ss")


%%
% 2-2
clear;
clc;
close all;

% 데이터 로드

fid = fopen('project_data.csv');
data = textscan(fid, '%s %f %f', 'Delimiter', ',', 'HeaderLines', 1);
fclose(fid);

date = data(:, 1);
date = date{1};

date = datetime(date, 'Format','yyyy-MM-dd HH:mm');

date = my_interp_time(date);

load = cell2mat(data(:, 2));
power_gen = cell2mat(data(:, 3));

load_total = my_interp(load);
res_out = my_interp(power_gen);


% 연도별 재생에너지 발전량 증가율 로드
increase_data = readtable('res_increase.csv');
years_list = table2array(increase_data(:,1));
rates = table2array(increase_data(:,2));

% 초기값 설정
net_load = load_total - res_out;
now_year = min(years_list);
time_start = [];
time_end = [];

while ~any(net_load <= 0)
    % 재생에너지 발전량 증가율 적용
    
    growth_rate = rates(years_list == now_year);
    res_out = res_out * (1 + growth_rate / 100);
    
    % 순부하 계산
    net_load = load_total - res_out;
    
    % 다음 연도로 넘어가기
    now_year = now_year + 1;
    
    % 순부하가 0인 시간 기록
    time_mask = net_load <= 0 & isempty(time_start);
    time_start = date(time_mask);
    time_mask = net_load > 0 & ~isempty(time_start);
    time_end = date(time_mask);
end


idx_zero = find(time_mask==0);
result_year = year(date(idx_zero(1)));
% 결과 출력

fprintf('총 부하가 0이 되는 지점은 %d 년입니다.', result_year)

fprintf('발생하는 시간은 %s 시부터 %s 시까지입니다.', date(idx_zero(1)), date(idx_zero(1)+1))

%%
%2-3
clear;
clc;
close all;

% 데이터 로드

fid = fopen('project_data.csv');
data = textscan(fid, '%s %f %f', 'Delimiter', ',', 'HeaderLines', 1);
fclose(fid);

date = data(:, 1);
date = date{1};

date = datetime(date, 'Format','yyyy-MM-dd HH:mm');

date = my_interp_time(date);

load = cell2mat(data(:, 2));
power_gen = cell2mat(data(:, 3));

load_total = my_interp(load);
res_out = my_interp(power_gen);


% 연도별 재생에너지 발전량 증가율 로드
increase_data = readtable('res_increase.csv');
years_list = table2array(increase_data(:,1));
rates = table2array(increase_data(:,2));

% 초기값 설정
net_load = load_total - res_out;
now_year = min(years_list);
time_range = [];

while now_year <= 2040
    % 재생에너지 발전량 증가율 적용
    growth_rate = rates(years_list == now_year);
    res_out = res_out * (1 + growth_rate / 100);
    
    % 순부하 계산
    net_load = load_total - res_out;

    if now_year == 2040
        % 순부하가 음수인 시간 범위 기록
        time_mask = net_load < 0;
        time_range = date(time_mask);
    end
    
    % 다음 연도로 넘어가기
    now_year = now_year + 1;
end

% 결과 출력
disp(['2040년에 순부하가 음의 값을 갖는 시간 범위:']);
disp(char(time_range));

%%2-4
% 재생에너지 출력 제한 조치 계산
max_restriction = abs(min(net_load));

disp(['재생에너지 출력 제한 조치로 인해 최대 ', num2str(max_restriction), 'MW까지 발생합니다.']);

