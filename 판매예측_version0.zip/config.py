import argparse

def set_config(argv=None):
    parser = argparse.ArgumentParser(
        description='Pharm-Wholesale Data Learner')
    parser.add_argument("--cfg_path",type=str,default="./config/config.json")
    # parser.add_argument("--save_",type=str,default="./config/config.json")
    parser.add_argument("--mode",type=str,default="inference",
                        help='test, inference -> test mode 설정 시 test data에 대한 Visualization 진행됨.')
    parser.add_argument("--model",type=str,default="xgbm",
                        help='xgbm, lgbm')
    parser.set_defaults(cfg_path='./config/config.json')

    return parser