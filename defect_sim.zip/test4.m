clc;
clear;
close all;

% 공정 개선 전 코드
gridSize = 100;
[x, y] = meshgrid(1:gridSize, 1:gridSize);
numPoints = gridSize^2;
numGroups = 10;
wegValues_before = zeros(1, numPoints);

for i = 1:numGroups:numPoints
    wegRange = rand(1, numGroups) * 0.1 + 0.2;
    wegValues_before(i:i+numGroups-1) = wegRange;
end

wegAverages_before = mean(reshape(wegValues_before, numGroups, []));
defectValues_before = (wegAverages_before - 0.2) / 0.4;
defectMap_before = reshape(defectValues_before, gridSize/numGroups, []);
defectMap_before = repelem(defectMap_before, numGroups, 1);

% 공정 개선 후 코드
wegValues_after = zeros(1, numPoints);

for i = 1:numGroups:numPoints
    wegRange = rand() * 0.1 + 0.2;
    
    if wegRange < 0.3
        wegRange = wegRange - 0.1;
    end
    
    for j = 2:numGroups
        wegRange = [wegRange, rand() * 0.1 + 0.1];
    end
    
    wegValues_after(i:i+numGroups-1) = wegRange;
end

wegAverages_after = mean(reshape(wegValues_after, numGroups, []));
defectValues_after = (wegAverages_after - 0.2) / 0.4;
defectMap_after = reshape(defectValues_after, gridSize/numGroups, []);
defectMap_after = repelem(defectMap_after, numGroups, 1);

% 최대, 최소값을 통해 공정 개선 전과 후의 color map 범위 동일하게 설정
caxis_range = [min([defectValues_before, defectValues_after]), max([defectValues_before, defectValues_after])];

% Plotting
figure;

subplot(1, 2, 1);
imagesc(defectMap_before);
colorbar;
colormap('jet');
axis equal;
title('Defect Map (Before)');
xlabel('X-axis');
ylabel('Y-axis');
caxis(caxis_range);

subplot(1, 2, 2);
imagesc(defectMap_after);
colorbar;
colormap('jet');
axis equal;
title('Defect Map (After)');
xlabel('X-axis');
ylabel('Y-axis');
caxis(caxis_range);
