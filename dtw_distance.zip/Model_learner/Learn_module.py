
import warnings
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import MinMaxScaler
from ML_class.my_mlp_classes import *
import xgboost as xgb
from sklearn.multioutput import MultiOutputRegressor
from .oputuna_use import optm

def set_device():
    USE_CUDA = torch.cuda.is_available()
    DEVICE = torch.device("cuda" if USE_CUDA else "cpu")
    print(DEVICE)
    return DEVICE

def set_mlp(input_size, n_out, DEVICE):
    train_model = MLP_regressor(input_size=input_size[1], n_out=n_out).to(DEVICE)
    return train_model

def set_lstm(input_size, n_out, DEVICE):
    train_model = LSTM_regressor(input_size=input_size[1:], hidden_dim=10, n_out=n_out, layers=1).to(DEVICE)
    return train_model


def set_model(params=None):
    xgb_model = MultiOutputRegressor(xgb.XGBRegressor(**params)) if params is not None else MultiOutputRegressor(xgb.XGBRegressor())
    return xgb_model


class Learn_manager():
    def __init__(self, X, Y, DEVICE, window=20, test_size=0.2, Model='MLP'):

        self.model_dict = {'MLP': set_mlp, 'LSTM':set_lstm}
        self.data_dict = {'MLP': self.data_split, 'LSTM':self.data_split_lstm, 'XGB': self.data_split}
        self.X = X
        self.Y = Y
        self.DEVICE = DEVICE
        self.Model = Model
        self.test_size = test_size
        self.window = window
        self.train_test_dict = dict()

    def __call__(self, ls_dict=None, hyper_tune=False, trial=10):
        self.data_dict[self.Model]()
        self.ls_dict = ls_dict

        if self.Model == "XGB":
            if hyper_tune:
                opt_models = optm()
                params, scores = opt_models.run_optm(x_train=self.train_test_dict['train_x'], y_train=self.train_test_dict['train_y'],
                                                     x_val=self.train_test_dict['test_x'], y_val=self.train_test_dict['test_y'],
                                                     n_trial=trial, direction='maximize', model=self.Model)
                model = set_model(params)
            else:
                model = set_model()
            model.fit(self.train_test_dict['train_x'], self.train_test_dict['train_y'])
            pred_output_np = model.predict(self.train_test_dict['test_x'])
            return model, pred_output_np

        else:
            model = self.model_dict[self.Model](self.train_test_dict['train_x'].shape, 2, DEVICE= self.DEVICE)


            net_learning = Dnn_Learner(DEVICE=self.DEVICE, type=self.Model)
            trained_model, train_loss, valid_loss, pred_output_np = net_learning.nn_learning(nn_model=model,
                                                                                            ls_dict=self.ls_dict,
                                                                                            data_dict=self.train_test_dict)

            return trained_model, pred_output_np

    def data_split(self):

        X_train, X_test, y_train, y_test = train_test_split(self.X, self.Y, test_size=self.test_size, random_state=2020, shuffle=False)

        self.train_test_dict['train_x'] = X_train
        self.train_test_dict['train_y'] = y_train
        self.train_test_dict['test_x'] = X_test
        self.train_test_dict['test_y'] = y_test

    def build_dataset(self, time_series, seq_length):

        dataX = []
        dataY = []

        for i in range(0, len(time_series) - (seq_length)):
            _x = time_series[i:i + seq_length, :-2]
            _y = time_series[i - 1 + seq_length, -2:]
            dataX.append(_x)
            dataY.append(_y)
        return np.array(dataX), np.array(dataY)

    def data_split_lstm(self):
        all_data = np.hstack([self.X, self.Y])

        test_size = int(self.test_size*len(all_data))
        train_data = all_data[:-test_size, :]
        test_data = all_data[-test_size:, :]

        X_train, y_train = self.build_dataset(time_series=train_data, seq_length=self.window)
        X_test, y_test = self.build_dataset(time_series=test_data, seq_length=self.window)

        self.train_test_dict['train_x'] = X_train
        self.train_test_dict['train_y'] = y_train
        self.train_test_dict['test_x'] = X_test
        self.train_test_dict['test_y'] = y_test


    def scale(self, train, test):
        # fit scaler
        self.scaler = MinMaxScaler(feature_range=(-1, 1))
        self.scaler = self.scaler.fit(train)
        # transform train
        train_scaled = self.scaler.transform(train)
        # transform test
        test_scaled = self.scaler.transform(test)
        return train_scaled, test_scaled