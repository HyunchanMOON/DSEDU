import torch.nn as nn
import torch
import torch.nn.init as init
import numpy as np
from torch.utils import data


class Dnn_Learner():
    def __init__(self, DEVICE):
        self.DEVICE = DEVICE

    def train(self,model, train_loader, optimizer,criterion):

        try:
            model.train()
            train_loss = 0

            for batch_idx, (data, target) in enumerate(train_loader):
                data, target = data.to(self.DEVICE), target.type(torch.float32).to(self.DEVICE)
                optimizer.zero_grad()
                hypothesis = model(data.type(torch.float32)).squeeze()
                loss = criterion(hypothesis, target)
                train_loss += loss
                loss.backward()
                optimizer.step()            
            train_loss /= len(train_loader.dataset)
            return train_loss

        except Exception as e:
            print('train::',e)

    def evaluate(self,model, test_loader,criterion):
        try:
            model.eval()
            test_loss = 0
            correct = 0

            with torch.no_grad():
                for data, target in test_loader:
                    data, target = data.to(self.DEVICE), target.type(torch.float32).to(self.DEVICE)
                    hypothesis = model(data.type(torch.float32)).squeeze()
                    test_loss += criterion(hypothesis, target)

            test_loss /= len(test_loader.dataset)
            test_accuracy = 100 * correct/len(test_loader.dataset)

            return test_loss, test_accuracy
        except Exception as e:
            print('evaluate',e)

    def nn_learning(self,nn_model, ls_dict, data_dict):
        optimizer = torch.optim.Adam(nn_model.parameters(), lr = ls_dict['learning_rate'])
        train_loader = torch.utils.data.DataLoader(dataset=My_Dataset(data_dict['train_x'],data_dict['train_y']),batch_size=ls_dict['BATCH_SIZE'], shuffle=True)
        test_loader = torch.utils.data.DataLoader(dataset=My_Dataset(data_dict['test_x'],data_dict['test_y']),batch_size=ls_dict['BATCH_SIZE'], shuffle=True)

        criterion = torch.nn.MSELoss().to(self.DEVICE)
        test_loss = 0
        correct = 0
        patience = ls_dict['patience']
        avg_train_losses = []
        avg_valid_losses = []
        early_stopping = EarlyStopping(patience = patience, verbose = True)
        best_model = None

        for epoch in range(1, ls_dict['EPOCHS']+1):
            train_loss= self.train(nn_model, train_loader, optimizer,criterion)
            test_loss, _ = self.evaluate(nn_model, test_loader,criterion) # validation 설정
            avg_train_losses.append(train_loss)
            avg_valid_losses.append(test_loss)

            if epoch%10==0:
                print('epoch:{} train_loss:{:.4f}'.format(epoch,train_loss))
                print('validation_loss:{:.4f}'.format(test_loss))
                best_model = early_stopping(test_loss, nn_model)
                if early_stopping.early_stop:
                     print("Early stopping")
                     break

        if best_model is None : best_model = nn_model
        best_model.eval()
        output = best_model(torch.from_numpy(data_dict['test_x'].astype(np.float32)).to(self.DEVICE)).cpu().squeeze()
        cost = criterion(output, torch.from_numpy(data_dict['test_y'].astype(np.float32)).to(self.DEVICE).cpu())
        y = torch.from_numpy(data_dict['test_y'].astype(np.float32)).cpu()

        output_np = output.detach().numpy()

        return best_model, avg_train_losses, avg_valid_losses, output_np



class MLP_regressor(nn.Module):
    def __init__(self,input_size,n_out):
        super().__init__()
        self.n_out = n_out
        #self.enc_size = [input_size,64, 128, 256, 128, 64,32]
        self.enc_size = [input_size, 128, 256, 512, 256, 128, 64]
        #self.enc_size = [input_size,64, 128, 64, 32]
        self.layers = nn.ModuleList([self._make_block(in_f, out_f) for in_f, out_f in zip(self.enc_size, self.enc_size[1:])])
        self.output_layer = nn.Linear(self.enc_size[-1], self.n_out)
        #self.sig = torch.nn.Sigmoid()
        self.dropout_p = 0.1
        self.drop_layer = nn.Dropout(p=self.dropout_p)

        for m in self.modules():
            if isinstance(m, nn.Linear):
                init.xavier_normal_(m.weight.data)
                # m.bias.data.fill(0)

    def forward(self, x):
        for layer in self.layers:
          x = layer(x)
          x = self.drop_layer(x)
        x = self.output_layer(x)
        #if self.n_class ==1:
            #xx = self.sig(x)
        #else: xx = x
        return x

    def _make_block(self, input_num, output_num):
        return nn.Sequential(
            nn.Linear(input_num, output_num),
            nn.BatchNorm1d(output_num),
            nn.ReLU())


class EarlyStopping:
    """주어진 patience 이후로 validation loss가 개선되지 않으면 학습을 조기 중지"""
    def __init__(self, patience=7, verbose=False, delta=0, path='checkpoint.pt'):
        """
        Args:
            patience (int): validation loss가 개선된 후 기다리는 기간
                            Default: 7
            verbose (bool): True일 경우 각 validation loss의 개선 사항 메세지 출력
                            Default: False
            delta (float): 개선되었다고 인정되는 monitered quantity의 최소 변화
                            Default: 0
            path (str): checkpoint저장 경로
                            Default: 'checkpoint.pt'
        """

        self.patience = patience
        self.verbose = verbose
        self.counter = 0
        self.best_score = None
        self.early_stop = False
        self.val_loss_min = np.Inf
        self.delta = delta
        self.path = path

    def __call__(self, val_loss, model):
        score = -val_loss

        if self.best_score is None:
            self.best_score = score
            self.best_model = model
            self.save_checkpoint(val_loss, model)
        elif score < self.best_score + self.delta:
            self.counter += 1
            print(f'EarlyStopping counter: {self.counter} out of {self.patience}')
            if self.counter >= self.patience:
                self.early_stop = True
            self.best_score = score
            return self.best_model
        else:
            print(f'Validation loss decreased ({-self.best_score:.6f} --> {val_loss:.6f}).')
            self.best_score = score
            self.best_model = model
            # self.save_checkpoint(val_loss, model)
            self.counter = 0
            return self.best_model

    def save_checkpoint(self, val_loss, model):
        '''validation loss가 감소하면 모델을 저장한다.'''
        if self.verbose:
            print(f'Validation loss decreased ({self.val_loss_min:.6f} --> {val_loss:.6f}).')
        # torch.save(model.state_dict(), self.path)
        self.val_loss_min = val_loss


class My_Dataset(data.Dataset):
    def __init__(self, data, labels):
        super().__init__()
        self.data = data
        self.labels = labels
    def __len__(self):
        return len(self.data)
    def __getitem__(self, idx):
        return self.data[idx], self.labels[idx]
