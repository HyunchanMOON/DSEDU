
import warnings
from sklearn.model_selection import train_test_split
from ML_class.my_mlp_classes import *

def set_device():
    USE_CUDA = torch.cuda.is_available()
    DEVICE = torch.device("cuda" if USE_CUDA else "cpu")
    print(DEVICE)
    return DEVICE

class Learn_manager():
    def __init__(self, X, Y, DEVICE):
        self.X = X
        self.Y = Y
        self.DEVICE = DEVICE


    def __call__(self, ls_dict=None):
        self.data_split()
        self.ls_dict = ls_dict
        mlp_model = MLP_regressor(self.train_test_dict['train_x'].shape[1], 2).to(self.DEVICE)

        net_learning = Dnn_Learner(DEVICE=self.DEVICE)
        trained_model, train_loss, valid_loss, pred_output_np = net_learning.nn_learning(nn_model=mlp_model,
                                                                                        ls_dict=self.ls_dict,
                                                                                        data_dict=self.train_test_dict)

        return trained_model, pred_output_np
    def data_split(self):

        self.train_test_dict = dict()


        X_train, X_test, y_train, y_test = train_test_split(self.X, self.Y, test_size=0.2, random_state=2020, shuffle=False)

        self.train_test_dict['train_x'] = X_train
        self.train_test_dict['train_y'] = y_train
        self.train_test_dict['test_x'] = X_test
        self.train_test_dict['test_y'] = y_test
