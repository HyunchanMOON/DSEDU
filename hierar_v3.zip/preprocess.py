import numpy as np
import pandas as pd
from pickle import dump
# from scipy import stats
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler #, LabelEncoder

from results import FitResult, PredictResult #, NoFitResult
from model_param import ModelParam


class Preprocess:
    def __init__(self, param, dataset, is_predict):
        self.param = param
        self._dataset = dataset
        self.is_predict = is_predict
        # print(f'_dataset: {self._dataset}')
        
        
    def process(self):
        # 결측치 처리
        self._proc_missing_data(self._dataset)
        # 이상치 처리
        self._proc_outlier()
        # 문자형 -> 숫자형 변환
        self._num_conversion()
        # X/Y 분리
        x, y = self._split_x_y()
        # 스케일링
        x_scaled = self._scaling_data(x)
        # Train/val 분리
        x_train, x_val, y_train, y_val = self._split_train_val(x_scaled, y)
        result = FitResult()
        result.x_train = x_train
        result.x_val = x_val
        result.y_train = y_train
        result.y_val = y_val
        return result
    
    def pred_process(self) -> PredictResult:
        # 문자형 -> 숫자형 변환
        self._num_conversion()
        # X/Y 분리
        x, y = self._split_x_y()
        # 결측치 처리
        self._proc_missing_data(x)
        # 스케일링
        x_scaled = self._scaling_data(x)
        print(x_scaled)
        # Train/val 분리
        result = PredictResult()
        result.x_test = x_scaled
        result.y_test = y
        return result

    def _proc_missing_data(self, dataset):
        orgcnt = len(dataset)
        self.param: ModelParam
        if self.param.remove_null:  # 결측치 제거
            dataset = dataset.dropna(axis=0)
            removecnt = orgcnt-len(dataset)
            print('%d 레코드중 %d 레코드가 결측치로 제거되었습니다.<br>' % (orgcnt, removecnt))
        else:
            for c in dataset.columns:

                if 'float' in str(dataset.dtypes[c]) or 'int' in str(dataset.dtypes[c]):
                    mean_val = dataset[c].mean()
                    dataset[c].fillna(mean_val, inplace=True)
                else:
                    most_freq = dataset[c].value_counts(dropna=True).idxmax()
                    dataset[c].fillna(most_freq, inplace=True)
            print('%d 레코드중 %d 레코드가 치환되었습니다.<br>' % (orgcnt, removecnt))
            

    def _proc_outlier(self):
        if len(self._dataset) > 0:
            from scipy import stats
            
            _zscore_threshold = 3.0
            orgcnt = len(self._dataset)
            org_columns = self._dataset.columns.copy()
            
            chkcols = []
            for idx, c in enumerate(org_columns):
                if c in chkcols:
                    self._dataset.columns.values[idx] = c+"_dup"
                chkcols.append(c)
            
            zcols = []
            for c in chkcols:
                ccnt = chkcols.count(c)  # 동일한 컬럼이 2개이상일시 이상치제거안함..
                if (('float' in str(self._dataset.dtypes[c])) or ('int' in str(self._dataset.dtypes[c]))) and ccnt == 1:
                    # 분산이 0보다 크면 이상치 제거 동작
                    var = self._dataset[c].var()
                    if np.isnan(var) == False:
                        if var > 0.0001: 
                            self._dataset[c + '_Z'] = np.abs(stats.zscore(self._dataset[c])) 
                            zcols.append(c) 
            for c in zcols:
                self._dataset = self._dataset[(self._dataset[c+'_Z'] < _zscore_threshold)]

            print('org_columns=>',chkcols);
            self._dataset = self._dataset[chkcols]
            print('org2=>',self._dataset.columns);

            removecnt = orgcnt-len(self._dataset)
            print('%d 레코드중 %d 레코드가 이상치로 제거되었습니다.<br>' % (orgcnt, removecnt))
            print('※ 속성값이 일반적인 값보다 편차가 큰 값을 이상치로 분류하고 제거<br>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;(3시그마기준 99.7%이상에 포함되는 값을 이상치로 판별)')
    
    def _num_conversion(self):
        if len(self._dataset) > 0: # 수치형 변환
            from sklearn.preprocessing import LabelEncoder
            
            le = LabelEncoder()
            org_columns = self._dataset.columns
        
            for c in org_columns:
                if not('float' in str(self._dataset.dtypes[c]) or 'int' in str(self._dataset.dtypes[c])) :
                    self._dataset.rename(columns = {c : c+'_old'}, inplace = True)
                    self._dataset[c] = le.fit_transform(self._dataset[c+'_old']) # 문자형 수치형 index로 변환
                    print('[%s] 컬럼을 수치형으로 변환 했습니다.<br>'%(c))
                    labels = str(le.classes_).replace("' '",",").replace("'","")
                    print('%s 값을 수치형(0~%d)으로 변환 했습니다.<br>'%(labels, len(le.classes_)-1))
            self._dataset = self._dataset[org_columns]
        
    def _split_x_y(self):
        # X 컬럼 유무 확인
        for x_col in self.param.independent_values:
            if x_col not in self._dataset.columns:
                raise Exception(f'데이터셋에 독립변수 {x_col} 컬럼이 누락되었습니다.')
        x = self._dataset[self.param.independent_values]

        # Y 컬럼 유무 확인
        if not self.is_predict:
            if self.param.dependent_value not in self._dataset.columns:
                raise Exception(f'데이터셋에 종속변수 "{self.param.dependent_value}" 컬럼이 누락되었습니다.')
            else:
                y = self._dataset[self.param.dependent_value]
        elif self.param.dependent_value not in self._dataset.columns:
            y = None     
        else:
            if self.param.dependent_value not in self._dataset.values:
                y = None
            else:
                y = self._dataset[self.param.dependent_value]
                
        return x, y
    
    def _scaling_data(self, x):
        std_scaler = StandardScaler()
        scaled_x = std_scaler.fit(x)
        scaled_x_train = scaled_x.transform(x)
        dump(std_scaler, open('./std_scaler.pkl', 'wb'))
        std_x_train = pd.DataFrame(scaled_x_train, columns=x.columns, index=x.index)
        # print(f'std_x_train.columns:\n{std_x_train.columns}')
        # print(f'std_x_train:\n{std_x_train}')
        return std_x_train
        
    def _split_train_val(self, std_x_train, y):
        x_train, x_val, y_train, y_val = train_test_split(std_x_train, y, test_size=0.3, random_state=1)
        # print(f'x_train:\n{x_train}')
        # print(f'y_train:\n{y_train}')
        return x_train, x_val, y_train, y_val
    
    
