class FitResult:
    def __init__(self):
        self.x_train = None
        self.y_train = None
        self.x_val = None
        self.y_val = None
        self.y_pred = None
        
        
        self.xgbmodel_info = None
        self.rdfmodel_info = None
        self.features_importances = None
        self.features_importances_img_path = None
        self.loss_img_path = None
        self.eval_report = None
        self.roc_curves_img_path = None
        # self.confusion_matrix = None
        self.confusion_matrix_img_path = None

class PredictResult:
    def __init__(self):
        self.x_test = None
        self.y_test = None
        self.y_pred = None
        self.x = None
        self.y = None
        
        self.data_info = None
        self.eval_report = None
        # self.confusion_matrix =  None
        self.confusion_matrix_img_path = None
        self.pred_results = None
        self.tf_proportion = None
