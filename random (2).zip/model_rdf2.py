# -*- coding: utf-8 -*-
import sys
import os
import warnings
import pickle
import joblib
import argparse
import cvthtml
import copy

import seaborn as sns
import pandas as pd
import numpy as np
from matplotlib import pyplot as plt
from sklearn.metrics import confusion_matrix
from sklearn.metrics import accuracy_score, precision_score, recall_score, f1_score, roc_auc_score, roc_curve
from sklearn.ensemble import RandomForestClassifier
from sklearn.model_selection import train_test_split

from model_param import ModelParam
from preprocess import Preprocess
from results import FitResult, PredictResult
from collections import OrderedDict

class Randomforest:
    _MODEL_PATH = None
    _RDF_MODEL = None
    # _IMAGE_PATH = './media/model/XGB/{0}'
    _IMAGE_PATH = './{0}'
    _IMPORTANCE_IMG_PATH = _IMAGE_PATH.format('feature_importances_rdf.png')
    _Loss_IMG_PATH = _IMAGE_PATH.format('Loss_rdf.png')
    _CONF_MATRIX_FIT_IMG_PATH = _IMAGE_PATH.format('confusion_matrix_fit_rdf.png')
    _CONF_MATRIX_PRED_IMG_PATH = _IMAGE_PATH.format('confusion_matrix_pred_rdf.png')
    _ROC_IMG_PATH = _IMAGE_PATH.format('ROC_Curvers_rdf.png')

    # 폰트 설정
    plt.rc('font', family='Malgun Gothic')
    # matplotlib.rcParams['font.family'] = 'AppleGothic'
    plt.rcParams['font.size'] = 10  # 글자 크기
    plt.rcParams['axes.unicode_minus'] = False  # 한글 폰트 사용 시, 마이너스 글자가 깨지는 현상을 해결

    def __init__(self, param):
        self.param = param
        self.param: ModelParam
        self.param.set_rdf()

        self.data_path = self.param.dataset_path
        self._target_data_path = None
        self.org_data_set = None
        self.x_train = None
        self.y_train = None
        self.x_val = None
        self.y_val = None
        self.x = None
        self.y = None
        self._fit_result = None
        self._fit_result: FitResult
        self._pred_result = None
        self._pred_result: PredictResult

    def preprocess(self):
        """ 2단계: 데이터 전처리 후 모델 학습
            _preprocess: 데이터 전처리
            _fit: 모델 학습

        Returns:
            FitResult(): 모델학습 결과
        """
        # 데이터 불러오기
        dataset = pd.read_csv(self.param.data_path)
        # 데이터 전처리
        self._preprocess(dataset)
        # 모델 학습
        result_fit = self._fit()

        return result_fit

    def predict(self, target_data_path):
        """4단계: 검사데이터를 받아서 전처리 후 학습된 모델에 적용
            _preprocess: 데이터 전철
            _predict: 모델 예측

        Args:
            target_data_path (_type_): _description_

        Returns:
            _type_: _description_
        """
        self._target_data_path = target_data_path
        self.org_data_set = pd.read_csv(self._target_data_path)
        dataset = self.org_data_set.copy()
        self._preprocess(dataset, True)
        result_predict = self._predict()

        return result_predict

    def _preprocess(self, dataset: pd.DataFrame(), is_predict=False):
        """입력된 데이터의 전처리 프로세스
            2단계, 4단계에서 모두 실행
            result는 X, y 분리된 데이터셋 (4개 or 2개)

        Args:
            dataset (pd.DataFrame): 사용자가 업로드한 데이터 파일. X, y 값을 가짐
            is_fit (bool, optional): 모델 fit 여부를 결정. Defaults to True.
        """
        prep = Preprocess(self.param, dataset, is_predict)
        if not is_predict:
            self._fit_result = prep.process()
        else:
            self._pred_result = prep.pred_process()

    def _save_model(self, model,model_path):

        joblib.dump(model, model_path)

    def _load_model(self, model_path):
         return joblib.load(model_path)

    def mk_error_graph(self):

        RANDOM_STATE = 123

        ensemble_clfs = [
            ("RandomForestClassifier, max_features='하한'",
             RandomForestClassifier(warm_start=True, oob_score=True,
                                    max_features="sqrt",
                                    random_state=RANDOM_STATE)),
            ("RandomForestClassifier, max_features='오차율'",
             RandomForestClassifier(warm_start=True, max_features='log2',
                                    oob_score=True,
                                    random_state=RANDOM_STATE)),
            ("RandomForestClassifier, max_features=상한",
             RandomForestClassifier(warm_start=True, max_features=None,
                                    oob_score=True,
                                    random_state=RANDOM_STATE))
        ]

        # Map a classifier name to a list of (<n_estimators>, <error rate>) pairs.
        error_rate = OrderedDict((label, []) for label, _ in ensemble_clfs)

        # Range of `n_estimators` values to explore.
        min_estimators = 15
        max_estimators = 500

        for label, clf in ensemble_clfs:
            for i in range(min_estimators, max_estimators + 1):
                clf.set_params(n_estimators=i)
                clf.fit(self.x_train, self.y_train)
                # Record the OOB error for each `n_estimators=i` setting.
                oob_error = 1 - clf.oob_score_
                error_rate[label].append((i, oob_error))

        # Generate the "OOB error rate" vs. "n_estimators" plot.
        for label, clf_err in error_rate.items():
            xs, ys = zip(*clf_err)
            plt.plot(xs, ys, label=label)

        plt.xlim(min_estimators, max_estimators)
        plt.xlabel("n_estimators")
        plt.ylabel("error rate")
        plt.legend(loc="upper right")
        plt.title("오차율 그래프")
        plt.savefig(self._Loss_IMG_PATH)
        plt.show()



    def _fit(self):
        self.x_train, self.y_train = self._fit_result.x_train, self._fit_result.y_train
        self.x_val, self.y_val = self._fit_result.x_val, self._fit_result.y_val

        self._RDF_MODEL = RandomForestClassifier(n_estimators=self.param.n_estimators,oob_score=True)

        self._RDF_MODEL.fit(self.x_train, self.y_train)

        # self._XGB_MODEL.fit(self.x_train, self.y_train,
        #                     eval_metric='mae', eval_set=[(self.x_val, self.y_val)],
        #                     early_stopping_rounds=20)
        leav_idx = self._RDF_MODEL.apply(self.x_train)


        nTerminal = np.array([len(set(li)) for li in leav_idx])
        percent_25 = np.quantile(nTerminal, .25)#1분위수
        percent_50 = np.quantile(nTerminal, .5) #중분위수
        percent_75 = np.quantile(nTerminal, .75)  #3분위수

        self._save_model(self._RDF_MODEL, self.param.model_path)

        y_pred = self._RDF_MODEL.predict(self.x_val)

        ## RDFoost 모델 정보 -> 이 항목으로 완성해주세요
        
        data = {
            '구분': ['나무유형','독립변수','종속변수','트리 모델의 갯수','분할당 변수 시도 횟수', 'Out of Bag 추정된 오차율', '나무크기 터미널 노드 : 1분위',
                   '나무크기 터미널 노드 : 중위', '나무크기 터미널 노드 : 3분위', '난수 시작 값'],
            '내용': []
        }
        indenpendent = ','.join(self.param.independent_values)
        data['내용'].append('분류')
        data['내용'].append(indenpendent)
        data['내용'].append(self.param.dependent_value)
        data['내용'].append(self.param.n_estimators)
        data['내용'].append(self.param.max_features)
        data['내용'].append(self._RDF_MODEL.oob_score_)
        data['내용'].append(percent_25)
        data['내용'].append(percent_50)
        data['내용'].append(percent_75)
        data['내용'].append(self.param.random_state)

        df_rdfmodel_info = pd.DataFrame(data)
        ## 예측 변수표 추가 부탁드립니다.
        
        '''
        여기는 R로 구현이 되어야할 것 같습니다.
        '''


        # 변수중요도 표
        df_importances = pd.DataFrame(columns=['변수', '변수중요도'])
        df_importances['변수'] = self.x_train.columns
        df_importances['변수중요도'] = self._RDF_MODEL.feature_importances_
        df_importances = df_importances.sort_values(by='변수중요도', ascending=False)

        # 변수중요도 시각화
        fi = pd.Series(self._RDF_MODEL.feature_importances_, index=self.x_train.columns).sort_values(ascending=False)
        plot = sns.scatterplot(x=fi, y=fi.index)
        # plt.grid(True)
        plot.set_title("변수중요도")
        plt.savefig(self._IMPORTANCE_IMG_PATH)
        plt.clf()
        plt.cla()
        # plt.show()

        ## 혼동행렬  -> 계층 오차(%) 추가해주세요
        self._plot_confusion_matrix(self.y_val, y_pred, True, self._CONF_MATRIX_FIT_IMG_PATH)


        ## 오차율 그래프 -> 추가해주세요

        self.mk_error_graph()


        # dataframe for result
        self._fit_result.y_pred = y_pred
        self._fit_result.rdfmodel_info = df_rdfmodel_info
        self._fit_result.features_importances = df_importances
        self._fit_result.features_importances_img_path = self._IMPORTANCE_IMG_PATH
        self._fit_result.loss_img_path = self._Loss_IMG_PATH
        self._fit_result.roc_curves_img_path = self._ROC_IMG_PATH
        self._fit_result.eval_report = self._classification_report(self.y_val, y_pred)
        self._fit_result.confusion_matrix_img_path = self._CONF_MATRIX_FIT_IMG_PATH

        return self._fit_result

    def _predict(self):
        self.x_test, self.y_test = self._pred_result.x_test, self._pred_result.y_test
        self._RDF_MODEL = self._load_model(self.param.model_path)
        y_pred = self._RDF_MODEL.predict(self.x_test)
        df_y_pred = pd.DataFrame(y_pred, columns=['예측결과'], index=self.x_test.index)
        print(df_y_pred)
        df_y_pred.columns = ['예측결과']

        if self.y_test is None:
            # y_test 값이 없을 때
            # Randomforest 검사대상 Data 정보
            df_testdata = self._pred_result.x

            # 예측결과표
            df_results = self.org_data_set
            print(df_results)
            df_pred_results = df_results.join(df_y_pred)
            print(df_pred_results)

            # df_pred_results = df_pred_results.astype({'예측결과' : 'bool'})

            # PredictResult 값 채우기
            self._pred_result.y_pred = y_pred
            self._pred_result.data_info = df_testdata.head(5)  ## RandomForest 검사대상 Data 정보 -> 처음 입력받은 데이터 그대로 출력되어야 합니다.
            self._pred_result.eval_report = None
            self._pred_result.confusion_matrix_img_path = None
            self._pred_result.pred_results = df_pred_results.head(100)
            self._pred_result.tf_proportion = None
        else:
            # y_test 값이 있을 때
            # RandomForest 검사대상 Data 정보
            df_testdata = self._pred_result.x
            # 혼동행렬
            self._plot_confusion_matrix(self.y_test, y_pred, True, self._CONF_MATRIX_PRED_IMG_PATH)

            # 예측결과표
            df_x_results = self._pred_result.x_test
            df_y_results = self._pred_result.y_test


            df_results = df_x_results.join(df_y_results, how='inner')
            df_results['예측결과'] = y_pred
            # df_pred_results = df_results.astype({'양불판정결과': 'bool', '예측결과' : 'bool'})

            # Test Data T/F 비율
            total_count = len(df_results)
            len_true = len(df_results[df_results['예측결과'] == 1])
            len_false = len(df_results[df_results['예측결과'] == 0])
            true_proportion = len_true / len(df_results['예측결과']) * 100
            false_proportion = len_false / len(df_results['예측결과']) * 100

            data = {'총 개수(개)': [],
                    '1의 비율(%)': [],
                    '0의 비율(%)': []
                    }
            data['총 개수(개)'].append(total_count)
            data['1의 비율(%)'].append(true_proportion)
            data['0의 비율(%)'].append(false_proportion)

            df_tf_proportion = pd.DataFrame(data)
            df_tf_proportion = df_tf_proportion.round(2)

            # PredictResult 값 채우기
            self._pred_result.y_pred = y_pred
            self._pred_result.data_info = df_testdata.head()
            self._pred_result.eval_report = self._classification_report(self.y_test, y_pred)
            self._pred_result.confusion_matrix_img_path = self._CONF_MATRIX_PRED_IMG_PATH
            self._pred_result.pred_results = df_results.head(100)
            self._pred_result.tf_proportion = df_tf_proportion

        return self._pred_result

    def _classification_report(self, y, y_pred):
        df = pd.DataFrame(columns=['구분', '결과값'])
        df['구분'] = ['정확도', '정밀도', '재현율', 'f1-score']
        df['결과값'] = [accuracy_score(y, y_pred), precision_score(y, y_pred), recall_score(y, y_pred),
                     f1_score(y, y_pred)]

        return df.round(2)

    def _plot_confusion_matrix(self, y, y_pred, to_save=False, img_path='./'):
        cm = confusion_matrix(y, y_pred)
        sns.heatmap(cm, annot=True, fmt='d', cmap='Blues').set(title='혼동행렬')

        plt.xlabel('실제값')
        plt.ylabel('예측값')
        plt.xticks([0.5, 1.5], ['0', '1'])
        plt.yticks([0.5, 1.5], ['0', '1'])
        if to_save:
            plt.savefig(img_path)
            plt.clf()
            plt.cla()
        else:
            plt.clf()
            plt.cla()
            plt.show()

def main():
    pass

if __name__ == '__main__':
    main()
# ## 1. 학습시 인자 전달
# ### 1.1 main에서 argv로 전달
#      필수 항목 input_path(String), model_path(String)
#      옵션 : target_name(String) : 설정하지 않으면 마지막 컬럼으로 자동 선택됨.
# ### 1.2 출력 항목 학습된 모델, 인코더, target_column, #Dict으로 구성된 Pickle 파일
#      ex)python3 ./Randomforest_v4.py --fun fit -input_path dataset/credit.xlsx -x_names Age,Income,Credit_cards,Education,Car_loans -target_name Credit_rating   -numoftree 500 -random_start 123 -model_path dataset/credit.rds
#      ex)python3 ./Randomforest_v4.py --fun fit -input_path dataset/사출_labeled_data.csv -x_names Age,Income,Credit_cards,Education,Car_loans -target_name Credit_rating   -numoftree 500 -random_start 123 -model_path dataset/credit.rds

'''
예제1
echo "----Randomforest Training---"
python3 Randomforest_v4.py --fun fit -input_path dataset/사출_labeled_data.csv -x_names Injection_Time,Filling_Time,Plasticizing_Time,Cycle_Time,Clamp_Close_Time,Cushion_Position,Switch_Over_Position,Plasticizing_Position,Clamp_Open_Position,Max_Injection_Speed -target_name PART_NAME -numoftree 500 -random_start 123 -model_path dataset/rf_사출_data > output/rf_사출.html
echo "----Randomforest Model Test---"
python3 Randomforest_v4.py --fun predict -input_path dataset/사출_labeled_data_sample_30.csv -model_path dataset/rf_사출_data > output/rf_test.html

예제2
echo "----Randomforest Training---"
python3 Randomforest_v4.py --fun fit -input_path dataset/credit.xlsx -x_names Age,Income,Credit_cards,Education,Car_loans -target_name Credit_rating \
-numoftree 500 -random_start 123 -model_path dataset/credit > output/credit_modeling.html

echo "----Randomforest Model Test---"
python3 Randomforest_v4.py --fun predict -input_path dataset/credit.xlsx -model_path dataset/credit > output/model_test_credit.html

예제3

echo "----Randomforest Training---"
python3 Randomforest_v4.py --fun fit -input_path dataset/rf_ds/3.pasteurizer_INSP.csv -x_names MIXA_PASTEUR_STATE,MIXB_PASTEUR_STATE,MIXA_PASTEUR_TEMP,MIXB_PASTEUR_TEMP -target_name INSP \
-numoftree 10 -random_start 123 -model_path dataset/rf_pasteurizer.pkl > output/pasteurizer_modeling.html

echo "----Randomforest Model Test---"
python3 Randomforest_v4.py --fun predict -input_path dataset/rf_ds/3.pasteurizer_INSP_test.csv -model_path dataset/rf_pasteurizer.pkl > output/pasteurizer_test.html

'''

