# -*- coding: utf-8 -*-
import sys

import pandas as pd
import os
from sklearn.ensemble import RandomForestClassifier
from sklearn.model_selection import train_test_split
from matplotlib import pyplot as plt
import warnings
from sklearn.metrics import accuracy_score,plot_confusion_matrix
import pickle
import argparse
import cvthtml
from rpy2.robjects import r, pandas2ri
import pandas as pd
import numpy as np
import copy
import logging

logging.basicConfig(filename='randomforest.log',
                format = '%(asctime)s:%(levelname)s:%(message)s',
                datefmt = '%m/%d/%Y %I:%M:%S %p')
logger = logging.getLogger("randomforest")
logger.setLevel(logging.DEBUG)

pd.options.display.float_format = '{:0,.3f}'.format

pandas2ri.activate()
r('library(randomForest)')
r('library(readxl)')
r('''
    rf_count_terminal_nodes = function(rf) {
  if (!"randomForest" %in% installed.packages()) {
    stop(paste0("rf_count_terminal_nodes requires the randomForest package.",
                'Please run install.packages("randomForest")'))
  }
  terminal_nodes = rep(NA, rf$forest$ntree)

  # TODO: vectorize
  for (tree_i in 1:rf$forest$ntree) {
    # Extract a single tree from the forest.
    tree = randomForest::getTree(rf, tree_i, labelVar = F)

    # Terminal nodes have 0 as their split variable.
    # NOTE: if we turn labelVar on, split variables with have NAs instead of 0s.
    sum_na = sum(tree[, "split var"] == 0)

    terminal_nodes[tree_i] = sum_na
  }

  return(terminal_nodes)
}''')
class Randomforest():
    _MODEL_PATH = None
    # _IMAGE_PATH = './media/model/XGB/{0}'
    _IMAGE_PATH = './{0}'
    _IMPORTANCE_IMG_PATH = _IMAGE_PATH.format('feature_importances.png')
    _CONF_MATRIX_FIT_IMG_PATH = _IMAGE_PATH.format('confusion_matrix_fit.png')
    _CONF_MATRIX_PRED_IMG_PATH = _IMAGE_PATH.format('confusion_matrix_pred.png')
    _ROC_IMG_PATH = _IMAGE_PATH.format('ROC_Curvers.png')

    # 폰트 설정
    plt.rcParams['font.family'] = 'NanumGothic'
    # matplotlib.rcParams['font.family'] = 'AppleGothic'
    plt.rcParams['font.size'] = 10  # 글자 크기
    plt.rcParams['axes.unicode_minus'] = False  # 한글 폰트 사용 시, 마이너스 글자가 깨지는 현상을 해결



    def __init__(self):
        pass
    
    def fit(self, input_path, x_name_list, target_name, numtree, random_start, model_path):
        """Randomforest 학습 시작
        Args:
            input_path : 학습에 사용할 입력 파일명
            x_name_list : 학습에 사용할 컬럼 목록
            target_name : 종속변수로 사용할 컬럼
            numtree : 생성할 트리의 갯수
            random_start : 램덤 시드
            model_path : 저정될 모델 경로
        """
        _, file_type = os.path.splitext(input_path)
        if 'xls' in file_type:
            input_df = pd.read_excel(input_path)
            input_df = input_df.fillna('0.0')
        elif 'csv':
            input_df = pd.read_csv(input_path)
            input_df = input_df.fillna('0.0')
        else:
            print('unknown format')
        targe_values = input_df[target_name].unique().tolist()
        col_names = input_df.columns.to_list()
        # Target이 미설정인 경우 마지막 컬럼으로 자동 설정
        if target_name is None:
            target_name = col_names[-1]
        # TargetCoumn을 문자열로 강제 설정
        for idx, col_name in enumerate(col_names):
            if col_name == target_name:
                input_df[col_name] = input_df[col_name].astype('str')
        plt.rc('font', family='NanumGothic')
        #plt.rc('font', family='DejaVu Sans')
        
        ### 3.Pit
        x_list = x_name_list#input_df.columns.to_list()
        
        x_list.sort()
        if  target_name in x_list:
            x_list.remove(target_name)
        # X=input_df[x_list]
        # y=input_df[target_name]
        #print('<pre>')
        """
        #학습할 데이터 로드.
        """
        try:
            logger.debug('randomforest:load training data')
            r('set.seed(' + str(random_start) + ')')
            if('xls' in file_type):
                r("df <- read_excel('" + input_path + "')")
            else:
                r("df <- read.csv('" + input_path + "')")
        except Exception as e:
            logger.error(str(e))
            sys.exit()

        r('sn <- sample(1:nrow(df), size = nrow(df)*1.0)')
        r('df$'+target_name+' = factor(df$'+target_name+')')
        r('trainData <- df[sn,]')
        r('testData <- df[-sn,]')
        mtry = 3
        rf_formula = target_name+'~'
        for x_name in x_name_list:
            rf_formula += x_name + '+'
            
#       print(rf_formula)
        rf_formula = rf_formula[:-1]
        """
        ***Randomforest 학습 수행
        """
        try:
            logger.debug('randomforest:fit')
            r('credit_rf <- randomForest('+rf_formula+',data=trainData,ntree=' + str(numtree) + ',proximity=TRUE, importance=TRUE)')
        except Exception as e:
            logger.error(str(e))

        try:
            logger.debug('randomforest:save model rds')
            r('saveRDS(credit_rf,file = "{m_path}")'.format(m_path=model_path))
            logging.debug('randomforest:save model pkl')
            with open(model_path + '.pkl', 'wb') as f:
                var_dict = {'input': x_name_list,
                            'output': target_name}
                pickle.dump(var_dict, f)
        except Exception as e:
            logger.error(str(e))
            sys.exit()

        try:
            logger.debug('randomforest:get summary')
            model_summary = r('credit_rf')
            performance = str(model_summary[0]).split('\n')
            oob_error_rate = performance[7].replace(' ', '').split(':')[1].replace('%', '')
            var_tried = performance[5].replace(' ', '').split(':')[1]
        except Exception as e:
            logger.error(str(e))
            sys.exit()

        try:
            logger.debug('randomforest:get quantile')
            nTerminal = r('rf_count_terminal_nodes(credit_rf)')
            percent_25 = np.quantile(nTerminal, .25)#1분위수
            percent_50 = np.quantile(nTerminal, .5) #중분위수
            percent_75 = np.quantile(nTerminal, .75)  #3분위수
        except Exception as e:
            logger.error(str(e))
            sys.exit()

        #print("#램덤 포레스트 요약")
        #print('종속변수:%s'%(target_name))
        #print('예측자:%s' % (','.join(x_name_list)))
        #print('나무:%s' % (numtree))
        #print('분할당 변수 시도 회수:%d' % (int(var_tried)))
        #print('Out of Bag 추정된 오차율:%0.3f'%(float(oob_error_rate)/100))
        #print('나무 크기 터미널 노드 1분위수 %d'%(int(percent_25)))
        #print('나무 크기 터미널 노드 중분위수 %d'% (int(percent_50)))
        #print('나무 크기 터미널 노드 3분위수 %d'% (int(percent_75)))
        #print('난수시작값:%s' % (random_start))
        
        plt.rcParams["font.family"] = 'NanumGothic'
        plt.rcParams['axes.unicode_minus'] = False
        """
        ***학급 결과 변수 중요도 획득
        """
        try:
            logger.debug('randomforest:get importance')
            importance = r('importance(credit_rf)')
            importance_df = pd.DataFrame({'MeanDecreaseAccuracy': importance[:, 2],
                                          'MeanDecreaseGini': importance[:, 3]})
            importance_df = importance_df.sort_values(by=['MeanDecreaseGini'],axis=0, ascending=False)
            column_list = x_list#input_df.columns.to_list()
            if target_name in column_list:
                column_list.remove(target_name)
            for idx, column_name in enumerate(column_list):
                importance_df.rename({idx: column_name}, axis='index', inplace=True)
            importance_gini = importance_df['MeanDecreaseGini'].to_frame()
        except Exception as e:
            logger.error(str(e))
            sys.exit()
        
        #print('#변수 중요도')
        imp_values = []
        imp_names = []
        for col_name in importance_gini.index.to_list():
        #    print('%s:%0.3f'%(col_name, importance_df['MeanDecreaseGini'][col_name]))
            imp_values.append(importance_df['MeanDecreaseGini'][col_name])
            imp_names.append(col_name)
        
        #print('예측자 변수 사용 구매빈도')
        """
        ***학급 결과 예측자 변수 사용 구매 빈도 획득
        """
        try:
            logger.debug('randomforest:get varUsed')
            var_count_alltree = r('varUsed(credit_rf, by.tree = FALSE, count=TRUE)')
            var_count_list = var_count_alltree.tolist()
            if target_name in var_count_list:
                var_count_list.remove(target_name)
        except Exception as e:
            logger.error(str(e))
            sys.exit()

        #for ci, name in enumerate(x_list):
        #    print('%s %d' % (x_list[ci], var_count_list[ci]))
        """
        ***학급 결과 예측 오차율 획득
        """
        try:
            logger.debug('randomforest:get error rate')
            summary = r('credit_rf')[0]
        except Exception as e:
            logger.error(str(e))
            sys.exit()

        element_list = str(summary).split('\n')
        error_rate = float(element_list[7].replace(' ', '').split(':')[1].replace('%', ''))
        # print("#예측 오류율")
        # print('Error Rate:%0.3f <br>' % (error_rate))
        # print("#예측 정확도")
        # print('정확도:%0.3f <br>' % (100 - error_rate))
        #print("#예측의 혼돈 행렬")
        try:
            logger.debug('randomforest:get confusion matrix')
            confusion = r('credit_rf$confusion')
            confusion_df = pd.DataFrame({0: confusion[:, 0],
                                         1: confusion[:, 1],
                                         '계층오차율': confusion[:, 2]})
            confusion_df["합계"] = confusion_df.sum(axis=1)

            # 계층오차율은 합치지 않음...
            confusion_df['합계'][0] = confusion_df['합계'][0] - confusion_df['계층오차율'][0]
            confusion_df['합계'][1] = confusion_df['합계'][1] - confusion_df['계층오차율'][1]
            rcnt = len(confusion)
            conf_df = pd.DataFrame(confusion)
            cols = list(conf_df.columns)
            cols.pop()

            conf_df['합계'] = conf_df[cols].sum(axis=1)
            conf_df = conf_df.append(pd.Series(conf_df.sum(axis=0),name="합계"))

            conf_df.rename(columns = {conf_df.columns[rcnt] : '계층오차(%)'}, inplace = True)
            conf_df['계층오차(%)']['합계'] = (conf_df[0][1] + conf_df[1][0]) / conf_df['합계']['합계']

            cols = list(conf_df.columns)
            cols[rcnt] = '합계'
            cols[rcnt+1] = '계층오차(%)'
            print(confusion_df)

        except Exception as e:
            logger.error(str(e))
            sys.exit()

        #혼동행렬
        t4 = conf_df.to_html(columns=cols , justify='center').replace('<th></th>','<th rowspan=2 colspan=2>구분</th><th colspan='+str(rcnt+2)+'>예측</th></tr><tr>').replace('<tbody>\n    <tr>', '<tbody>\n    <tr><th rowspan='+str(rcnt+1)+'>학습</th>', 1)
        fp = t4.rfind('<td>')
        #마지막 셀 진하게..
        t4 = t4[:(fp-1)]+'<td style="border: 3px solid black; font-weight:bold; font-size:13pt; color:darkblue">'+t4[(fp+4):]
        #print(conf_df.to_html().replace('<th></th>','<th rowspan=2 colspan=2>구분</th><th colspan='+str(rcnt+2)+'>예측</th></tr><tr>').replace('<tbody>\n    <tr>', '<tbody>\n    <tr><th rowspan='+str(rcnt+1)+'>학습</th>', 1))
        confusion_df = confusion_df.append(confusion_df.sum(numeric_only=True), ignore_index=True)
        idx = confusion_df.shape[0]
        confusion_df.rename({idx - 1: '열 총계'}, axis='index', inplace=True)
        columns_name = confusion_df.columns.to_list()
        #for i, columns in confusion_df.iterrows():
        #    for ci, column in enumerate(columns):
        #        if str(i) == '열 총계' and columns_name[ci] == '계층오차율':
        #            print('%s,%s:%0.3f' % (i, columns_name[ci], error_rate/100))
        #        else:
        #            print('%s,%s:%0.3f' % (i, columns_name[ci], column))
        #print("#오차율")
        """
        ***학급 결과 예측 오차율을 플롯팅
        """
        try:
            logger.debug('randomforest:error rate plot')
            min_tree = 0
            r_lang_rf_error_obb_y = r('credit_rf$err.rate[,1]')
            r_lang_rf_error_1_y = r('credit_rf$err.rate[,2]')
            r_lang_rf_error_2_y = r('credit_rf$err.rate[,3]')
            max_error_obb = r_lang_rf_error_obb_y.max()
            max_error_1_y = r_lang_rf_error_1_y.max()
            max_error_2_y = r_lang_rf_error_2_y.max()
            y_max = np.max([max_error_obb, max_error_1_y, max_error_2_y])
            r_error_graph_x = range(0, len(r_lang_rf_error_obb_y))
            #fig = plt.figure(figsize=(10, 6))
            plt.title('')
            plt.subplots_adjust(top=1)
            plt.xlim(min_tree, numtree)  # 변수에 의한 오차율 그래프 축 이름 범위 설정.
            #plt.ylim(0.13, y_max)
            plt.xlabel('나무 수(개)')
            plt.ylabel('오차(%)')
            #20201212 수정 사항 반영 시작
            plt.plot(r_error_graph_x, r_lang_rf_error_obb_y, 'g', label='오차율')
            plt.plot(r_error_graph_x, r_lang_rf_error_1_y, 'r', label='상한')
            plt.plot(r_error_graph_x, r_lang_rf_error_2_y, 'b', label='하한')
            plt.legend(bbox_to_anchor=(0.8, 0.8, 0.2, 0.2))
            # 20201212 수정 사항 반영 종료
            imgstr = cvthtml.plt2html()
            plt.cla()
        except Exception as e:
            logger.error(str(e))
            sys.exit()

        #print('</pre>')
        #print(imgstr)
        #print('<pre>')
        #print('#변수 중요도 도표')
        #fig2 = plt.figure(figsize=(8, 6))
        """
        ***변수 중요도를 플롯팅
        """
        try:
            logger.debug('randomforest:plot var importance')
            re_imp_names = copy.deepcopy(imp_names)
            for idx, cls in enumerate(re_imp_names):
                rename = ''
                for nidx, ch in enumerate(cls):
                    if nidx % 10 == 0 and nidx > 0:
                        rename += '\n'
                    rename += ch
                re_imp_names[idx] = rename

            plt.figure(figsize=(10, 6))
            scatter = plt.scatter(imp_values, re_imp_names)
            ax = scatter.axes
            ax.invert_yaxis()
            # plt.yticks(rotation=45)
            plt.title('변수 중요도')
            plt.xlabel('MeanDecreaseGini')
            def get_mx_lbl_length(labelList):
                mx_length = 0
                for lbl in labelList:
                    if len(str(lbl)) > mx_length:
                        mx_length  = len(str(lbl))
                return mx_length

            mx_lbl_length = 0.1 + (get_mx_lbl_length(col_names) / 500)
            plt.subplots_adjust(top=0.998, left=mx_lbl_length, right=0.9)
            # plt.subplots_adjust(left=0.2)
            plt.plot()
            imgstr2 = cvthtml.plt2html()
            plt.cla()
        except Exception as e:
            logger.error(str(e))
            sys.exit()

        #print('</pre>')
        """
        ***최종 분석 결과를 포맷팅하여 출력함.
        """
        try:
            logger.debug('randomforest:print final result')
            file = open("/python/data/rf_result.html", "r", encoding='utf8')
            # file = open("rf_result.html", "r", encoding='utf8')
            templete = file.read()
            file.close()

            templete = templete.replace("{t1-1}",target_name)
            templete = templete.replace("{t1-2}",', '.join(x_name_list))
            templete = templete.replace("{t1-3}",'%s'%(numtree))
            templete = templete.replace("{t1-4}",'%d'%(int(var_tried)))
            # templete = templete.replace("{t1-5}",'%0.0f%%'%(round(float(oob_error_rate))))
            templete = templete.replace("{t1-5}", '%0.3f%%' % (float(error_rate)))
            templete = templete.replace("{t1-6}",'%d'%(int(percent_25)))
            templete = templete.replace("{t1-7}",'%d'%(int(percent_50)))
            templete = templete.replace("{t1-8}",'%d'%(int(percent_75)))
            templete = templete.replace("{t1-9}",'%s'%(random_start))
            templete = templete.replace("{t1-10}",'%0.3f%%'%((100 - error_rate)))

            for i in range(0,10):
                if(i<len(imp_names)):
                    templete = templete.replace("{t2-"+str(i)+"0}",'')
                    templete = templete.replace("{t2-"+str(i)+"1}",imp_names[i])
                    templete = templete.replace("{t2-"+str(i)+"2}",'{:,.0f}'.format(imp_values[i]))
                else:
                    templete = templete.replace("{t2-"+str(i)+"0}",'display:none')

            for i in range(0,10):
                if(i<len(imp_names)):
                    templete = templete.replace("{t3-"+str(i)+"0}",'')
                    templete = templete.replace("{t3-"+str(i)+"1}",x_list[i])
                    templete = templete.replace("{t3-"+str(i)+"2}",'{:,.0f}'.format(var_count_list[i]))
                else:
                    templete = templete.replace("{t3-"+str(i)+"0}",'display:none')

            # 혼동 행렬
            templete = templete.replace("{t4}",t4)
            templete = templete.replace("{plot-1}",imgstr)
            templete = templete.replace("{plot-2}",imgstr2)
            print(templete)
        except Exception as e:
            logger.error(str(e))
            sys.exit()

    def predict(self, input_path, model_path):
        logger.debug('run inference')
        try:
            logger.debug('randomforest:pkl model loading')
            logger.debug('input path ' + input_path)
            logger.debug('model path ' + model_path)
            with open(model_path + '.pkl', 'rb') as f:
                var_dict = pickle.load(f)
                var_list = var_dict['input']
                target_name = var_dict['output']
        except Exception as e:
            logger.error(str(e))
            sys.exit()

        _, file_type = os.path.splitext(input_path)

        try:
            logger.debug('randomforest:target data loading')
            if ('xls' in file_type):
                r("df <- read_excel('" + input_path + "')")
            else:
                r("df <- read.csv('" + input_path + "')")
        except Exception as e:
            logger.error(str(e))
            sys.exit()

        try:
            logger.debug('randomforest:rds model loading')
            forest = r("forest<-readRDS('" + model_path + "')")
            df = r('df')
            if target_name in df.columns.to_list():
                var_list.append(target_name)
        except Exception as e:
            logger.error(str(e))
            sys.exit()

        df = df[var_list]
        try:
            logger.debug('randomforest:run inference')
            y_pred_decision = r('predicted <- predict(forest, df)')
            pred_prob_matrix = r('predicted <- predict(forest, df, type="prob")')
            pred_prob_df = pd.DataFrame.from_records(pred_prob_matrix)
            pred_prob_df['모형을 통하여 예측한 결괏값'] = y_pred_decision.tolist()
            colnames = r('colnames(predicted)')
            col_id_name = {}
            for idx, name in enumerate(colnames.tolist()):
                col_id_name[idx] = '모형이 {clsnm}(으)로 예측한 확률'.format(clsnm=name)
            pred_prob_df = pred_prob_df.rename(columns=col_id_name)
            pred_prob_df = pred_prob_df.rename(columns=col_id_name)
            pred_prob_df.index = np.arange(1, len(df) + 1)
            pred_prob_df['모형을 통하여 예측한 결괏값'] = y_pred_decision.tolist()
            cols = pred_prob_df.columns.tolist()
            cols = cols[-1:] + cols[:-1]
            pred_prob_df = pred_prob_df[cols]
            for col in pred_prob_df.columns.tolist():
                df[col] = pred_prob_df[col].tolist()
        except Exception as e:
            logger.error(str(e))
            sys.exit()

        try:
            logger.debug('randomforest:report inference result')
            print(df.to_html(index=True, justify='center').replace("<th></th>", "<th>구분</th>"))
        except Exception as e:
            logger.error(str(e))
            sys.exit()

# ## 1. 학습시 인자 전달
# ### 1.1 main에서 argv로 전달
#      필수 항목 input_path(String), model_path(String)
#      옵션 : target_name(String) : 설정하지 않으면 마지막 컬럼으로 자동 선택됨.
# ### 1.2 출력 항목 학습된 모델, 인코더, target_column, #Dict으로 구성된 Pickle 파일
#      ex)python3 ./Randomforest_v4.py --fun fit -input_path dataset/credit.xlsx -x_names Age,Income,Credit_cards,Education,Car_loans -target_name Credit_rating   -numoftree 500 -random_start 123 -model_path dataset/credit.rds
#      ex)python3 ./Randomforest_v4.py --fun fit -input_path dataset/사출_labeled_data.csv -x_names Age,Income,Credit_cards,Education,Car_loans -target_name Credit_rating   -numoftree 500 -random_start 123 -model_path dataset/credit.rds

'''
예제1
echo "----Randomforest Training---"
python3 Randomforest_v4.py --fun fit -input_path dataset/사출_labeled_data.csv -x_names Injection_Time,Filling_Time,Plasticizing_Time,Cycle_Time,Clamp_Close_Time,Cushion_Position,Switch_Over_Position,Plasticizing_Position,Clamp_Open_Position,Max_Injection_Speed -target_name PART_NAME -numoftree 500 -random_start 123 -model_path dataset/rf_사출_data > output/rf_사출.html
echo "----Randomforest Model Test---"
python3 Randomforest_v4.py --fun predict -input_path dataset/사출_labeled_data_sample_30.csv -model_path dataset/rf_사출_data > output/rf_test.html

예제2
echo "----Randomforest Training---"
python3 Randomforest_v4.py --fun fit -input_path dataset/credit.xlsx -x_names Age,Income,Credit_cards,Education,Car_loans -target_name Credit_rating \
-numoftree 500 -random_start 123 -model_path dataset/credit > output/credit_modeling.html

echo "----Randomforest Model Test---"
python3 Randomforest_v4.py --fun predict -input_path dataset/credit.xlsx -model_path dataset/credit > output/model_test_credit.html

예제3

echo "----Randomforest Training---"
python3 Randomforest_v4.py --fun fit -input_path dataset/rf_ds/3.pasteurizer_INSP.csv -x_names MIXA_PASTEUR_STATE,MIXB_PASTEUR_STATE,MIXA_PASTEUR_TEMP,MIXB_PASTEUR_TEMP -target_name INSP \
-numoftree 10 -random_start 123 -model_path dataset/rf_pasteurizer.pkl > output/pasteurizer_modeling.html

echo "----Randomforest Model Test---"
python3 Randomforest_v4.py --fun predict -input_path dataset/rf_ds/3.pasteurizer_INSP_test.csv -model_path dataset/rf_pasteurizer.pkl > output/pasteurizer_test.html

'''

if __name__ == '__main__':
    """
    Randomforest 시작.
    동작에 필요한 각종 인자를 처리한다. 
    """
    try:
        parser = argparse.ArgumentParser(prog='argparser')
        parser.add_argument('--fun',action='store_true', help='RandomForestRegression help')
        subparsers = parser.add_subparsers(help='sub-command help', dest='fun')

        parser_fit = subparsers.add_parser('fit', help='fit help')
        parser_fit.add_argument('-input_path', type=str, help='input path help',required=True)
        parser_fit.add_argument('-model_path', type=str, help='model path help', required=True)
        parser_fit.add_argument('-x_names', type=str, help='x name help', required=True)
        parser_fit.add_argument('-target_name', type=str, help='target name help', required=True)
        parser_fit.add_argument('-numoftree', type=int, help='number of trees help', required=False)
        parser_fit.add_argument('-random_start', type=int, help='random numer help', required=False)

        # "predict" 명령을 위한 파서를 만듭니다
        parser_fit = subparsers.add_parser('predict', help='predict help')
        parser_fit.add_argument('-input_path', type=str, help='test file input path help', required=True)
        parser_fit.add_argument('-model_path', type=str, help='model path help', required=True)

        args = parser.parse_args()
        logger.debug(str(args))
        if 'fit' == args.fun:
            input_path = args.input_path
            model_path = args.model_path
            random_start = args.random_start
            numtree = args.numoftree
            rfr = Randomforest()
            x_name_list = args.x_names.split(',')
            rfr.fit(input_path=input_path, x_name_list=x_name_list, target_name=args.target_name, model_path=model_path, numtree=numtree, random_start=random_start)

        elif 'predict' == args.fun:
            rfr = Randomforest()
            input_path = args.input_path
            model_path = args.model_path
            rfr.predict(input_path=input_path, model_path=model_path)
        else:
            logger.error('Unknown arguments')
    except Exception as e:
        logger.error(str(e))

