# from results import FitResult
from model_rdf2 import Randomforest
from model_param import ModelParam


def main():
    param = ModelParam()
    
    param.user_id = 13
    param.data_path = './data/interrojo_사출성형기_train.csv'
    param.independent_values = ['사출시간','사출압력','사출속도','금형곡률','쿠션계량','냉각수온도','냉각시간']
    param.dependent_value = '양불판정결과'
    param.model_path = './trained_rdf_model.joblib'
    
    model = Randomforest(param)
    result = model.preprocess()
    # result: FitResult
    # 화면 출력.
    data_path = './data/interrojo_사출성형기_test.csv'
    result_predict = model.predict(data_path)
    # 화면 출력
    
    print("end")
    
if __name__ == '__main__':
    main()