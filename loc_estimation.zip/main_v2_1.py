################################################################################################################

import os
import os.path as osp
import sys
import matplotlib.pyplot as plt
import h5py
import matplotlib
import argparse

from collections import defaultdict
import numpy as np
import pandas as pd
import dtw

import warnings
from Model_learner import Learn_module


### global var ###

warnings.filterwarnings("ignore", "(?s).*MATPLOTLIBDATA.*", category=UserWarning)
warnings.simplefilter(action='ignore', category=UserWarning)

DEVICE = Learn_module.set_device()

pd.set_option('display.max_columns', 500)

matplotlib.use('TkAgg')
sys.path.append(osp.join(osp.dirname(osp.abspath(__file__)), '..'))
################################################################################################################

data_folder = 'data'

files = [f for f in os.listdir(data_folder) if osp.isdir(osp.join(data_folder, f)) and not f.endswith('_paired')]


outfolder = osp.abspath('./magnet_viz')

calculate_average = False

if not osp.exists(outfolder):
    os.makedirs(outfolder)

def mk_fig():
    if not calculate_average:
        fig, ax = plt.subplots(1, 1, figsize=(20, 12))
    return ax

################################################################################################################

def change_cf(ori, vectors):
    """
    Euler-Rodrigous formula v'=v+2s(rxv)+2rx(rxv)
    :param ori: quaternion [n]x4
    :param vectors: vector nx3
    :return: rotated vector nx3
    """
    assert ori.shape[-1] == 4
    assert vectors.shape[-1] == 3

    if len(ori.shape) == 1:
        ori = np.repeat([ori], vectors.shape[0], axis=0)
    q_s = ori[:, :1]
    q_r = ori[:, 1:]

    tmp = np.cross(q_r, vectors)
    vectors = np.add(np.add(vectors, np.multiply(2, np.multiply(q_s, tmp))), np.multiply(2, np.cross(q_r, tmp)))
    return vectors

################################################################################################################

def get_window_signal(magnet_input, window, hop_len=0, threshold=0.7):
    out_sig = magnet_input
    dim = out_sig.shape[1]
    x_size = window*dim
    all_len = out_sig.shape[0]

    split_num = all_len // window + 1
    s , n = 0, window
    return_dict = {}
    same_win = []
    different_win = []

    for i in range(split_num):
        cut_sig = out_sig[s:n, :]
        x_data = cut_sig.reshape(1,-1)

        if cut_sig.shape[0] >= window*threshold:
            same_win.append(cut_sig) if cut_sig.shape[0] == window else different_win.append(cut_sig)
        n += hop_len
        s, n = n, n+window
        if x_data.shape[1] != x_size:
            continue

        x_set = x_data if i == 0 else np.vstack([x_set, x_data])

    return_dict['same_win'] = np.asarray(same_win)
    return_dict['diff_win'] = np.asarray(different_win)
    return_dict['x_dset'] = x_set

    return return_dict

################################################################################################################
def softmax(x):
    e_x = np.exp(x - np.max(x))
    return e_x / e_x.sum()

def df_to_csv(dataframe, file_name):
    if os.path.exists(file_name) == False:
        dataframe.to_csv(file_name)

def cal_dtw(train_magnet, test_magent):

    n = test_magent
    dtw_list = []
    prob_list = []
    for m in train_magnet:
        dist_n = dtw.dtw(m, n, keep_internals=True).distance
        inverse_dist = 1 / dist_n
        prob_list.append(inverse_dist)
        dtw_list.append(dist_n)

    probs = softmax(x=prob_list)
    return dtw_list, probs

def main(set_window = 20):
    sframe, eframe = 0, -1

    average_vector = np.asarray([2.37530259, -18.93004064, -48.90972049])
    max_magnitude = np.linalg.norm(average_vector)
    i = 1
    magnet_dict = dict()
    magnet_dict['dd'] = defaultdict(list)

    avg_vectors = []
    DEFAULT_PLOTLY_COLORS = ['red', 'orange', 'yellow', 'green', 'cyan', 'navy', 'purple']

    label = ['x', 'y', 'z']
    for data in files:
        with h5py.File(osp.join(data_folder, data, "data.hdf5"), 'r') as f:
            pos = np.copy(f["pose/tango_pos"])[sframe:eframe]
            ori = np.copy(f["pose/tango_ori"])[sframe:eframe]
            magnet = np.copy(f["synced/magnet"])[sframe:eframe]

            if not calculate_average:
                glob_magnet = (change_cf(ori, magnet) - average_vector) / max_magnitude
                #glob_magnet = change_cf(ori, magnet) / max_magnitude
                #glob_magnet = change_cf(ori, magnet)
                print(data)
                # ax.scatter(pos[:, 1], pos[:, 0], c=glob_magnet[:, i], vmin=-1.0, vmax=1.0, cmap='rainbow', alpha=0.4,s=.2)

            else:
                glob_magnet = change_cf(ori, magnet)
                median_vector = np.median(glob_magnet, axis=0)
                avg_vectors.append(median_vector)

            max_m, mid_m = max(np.linalg.norm(glob_magnet, axis=1)), np.median(np.linalg.norm(glob_magnet, axis=1))
    ################################################################################################################

        if calculate_average:
            avg_vectors = np.asarray(avg_vectors)
            avg = np.average(avg_vectors, axis=0)
            print(avg)

        else:
            window = set_window

            windowing_train = get_window_signal(magnet_input=glob_magnet, window=window, hop_len=0)
            windowing_test = get_window_signal(magnet_input=glob_magnet, window=window, hop_len=10)

            magnet_train = pd.DataFrame(windowing_train['same_win'].reshape(window, -1))
            magnet_test = pd.DataFrame(windowing_test['same_win'].reshape(window, -1))
            magnet_train = magnet_train.values.T.reshape(3, -1, 20)
            magnet_test = magnet_test.values.T.reshape(3,-1, 20)
            train_y = pos[window-1::window][:, :2]

            ## magnet axis 0 ##
            s = magnet_test.shape[1]
            for i in range(s):
                x_test = magnet_test[0, i, :]
                x_train = magnet_train[0, :, :]
                x_dists, x_probs = cal_dtw(train_magnet=x_train, test_magent=x_test)
                x_dists, x_probs = np.array(x_dists), np.array(x_probs)

                y_test = magnet_test[1, i, :]
                y_train = magnet_train[1, :, :]
                y_dists, y_probs = cal_dtw(train_magnet=y_train, test_magent=y_test)
                y_dists, y_probs = np.array(y_dists), np.array(y_probs)

                z_test = magnet_test[2, i, :]
                z_train = magnet_train[2, :, :]
                z_dists, z_probs = cal_dtw(train_magnet=z_train, test_magent=z_test)
                z_dists, z_probs = np.array(z_dists), np.array(z_probs)

                all_dis = np.vstack([x_dists, y_dists, z_dists])
                x_prob = np.argmax(x_probs)
                y_prob = np.argmax(y_probs)
                z_prob = np.argmax(z_probs)

                all_dis = np.sum(all_dis, axis=0)

                min_indices = np.argmin(all_dis)

                print('min_dist',min_indices)
                print('max_prob_X',x_prob)
                print('max_prob_Y',y_prob)
                print('max_prob_Z',z_prob)
                print('pred_loc',train_y[min_indices])



if __name__ == '__main__':
    parser = argparse.ArgumentParser(description='DTW Location Estimation')
    parser.add_argument("--window", type=int, default=20)

    args = parser.parse_args()
    main(set_window=args.window)