class ModelParam:
    
    def __init__(self):
        self.data_path = './datasets/dataset_train.csv'
        self.independent_values = ['사출시간','사출압력','사출속도','금형곡률','쿠션계량','냉각수온도','냉각시간']
        self.dependent_value = '양불판정결과'
        self.model_path = './trained_model.joblib'
        
        self.user_id = None
        self.dataset_path = None
        self.independent_values = list()
        self.dependent_value = None
        self.remove_null = True
        self.remove_outlier = True
        self.n_estimators = 500
        self.eta = 0.3
        self.k = 2
        self.subsample = 0.5