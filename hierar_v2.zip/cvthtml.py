#!/usr/bin/env python
# coding: utf-8
from PIL import Image
import base64
from io import BytesIO
import numpy as np
from matplotlib import pyplot as plt
from matplotlib.backends.backend_agg import FigureCanvasAgg as FigureCanvas

def getimgstr(img):
    img = Image.fromarray(img)
    buffered = BytesIO()
    img.save(buffered, format="JPEG")
    retstr = 'data:image/jpeg;base64,' + base64.b64encode(buffered.getvalue()).decode('utf-8')
    return retstr

def fig2data ( fig ):
    """
    @brief Convert a Matplotlib figure to a 4D numpy array with RGBA channels and return it
    @param fig a matplotlib figure
    @return a numpy 3D array of RGBA values
    """
    # draw the renderer
    fig.canvas.draw ( )
 
    # Get the RGBA buffer from the figure
    w,h = fig.canvas.get_width_height()
    buf = np.fromstring ( fig.canvas.tostring_argb(), dtype=np.uint8 )
    buf.shape = ( w, h,4 )
 
    # canvas.tostring_argb give pixmap in ARGB mode. Roll the ALPHA channel to have it in RGBA mode
    buf = np.roll ( buf, 3, axis = 2 )
    return buf
	
def fig2img ( fig ):
    """
    @brief Convert a Matplotlib figure to a PIL Image in RGBA format and return it
    @param fig a matplotlib figure
    @return a Python Imaging Library ( PIL ) image
    """
    # put the figure pixmap into a numpy array
    buf = fig2data ( fig )
    w, h, d = buf.shape
    return Image.fromstring( "RGBA", ( w ,h ), buf.tostring( ) )
	
def plt2html():
    buffered = BytesIO()
    #plt.rc('font', family='NanumGothic')
    plt.rcParams["font.family"] = 'Malgun Gothic'
    plt.rcParams['axes.unicode_minus'] = False
    plt.savefig(buffered, format="PNG")
    data_base64 = base64.b64encode(buffered.getvalue()).decode('utf-8')
	
    #plt.savefig("test.png")
	
    return '<img src="data:image/jpeg;base64,' + data_base64 + '">'
	
#plt.plot([1,2,3], [1,4,9])
#plt.plot([2,3,4],[5,6,7])
#plt.xlabel('Sequence')
#plt.ylabel('Time(secs)')
#plt.title('Experiment Result')
#plt.legend(['Mouse', 'Cat'])

#html = plt2img()
#print(html)