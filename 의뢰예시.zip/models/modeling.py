import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
from sklearn.svm import SVR
from sklearn.ensemble import RandomForestRegressor

from xgboost import XGBRegressor
from lightgbm import LGBMRegressor
from sklearn.multioutput import MultiOutputRegressor


def set_xgb(params=None):
    xgb_model = XGBRegressor(**params) if params is not None else XGBRegressor()  # parameter 수정 된 파라미터가 있을 시 해당 parameter 적용, 아니면 그냥 기본 모델 적용
    return xgb_model

def set_rf(params=None):
    rf_model = RandomForestRegressor(**params) if params is not None else RandomForestRegressor()  # parameter 수정 된 파라미터가 있을 시 해당 parameter 적용, 아니면 그냥 기본 모델 적용
    return rf_model

def set_svr(params=None):
    svr_model = SVR(**params) if params is not None else SVR()  # parameter 수정 된 파라미터가 있을 시 해당 parameter 적용, 아니면 그냥 기본 모델 적용
    return svr_model

def set_lgb(params=None):
    lgb_model = LGBMRegressor(**params) if params is not None else LGBMRegressor()
    return lgb_model





class Execute_ml():
    def __init__(self, args):

        ml_models = {'xgbm': set_xgb, 'lgbm': set_lgb, 'rdf':set_rf, 'svm':set_svr}
        self.model = ml_models[args.model]
        self.mode = args.mode
        self.result_plot = args.result_plot
        self.param_tune =  args.param_tune
    def parallel_runner(self, p, data_dict):
        out = p.map(self.run_ml, [(k, v) for k, v in data_dict.items()])

        if out[0] is not None:
            out_df = pd.DataFrame()
            for o in out:
                out_df = pd.concat([out_df, o])

            out_df['year'] = out_df['year'].round(0).astype(int)
            out_df['month'] = out_df['month'].round(0).astype(int)

            out_df['Date'] = out_df['year'].astype(str).str.cat(out_df['month'].astype(str), sep='-')
            out_df['Date'] = pd.to_datetime(out_df['Date'],format='%Y-%m')

            out_df.drop(['class','year','month'],axis=1, inplace=True)
            out_df = out_df[['Date', 'Code', 'Rx']]
            out_df.sort_values(['Date'], inplace=True)
            out_df.reset_index(drop=True, inplace=True)

            out_df['Date'] = out_df['Date'].dt.strftime('%Y-%m')

            out_df.to_csv('sales_prediction.csv',index=False)

    def set_new_value(self, data_in, column, rowsize, y_value, norm_param):
        new_test = pd.DataFrame(data_in.reshape(-1, len(column))[-rowsize:], columns=column)
        y_value = y_value*norm_param.loc['Rx', 'std'] + norm_param.loc['Rx', 'mean']
        new_test = new_test*norm_param['std'] + norm_param['mean']
        new_value = list(new_test.iloc[-1, :].values)
        new_value[-1], new_value[1] = new_value[-1] + 1, y_value
        new_test.loc[len(new_test)] = new_value
        new_test = new_test.iloc[1:, :]

        return new_test


    def run_ml(self, parallel_input):
        try:
            label = parallel_input[0]
            dd = parallel_input[1]

            train_x, train_y = dd['train']
            test_x, test_y = dd['test']
            winsize = dd['winsize']
            col = dd['columns']

            pred_month = dd['pred_month']
            norm = dd['norm_param']

            model_xgb = MultiOutputRegressor(self.model()).fit(train_x, train_y)

            if self.mode== 'test':
                y_pred = model_xgb.predict(test_x)
                plt.plot(y_pred, 'r', label='y_pred')
                plt.plot(test_y, 'b', label='y_true')
                plt.title(label+f' , rmse : {np.round(np.sqrt(np.mean(np.square(y_pred-test_y))), 3)}')
                plt.legend(loc='best')
                plt.show()
                return None

            elif self.mode=='inference':

                new_test = self.set_new_value(data_in=test_x, column=col, rowsize=winsize, y_value=test_y[-1][0], norm_param=norm) # 초기값 setting
                output = []

                for m in range(pred_month):
                    tmp_code = new_test['Code'].values
                    tmp_class = new_test['class'].values
                    new_test = (new_test-norm['mean']) / norm['std']
                    new_test['Code'] = tmp_code
                    new_test['class'] = tmp_class

                    new_input = new_test.values.reshape(-1, winsize * len(col))
                    y_pred = model_xgb.predict(new_input)

                    new_test = self.set_new_value(data_in=new_input, column=col, rowsize=winsize, y_value=y_pred[0][0], norm_param=norm)
                    output.append(new_test.iloc[-1, :].values)

                output_df = pd.DataFrame(np.asarray(output),columns=col)

                if self.result_plot:
                    middle = len(dd['test_org'])
                    all_range = list(range(middle + output_df.shape[0]))
                    plt.plot(all_range[:middle], dd['test_org'], 'r')
                    plt.plot(all_range[middle:], output_df.Rx, 'b')
                    plt.suptitle(f'{label}')
                    plt.show()

                output_df['Code'] = label
                return output_df
        except Exception as e:
            print('grid cv :',e)

