import argparse

def set_config(argv=None):
    parser = argparse.ArgumentParser(
        description='Pharm-Wholesale Data Learner')
    parser.add_argument("--cfg_path",type=str,default="./config/config.json")
    # parser.add_argument("--save_",type=str,default="./config/config.json")
    parser.add_argument("--mode",type=str,default="test",
                        help='test, inference -> test mode 설정 시 test data에 대한 Visualization 진행됨.')
    parser.add_argument("--model",type=str,default="xgbm",
                        help='xgbm, lgbm, rdf, svm, lstm')
    parser.add_argument("--result_plot",type=bool,default=False,
                        help='True or False, inference result plot setting')
    parser.add_argument("--param_tune",type=bool,default=False,
                        help='True or False, ml model parameter tune setting')
    parser.set_defaults(cfg_path='./config/config.json')

    return parser