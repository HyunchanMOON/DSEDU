import torch
import torch.nn as nn
import torch.optim as optim
import numpy as np
import argparse
import time
from sklearn.metrics import r2_score
from torch.autograd import Variable
from sklearn.preprocessing import MinMaxScaler
from sklearn.linear_model import LinearRegression
import numpy as np
import matplotlib.pyplot as plt
import scipy.io
import time
import os


class CNN(nn.Module):
    def __init__(self, data_length, numout):
        super(CNN, self).__init__()
        self.data_length = data_length
        self.conv = nn.Sequential(
            nn.Conv1d(1, 64, kernel_size=50, stride=1, padding=25),
            nn.ReLU(),
            nn.Conv1d(64, 64, kernel_size=50, stride=1, padding=25),
            nn.ReLU(),
            nn.Conv1d(64, 64, kernel_size=50, stride=1, padding=25),
            nn.ReLU(),
            nn.Conv1d(64, 64, kernel_size=50, stride=1, padding=25),
            nn.ReLU(),
            nn.Conv1d(64, 64, kernel_size=50, stride=1, padding=25),
            nn.ReLU()
        )

        # n_channels = self.conv(torch.empty(1, input_size, feature_size)).size(-1)
        self.output_layer = nn.Sequential(nn.Linear(64, 50),
                                          nn.ReLU(),
                                          nn.Linear(50, 50),
                                          nn.ReLU(),
                                          nn.Linear(50, numout))

    def forward(self, x_in):
        x = x_in.permute(0, 2, 1)
        x = self.conv(x)
        x = x[:, :, :self.data_length]
        x = x.permute(0, 2, 1)
        out = self.output_layer(x)
        return out



class DeepPhyLSTM:
    # Initialize the class
    def __init__(self, output_y, input_x, Phi_t):
        super(DeepPhyLSTM, self).__init__()

        self.output_y = output_y

        self.input_x = input_x
        self.Phi_t = Phi_t

        # placeholders for data
        self.learning_rate = 0.001 # 초기 학습률 지정
        self.output_y = torch.from_numpy(output_y).float()
        self.input_x = torch.from_numpy(input_x).float()
    
        self.model = CNN(data_length=self.input_x.shape[1], numout=self.output_y.shape[2])
        self.output_y.requires_grad = True
        self.input_x.requires_grad = True
        

        self.optimizer_Adam = optim.Adam(self.model.parameters(), lr=self.learning_rate)


    def net_structure(self, input_x):

        pred_y = self.model(input_x)
        Phi_ut = self.Phi_t.reshape(1, self.output_y.shape[1], self.output_y.shape[1])
        Phi_ut = Phi_ut.repeat(self.output_y.shape[0], axis=0)
        
        pred_y_t = torch.matmul(torch.tensor(Phi_ut, dtype=torch.float32), pred_y)
        pred_y_tt = torch.matmul(torch.tensor(Phi_ut, dtype=torch.float32), pred_y_t)

        return pred_y, pred_y_t, pred_y_tt

    def criterion(self, target_in, pred_tt_in, pred_in):
        return torch.mean(torch.square(target_in - pred_tt_in)) + torch.mean(torch.square(pred_in[:,:,0:10]))

    def train(self, num_epochs, learning_rate, bfgs, batch_size = 64):
        Loss = []
        self.pred_y, self.pred_y_t, self.pred_y_tt = self.net_structure(self.input_x)
        
        self.learning_rate = learning_rate
        self.model.train()

        for epoch in range(num_epochs):
            N = self.output_y.shape[0]
            for it in range(0, N, batch_size):
                self.optimizer_Adam.zero_grad()
                self.pred_y, self.pred_y_t, self.pred_y_tt = self.net_structure(self.input_x)
                loss = self.criterion(self.output_y, self.pred_y_tt, self.pred_y)
                loss.backward()
                self.optimizer_Adam.step()
                if it % (10*batch_size) == 0:
                        print('Epoch: %d, It: %d, Loss: %.3e,  Learning Rate: %.3e'
                          %(epoch, it/batch_size, loss.item(), learning_rate))

            Loss.append(loss.item())

        if bfgs == 1:
            # use L-BFGS optimizer
            self.optimizer_lbfgs = optim.LBFGS(self.model.parameters(), lr=self.learning_rate, max_iter=10, max_eval=50000, history_size=50, 
                                               line_search_fn='strong_wolfe')
            def closure():
                self.optimizer_lbfgs.zero_grad()
                self.pred_y, self.pred_y_t, self.pred_y_tt = self.net_structure(self.input_x)
                loss = self.criterion(self.output_y, self.pred_y_tt, self.pred_y)
                loss.backward()
                return loss

            self.optimizer_lbfgs.step(closure)

            print('LBFGS Loss :', self.criterion(self.output_y, self.pred_y_tt, self.pred_y).item())
            Loss.append(self.criterion(self.output_y, self.pred_y_tt, self.pred_y).item())
            

        return Loss

    def predict(self, test_in):
        self.model.eval()
        test_in = torch.from_numpy(test_in).float()
        test_in.requires_grad = False

        pred_y, pred_y_t, pred_y_tt = self.net_structure(test_in)

        pred_y = pred_y.detach().numpy()
        pred_y_t = pred_y_t.detach().numpy()
        pred_y_tt = pred_y_tt.detach().numpy()

        return pred_y, pred_y_t, pred_y_tt



class Base_Model:
    # Initialize the class
    def __init__(self, output_y, input_x, Phi_t):
        super(Base_Model, self).__init__()

        self.output_y = output_y
        self.input_x = input_x
        self.Phi_t = Phi_t

        # placeholders for data
        self.learning_rate = 0.001 # 초기 학습률 지정
        self.output_y = torch.from_numpy(self.output_y).float()
        self.input_x = torch.from_numpy(self.input_x).float()
        
        self.model = CNN(data_length=self.input_x.shape[1], numout=self.output_y.shape[2])
        self.output_y.requires_grad = True
        self.input_x.requires_grad = True
    
        self.optimizer_Adam = optim.Adam(self.model.parameters(), lr=self.learning_rate)


    def net_structure(self, input_x):

        pred_y = self.model(input_x)
        Phi_ut = self.Phi_t.reshape(1, self.output_y.shape[1], self.output_y.shape[1])
        Phi_ut = Phi_ut.repeat(self.output_y.shape[0], axis=0)

        pred_y_reshape = torch.matmul(torch.tensor(Phi_ut, dtype=torch.float32), pred_y)

        return pred_y_reshape

    def criterion(self, target_in, pred_in):
        return torch.mean(torch.square(target_in - pred_in))

    def run_train(self, num_epochs, learning_rate, bfgs, batch_size = 64):
        Loss = []
        
        self.pred_y = self.net_structure(self.input_x)
        self.learning_rate = learning_rate
        self.model.train()

        for epoch in range(num_epochs):
            N = self.output_y.shape[0]
            for it in range(0, N, batch_size):
                self.optimizer_Adam.zero_grad()
                self.pred_y = self.net_structure(self.input_x)
                loss = self.criterion(self.output_y, self.pred_y)
                loss.backward()
                self.optimizer_Adam.step()
                if it % (10*batch_size) == 0:
                        print('Epoch: %d, It: %d, Loss: %.3e,  Learning Rate: %.3e'
                          %(epoch, it/batch_size, loss.item(), learning_rate))

            Loss.append(loss.item())

        if bfgs == 1:
            # use L-BFGS optimizer
            self.optimizer_lbfgs = optim.LBFGS(self.model.parameters(), lr=self.learning_rate, max_iter=10, max_eval=50000, history_size=50, 
                                               line_search_fn='strong_wolfe')
            def closure():
                self.optimizer_lbfgs.zero_grad()
                self.pred_y = self.net_structure(self.input_x)
                loss = self.criterion(self.output_y,  self.pred_y)
                loss.backward()
                return loss

            self.optimizer_lbfgs.step(closure)

            print('LBFGS Loss :', self.criterion(self.output_y,  self.pred_y).item())
            Loss.append(self.criterion(self.output_y, self.pred_y).item())
            
        return Loss

    def predict(self, test_in):
        self.model.eval()
        test_in = torch.from_numpy(test_in).float()
        test_in.requires_grad = False

        test_pred = self.net_structure(test_in)
        test_pred = test_pred.detach().numpy()

        return test_pred



if __name__ == "__main__":

    parser = argparse.ArgumentParser(
        description='ag2utt forecast')

    parser.add_argument("--data_path", type=str, default="D:/MHC/2022/개인자료/kmong/battery_health_등푸른비행선/tf to torch/PhyCNN/data/data_exp.mat",
                        help="ag2utt data path ")

    parser.add_argument("--target_type", type=str, default="target_Xdd_tf", help="target data type, target_X_tf, target_Xd_tf, target_Xdd_tf")
    
    parser.add_argument("--limit_len", type=int, default=2500)

    parser.add_argument("--d_time", type=float, default=0.02)
    
    parser.add_argument("--train_ratio", type=float, default=0.8)

    parser.add_argument("--dof", type=int, default=0)

    target_pred_dict = {"target_X_tf":"target_pred_X_tf","target_Xd_tf":"target_pred_Xd_tf","target_Xdd_tf":"target_pred_Xdd_tf"}

    args = parser.parse_args()

    dataDir = args.data_path
    data_len = args.limit_len
    d_time = args.d_time
    train_ratio = args.train_ratio
    target_type = args.target_type

    # load data
    mat = scipy.io.loadmat(dataDir)

    size = mat['input_tf'].shape[1]

    size_limit = data_len if size > data_len else size

    dim = mat[target_type].ndim

    input_data = mat['input_tf'][:, 0:size_limit]

    target_data =  mat[target_type][:, 0:size_limit] if dim ==2 else mat[target_type][:, 0:size_limit, :]

    input_data = input_data.reshape([input_data.shape[0], input_data.shape[1], 1]) if input_data.ndim ==2 else input_data

    target_data = target_data.reshape([target_data.shape[0], target_data.shape[1], 1]) if target_data.ndim ==2 else target_data

    dt = mat['time'][0,1] - mat['time'][0,0] if 'time' in mat.keys() else d_time

    # finite difference
    n = size_limit
    phi1 = np.concatenate([np.array([-3 / 2, 2, -1 / 2]), np.zeros([n - 3, ])])
    temp1 = np.concatenate([-1 / 2 * np.identity(n - 2), np.zeros([n - 2, 2])], axis=1)
    temp2 = np.concatenate([np.zeros([n - 2, 2]), 1 / 2 * np.identity(n - 2)], axis=1)
    phi2 = temp1 + temp2
    phi3 = np.concatenate([np.zeros([n - 3, ]), np.array([1 / 2, -2, 3 / 2])])

    Phi_t = 1 / dt * np.concatenate([np.reshape(phi1, [1, phi1.shape[0]]), phi2, np.reshape(phi3, [1, phi3.shape[0]])], axis=0)

    # Training Data
    N_train = int(input_data.shape[0]*train_ratio)

    input_train = input_data[0:N_train]
    target_train = target_data[0:N_train]

    model = Base_Model(target_train, input_train, Phi_t)

    phycnn = DeepPhyLSTM(target_train, input_train, Phi_t)

    phycnn_Loss = phycnn.train(num_epochs=50, learning_rate=1e-3, bfgs=1, batch_size=N_train)

    Base_Loss = model.run_train(num_epochs=50, learning_rate=1e-3, bfgs=1, batch_size=N_train)


    plt.figure()
    plt.plot(np.log(Base_Loss), label='loss')
    plt.plot(np.log(phycnn_Loss), label='phycnn_loss')

    plt.legend()


    dof = 0

    # Prediction performance
    ag_pred = mat['input_pred_tf']  # ag, ad, av

    target_pred = mat[target_pred_dict[target_type]]

    ag_pred = ag_pred[:, 0:size_limit]

    target_pred =  target_pred[:, 0:size_limit] if dim ==2 else target_pred[:, 0:size_limit, :]

    ag_pred = ag_pred.reshape([ag_pred.shape[0], ag_pred.shape[1], 1]) if ag_pred.ndim ==2 else ag_pred

    target_pred = target_pred.reshape([target_pred.shape[0], target_pred.shape[1], 1]) if target_pred.ndim ==2 else target_pred

    X_pred = ag_pred
    y_pred_ref = target_pred

    model.output_y = y_pred_ref
    phycnn.output_y = y_pred_ref

    y_pred = model.predict(ag_pred)
    pred_y, pred_y_t, pred_y_tt = phycnn.predict(ag_pred)

    if target_pred_dict[target_type] == "target_pred_X_tf":
        phycnn_pred_y = pred_y
    elif target_pred_dict[target_type] == "target_pred_Xd_tf":
        phycnn_pred_y = pred_y_t
    else:
        phycnn_pred_y = pred_y_tt

    # Prediction

    for ii in range(len(y_pred_ref)):
        plt.figure()
        plt.plot(y_pred_ref[ii, :, dof], 'gray',linewidth=2, label='True')
        plt.plot(y_pred[ii, :, dof], 'r.-', markersize=3, label='Predict')
        plt.plot(phycnn_pred_y[ii, :, dof], 'k-',  label='Predict Phycnn')
        plt.title('Prediction_result')
        plt.legend()

    R_Phycnn = []
    R2 = []

    for ii in range(len(y_pred_ref)):
        # reg1 = LinearRegression().fit(y_pred_ref[ii, :, 0:1], y_pred[ii, :, 0:1])
        r2 = r2_score(y_pred_ref[ii, :, 0:1],  y_pred[ii, :, 0:1])
        r_phy = r2_score(y_pred_ref[ii, :, 0:1],  phycnn_pred_y[ii, :, 0:1])
        R2.append(r2)
        R_Phycnn.append(r_phy)




    plt.figure()
    plt.bar(range(len(R2)), R2,  alpha=0.5, label='Predict Base')
    plt.bar(range(len(R_Phycnn)), R_Phycnn,  alpha=0.5, label='Predict Phycnn')
    plt.grid(axis='y', alpha=0.75)
    plt.xlabel('Value')
    plt.title('R2')
    plt.legend()
    ax = plt.gca()
    ax.invert_xaxis()

    plt.show()
