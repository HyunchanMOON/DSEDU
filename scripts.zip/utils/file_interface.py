import json
import os, shutil
import yaml
import pickle5 as pickle


def read_json_file(file_path, logger):
    try:
        with open(file_path, 'r', encoding='UTF-8') as f:

            json_object = json.load(f)
            logger.debug("Load json file %s", f)
    
        return json_object

    except Exception as e:
        print("Error in [read_json_file]", e)
        logger.error("Error in [read_json_file] %s", e, exc_info=True)

def read_yaml_file(file_path, logger):
    try:

        with open(file_path,'r', encoding='UTF-8') as f:

            yaml_object = yaml.load(f, Loader=yaml.FullLoader)
            logger.debug("Load yaml file %s", f)
            
        return yaml_object

    except Exception as e:
        print("Error in [read_yaml_file]", e)
        logger.error("Error in [read_yaml_file] %s", e, exc_info=True)

def read_pickle_file(file_path, logger):
    try:
        with open(file_path, 'rb') as f:

            pickle_object = pickle.load(f)
            logger.debug("Load pickle file %s", f)

        return pickle_object

    except Exception as e:
        print("Error in [read_pickle_file]", e)
        logger.error("Error in [read_pickle_file] %s", e, exc_info=True)

def chk_dir(file_path):
    return True if os.path.exists(file_path) is True else False

def make_dir(file_path, logger):
    os.mkdir(file_path)
    logger.debug('make dir %s', file_path)

def del_dir(target_dir, logger):
    try:
        if target_dir is not None:
            shutil.rmtree(target_dir)
            logger.info('del dir %s', target_dir)
        else:
            print('Skip del dir, does not exist target path')
            logger.info('Skip del dir, does not exist target path')

    except Exception as e:
        print("Error in [del_dir] %s", e, exc_info=True)
        logger.error("Error in [del_dir] %s", e, exc_info=True)
        
def del_path(file_path, logger):
    os.remove(file_path)
    logger.debug("del path %s", file_path)

def rename_path(src_path, dst_path, logger):
    os.rename(src=src_path, dst=dst_path)
    logger.debug("Rename Path : %s -> %s", src_path, dst_path)

def copy_path(src, dst, logger):
    try:
        shutil.copyfile(src, dst)
        logger.debug("copy file from %s to %s", src, dst)
    except Exception as e:
        logger.error("Error in [copy_path] %s", e, exc_info=True)

def copy2_path(src, dst, logger):
    try:
        shutil.copy2(src, dst)
        logger.debug("copy file from %s to %s", src, dst)
    except Exception as e:
        logger.error("Error in [copy2_path] %s", e, exc_info=True)


def copy_dir(src, dst, logger):
    try:
        shutil.copytree(src, dst)
        logger.debug("copy directory from %s to %s", src, dst)
    except Exception as e:
        logger.error("Error in [copy_dir] %s", e, exc_info=True)
        
def move_file(src, dst, logger):
    try:
        shutil.move(src, dst)
        logger.debug("move directory from %s to %s", src, dst)
    except Exception as e:
        logger.error("Error in [move_file] %s", e, exc_info=True)