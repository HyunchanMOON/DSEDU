import pandas as pd
import matplotlib.pyplot as plt
from xgboost import XGBClassifier
from sklearn.svm import SVC

from .nn_model import CNNModel


def set_xgb(params=None):
    xgb_model = XGBClassifier(**params) if params is not None else XGBClassifier()  # parameter 수정 된 파라미터가 있을 시 해당 parameter 적용, 아니면 그냥 기본 모델 적용
    return xgb_model

def set_svc(params=None):
    svr_model = SVC(**params) if params is not None else SVC()  # parameter 수정 된 파라미터가 있을 시 해당 parameter 적용, 아니면 그냥 기본 모델 적용
    return svr_model

def set_cnn(input_size, num_out, feature_size):

    cnn_model = CNNModel(input_size=input_size, num_out=num_out, feature_size=feature_size)
    return cnn_model