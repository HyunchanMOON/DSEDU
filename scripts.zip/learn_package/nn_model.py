import torch
import torch.nn as nn
import torch.nn.functional as F

class CNNModel(nn.Module):
    def __init__(self,input_size, num_out, feature_size):
        super(CNNModel, self).__init__()
        self.conv1 = nn.Conv2d(input_size, 32, kernel_size=(1, 9), stride=(1, 2), padding=(0, 0))
        self.conv2 = nn.Conv2d(32, 64, kernel_size=(1, 3), stride=(1, 1), padding=(0, 0))
        self.conv3 = nn.Conv2d(64, 128, kernel_size=(1, 3), stride=(1, 1), padding=(0, 0))
        self.pool1 = nn.MaxPool2d(kernel_size=(1, 2), stride=(1, 2), padding=(0, 0))
        self.pool2 = nn.MaxPool2d(kernel_size=(1, 2), stride=(1, 2), padding=(0, 0))
        self.conv4 = nn.Conv2d(128, 128, kernel_size=(6, 1), stride=(1, 1), padding=(0, 0))

        n_channels = self.feature(torch.empty(1, input_size, feature_size)).size(-1)
        
        self.fc = nn.Linear(n_channels, num_out)

    def forward(self, x):
        x = F.relu(self.conv1(x))
        x = self.pool1(x)
        x = F.relu(self.conv2(x))
        x = F.relu(self.conv3(x))
        x = self.pool2(x)
        x = F.relu(self.conv4(x))
        x = x.view(x.size(0), -1)
        x = self.fc(x)
        return x
