import torch
import numpy as np
from .ml_model import *
from torch.utils import data
import shap
from sklearn.model_selection import GridSearchCV, train_test_split, KFold, LeaveOneOut, StratifiedKFold, cross_val_score
from sklearn.metrics import accuracy_score, precision_score, recall_score, f1_score, roc_auc_score, confusion_matrix

class EarlyStopping:
    """주어진 patience 이후로 validation loss가 개선되지 않으면 학습을 조기 중지"""

    def __init__(self, patience=7, verbose=False, delta=0, path='checkpoint.pt'):
        """
        Args:
            patience (int): validation loss가 개선된 후 기다리는 기간
                            Default: 7
            verbose (bool): True일 경우 각 validation loss의 개선 사항 메세지 출력
                            Default: False
            delta (float): 개선되었다고 인정되는 monitered quantity의 최소 변화
                            Default: 0
            path (str): checkpoint저장 경로
                            Default: 'checkpoint.pt'
        """

        self.patience = patience
        self.verbose = verbose
        self.counter = 0
        self.best_score = None
        self.early_stop = False
        self.val_loss_min = np.Inf
        self.delta = delta
        self.path = path

    def __call__(self, val_loss, model):
        score = -val_loss

        if self.best_score is None:
            self.best_score = score
            self.best_model = model
            self.save_checkpoint(val_loss, model)
        elif score < self.best_score + self.delta:
            self.counter += 1
            print(f'EarlyStopping counter: {self.counter} out of {self.patience}')
            if self.counter >= self.patience:
                self.early_stop = True
            self.best_score = score
            return self.best_model
        else:
            print(f'Validation loss decreased ({-self.best_score:.6f} --> {val_loss:.6f}).')
            self.best_score = score
            self.best_model = model
            # self.save_checkpoint(val_loss, model)
            self.counter = 0
            return self.best_model

    def save_checkpoint(self, val_loss, model):
        '''validation loss가 감소하면 모델을 저장한다.'''
        if self.verbose:
            print(f'Validation loss decreased ({self.val_loss_min:.6f} --> {val_loss:.6f}).')
        # torch.save(model.state_dict(), self.path)
        self.val_loss_min = val_loss


# torch data loader 에 넣어주기 위한 Dataset

class My_Dataset(data.Dataset):
    def __init__(self, data, labels):
        super().__init__()
        self.data = data
        self.labels = labels

    def __len__(self):
        return len(self.data)

    def __getitem__(self, idx):
        return self.data[idx], self.labels[idx]


class Model_Learner():

    def __init__(self, DEVICE, cfg, logger, learn_type='ml'):
        self.DEVICE = DEVICE
        self.cfg = cfg
        self.logger = logger
        self.learn_type = learn_type

        self.train_dict = {'cnn': self.cnn_run, 'ml': self.ml_run}  # 각 model type에 따라 train 함수를 다르게 호출한다.
        # self.eval_dict = {'cnn': self.dnn_evaluate, 'ml': self.lstm_evaluate}  # 각 model type에 따라 evaluate 함수를 다르게 호출한다.

    # 모델 별로 학습을 하기 위한 함수
    def run_learning(self, data_in):
        self.data_in = data_in

        if self.learn_type == 'ml':
            self.train_dict[self.learn_type]()

        else:
            nn_model = set_cnn(input_size=0, num_out=0, feature_size=0)
            
            ls_dict = self.cfg['model_params']['learn_type']

           

            self.train_loader = torch.utils.data.DataLoader(dataset=My_Dataset(self.data_in['train_x'], self.data_in['train_y']),
                                                            batch_size=ls_dict['batch'], shuffle=False,
                                                            drop_last=True)

            self.test_loader = torch.utils.data.DataLoader(dataset=My_Dataset(self.data_in['test_x'], self.data_in['test_y']),
                                                        batch_size=ls_dict['batch'], shuffle=False, drop_last=False)


            optimizer = torch.optim.Adam(nn_model.parameters(), lr=ls_dict['learning_rate'])
            criterion = torch.nn.CrossEntropyLoss().to(self.DEVICE)

            criterion = self.loss_dict[self.type]()

            patience = ls_dict['patience']

            self.avg_train_losses = []
            self.avg_valid_losses = []

            early_stopping = EarlyStopping(patience=patience, verbose=True)
            best_model = None

            for epoch in range(1, ls_dict['epoch'] + 1):
                train_loss = self.train_dict[self.type](nn_model, self.train_loader, optimizer, criterion)
                test_loss = self.eval_dict[self.type](nn_model, self.test_loader, criterion)

                self.avg_train_losses.append(train_loss)
                self.avg_valid_losses.append(test_loss)

                if epoch % 10 == 0:
                    print('epoch:{} train_loss:{:.4f}'.format(epoch, train_loss))
                    print('validation_loss:{:.4f}'.format(test_loss))
                    best_model = early_stopping(test_loss, nn_model)
                    if early_stopping.early_stop:
                        print("Early stopping")
                        break

            if best_model is None: best_model = nn_model

            best_model.eval()

            return best_model

    def ml_run(self):
        model_list = {'xgb':set_xgb, 'svc':set_svc}

        n_splits = self.cfg['data_size']['n1']
        kfold = KFold(n_splits=n_splits)
    
        mean_accuracy = 0
        mean_precision = 0
        mean_recall = 0
        mean_f1 = 0

        classifier = model_list[self.cfg['default_ml_model']]() ##필요시 params 입력

        metric_df = pd.DataFrame(columns=['model', 'accuracy', 'precision', 'recall', 'f1_score'])
        y_pred_prob_list = []
        
        list_shap_values = list()
        list_test_sets = list()
        X, y = self.data_in['data_x'], self.data_in['data_y']

        for num, (train_idx, val_idx) in enumerate(kfold.split(X)):
            X_train, X_val = X[train_idx, :], X[val_idx, :]
            y_train, y_val = y[train_idx], y[val_idx]

            classifier.fit(X_train, y_train)

            y_pred = classifier.predict(X_val)
            y_pred_prob = classifier.predict_proba(X_val)

            accuracy = accuracy_score(y_val, y_pred)
            precision = precision_score(y_val, y_pred, average='macro')
            recall = recall_score(y_val, y_pred, average='macro')
            f1 = f1_score(y_val, y_pred, average='macro')

            metric_df.loc[len(metric_df)] = [f'model_{num+1}', accuracy, precision, recall, f1]
            
            # roc-auc score 계산을 위해 각 클래스별 예측 확률을 저장한다
            y_pred_prob_list.extend(y_pred_prob)

            # explaining model
            explainer = shap.TreeExplainer(classifier)
            shap_values = explainer.shap_values(X_val)
            
            list_shap_values.append(shap_values)
            list_test_sets.append(val_idx)


            # 평균 performance metric을 구한다
            mean_accuracy += accuracy
            mean_precision += precision
            mean_recall += recall 
            mean_f1 += f1

            print(f'fold {num} test accuracy : {accuracy}')

        mean_accuracy = mean_accuracy / n_splits
        mean_precision = mean_precision / n_splits
        mean_recall = mean_recall / n_splits
        mean_f1 = mean_f1 / n_splits
        print()
        print('mean accuracy : ', mean_accuracy)
        print('mean precision : ', mean_precision)
        print('mean recall : ', mean_recall)
        print('mean f1 : ', mean_f1)
        print()

        metric_df.loc[len(metric_df)] = ['mean', mean_accuracy, mean_precision, mean_recall, mean_f1]

        metric_df.to_csv(f"{self.cfg['default_ml_model']}_label_num_{self.cfg['data_size']['n1']}.csv",index=False)



    def cnn_run(self, model, train_loader, optimizer, criterion):
        try:
            model.train()
            train_loss = 0

            for batch_idx, (data, target) in enumerate(train_loader):
                data, target = data.to(self.DEVICE), target.type(torch.float32).to(self.DEVICE)
                optimizer.zero_grad()
                hypothesis = model(data.type(torch.float32)).squeeze()
                loss = criterion(hypothesis, target)
                train_loss += loss
                loss.backward()
                optimizer.step()
            train_loss /= len(train_loader.dataset)
            return train_loss

        except Exception as e:
            print('train:', e)

    

    def cnn_evaluate(self, model, test_loader, criterion):
        try:
            model.eval()
            test_loss = 0

            with torch.no_grad():
                for data, target in test_loader:
                    data, target = data.to(self.DEVICE), target.type(torch.float32).to(self.DEVICE)

                    hypothesis = model(data.type(torch.float32)).squeeze()
                    test_loss += criterion(hypothesis, target)

            test_loss /= len(test_loader.dataset)

            return test_loss
        except Exception as e:
            print('evaluate', e)

