from work_flow.model_conductor import *
from utils.file_interface import read_yaml_file
from utils.logger import AppLogger
from config import get_config

USE_CUDA = torch.cuda.is_available()
DEVICE = torch.device("cuda" if USE_CUDA else "cpu")

parser = get_config()
args = parser.parse_args()

logger = AppLogger(log_path=args.logging_path).get_logger()

config_info = read_yaml_file(file_path=args.ml_cfg_path, logger=logger)

pipe_manager = Set_Workflow(args=args, config_info=config_info, logger=logger)
pipe_manager.run_preprocessing()
pipe_manager.run_modeling(device=DEVICE)

