
import numpy as np
import os, glob, gc, time, logging, sys, re
import datetime
from typing import Optional
from utils.file_interface import *

from learn_package.model_learner import *
from sklearn.preprocessing import LabelEncoder


import warnings, argparse

warnings.filterwarnings(action='ignore')


astype_dict = {'int32':np.int32, 'int64':np.int64,'float32':np.float32,'float64':np.float64, 'object':str}


class Set_Workflow():
    def __init__(self, args: Optional[argparse.Namespace] , 
                       config_info:Optional[dict],
                       logger: Optional[logging.Logger]) -> None:
        
        self.logger = logger
        self.today = args.today
        self.args = args
        self.config_info = config_info

    def set_img_dataset(self, data_in):
        self.logger.info("Start img data preprocessing")
        unit_start_time = time.time()
        data_out = {}

        class_num = self.config_info['data_size']['n1']
        data_size = self.config_info['data_size']['n2']

    
        """
        data_x = data_in.copy()

        data_y = np.array([i for i in range(0,class_num) for _ in range(0,data_size)])

        여기에 image 전처리 코드 작성 하시면 됩니다.
        
        
        """

        unit_finish_time = time.time()
        unit_final_message = f"{unit_finish_time-unit_start_time:.2f}"

        self.logger.info("Finish unit process: %s in %s s", self.data_path, unit_final_message)

        return data_out


    def set_numeric_dataset(self, data_in):
        self.logger.info("Start numeric data preprocessing")
        unit_start_time = time.time()
        data_out = {}
        class_num = self.config_info['data_size']['n1']
        data_size = self.config_info['data_size']['n2']

        data_x = data_in.copy()
        data_x = data_x.reshape(class_num*data_size, -1)

        data_y = np.array([i for i in range(0,class_num) for _ in range(0,data_size)])

        data_out['data_x'] = data_x

        data_out['data_y'] = data_y

        unit_finish_time = time.time()
        unit_final_message = f"{unit_finish_time-unit_start_time:.2f}"

        self.logger.info("Finish unit process: %s in %s s", self.data_path, unit_final_message)

        return data_out

    def run_preprocessing(self):
        
        self.data_path = self.config_info['data_path']
        self.pp_data = None

        if os.path.exists(self.data_path):
            data = np.asarray(read_pickle_file(file_path=self.data_path, logger=self.logger))
            self.logger.info("Data Load Success : %s", self.data_path)

            self.dim = data.ndim
            
            if self.dim > 3:
                self.learn_type = 'cnn'
                self.pp_data = self.set_img_dataset(data_in=data)
            else:
                self.learn_type = 'ml'
                self.pp_data = self.set_numeric_dataset(data_in=data)

        else:
            self.logger.error("No data, Check the data path you set again.")
            sys.exit(1)


    def run_modeling(self, device):
        model_manager = Model_Learner(DEVICE=device, cfg = self.config_info, logger=self.logger, learn_type = self.learn_type)
        model_manager.run_learning(data_in = self.pp_data)
