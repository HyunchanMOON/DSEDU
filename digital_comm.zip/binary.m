clear;
clc;
close all;

% 매개변수 설정
n = 10000; % 전체 비트 수
SNR_dB = -5:2:15; % 다양한 SNR 값
sigma_values = 10.^(-SNR_dB/20); % SNR에 따른 잡음의 표준 편차

% 초기화
bit_errors = zeros(size(sigma_values));
num_iterations = 100; % 반복 횟수

% 메인 루프
for iter = 1:num_iterations
    for sigma_index = 1:length(sigma_values)
        % 이진 랜덤 데이터 생성
        tx_data = randi([0, 1], 1, n);
        
        % 가우시안 잡음 생성
        noise = sigma_values(sigma_index) * randn(1, n);
        
        % 전송: y = x + n
        rx_signal = tx_data + noise;
        
        % 수신 단계에서 이진 데이터 검출
        rx_data = rx_signal > 0.5;
        
        % 비트 오류 수 계산
        bit_errors(sigma_index) = bit_errors(sigma_index) + sum(tx_data ~= rx_data);
    end
end

% 평균 오류 계산
bit_errors = bit_errors / (num_iterations * n);

% SNR 값에 따른 결과를 log-log 그래프로 plot
figure;
semilogy(SNR_dB, bit_errors, '-o');
grid on;
xlabel('SNR (dB)');
ylabel('BER');
title('Binary Digital Communication');
legend('Test Result');

% Q 함수를 이용한 분석
q_function = 0.5 * erfc(sqrt(10.^(SNR_dB/10)));
hold on;
semilogy(SNR_dB, q_function, '--');
legend('Test result', 'Q function');

% 결과 출력
disp('Test result:');
disp(bit_errors);
disp('Q function:');
disp(q_function);


