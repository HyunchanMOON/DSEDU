%%
clear;
clc;
close all;


% 매개변수 설정
M = 4; % 4진 데이터
k = log2(M); % 비트 수
n = 10000; % 전체 비트 수
SNR_dB = -5:2:15; % 다양한 SNR 값
sigma_values = 10.^(-SNR_dB/20); % SNR에 따른 잡음의 표준 편차

% 초기화
symbol_errors = zeros(size(sigma_values));
bit_errors = zeros(size(sigma_values));
num_iterations = 100; % 반복 횟수

% 메인 루프
for iter = 1:num_iterations
    for sigma_index = 1:length(sigma_values)
        % 4진 랜덤 데이터 생성
        tx_data = randi([0, M-1], 1, n/k);
        
        % 송신 신호 x의 정규화
        tx_symbols = qammod(tx_data, M, 'UnitAveragePower', true);
        
        % 가우시안 잡음 생성
        noise = sigma_values(sigma_index) * (randn(1, n/k) + 1i * randn(1, n/k));
        
        % 전송: y = x + n
        rx_symbols = tx_symbols + noise;
        
        % 수신 신호에서 4진 데이터 복조
        rx_data = qamdemod(rx_symbols, M, 'UnitAveragePower', true);
        
        % 심볼 오류 수 계산
        symbol_errors(sigma_index) = symbol_errors(sigma_index) + sum(tx_data ~= rx_data);
        
        % 비트 오류 수 계산
        % Convert the received symbols to binary representation
        rx_bits = de2bi(rx_data, k, 'left-msb');

        % Convert the transmitted symbols to binary representation
        tx_bits = de2bi(tx_data, k, 'left-msb');

        % Calculate the bit errors
        bit_errors(sigma_index) = bit_errors(sigma_index) + sum(tx_bits(:) ~= rx_bits(:));
    end
end

% 평균 오류 계산
symbol_errors = symbol_errors / (num_iterations * n/k);
bit_errors = bit_errors / (num_iterations * n);

% SNR 값에 따른 결과를 log-log 그래프로 plot
figure;
semilogy(SNR_dB, symbol_errors, '-o');
hold on;
semilogy(SNR_dB, bit_errors, '-^');
grid on;
xlabel('SNR (dB)');
ylabel('BER ');
title('QAM Digital Comm performance');
legend('Symbol Error', 'Bit Error');

% 결과 출력
disp('심볼 오류 확률:');
disp(symbol_errors);
disp('비트 오류 확률:');
disp(bit_errors);