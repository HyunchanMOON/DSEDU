import torch
import numpy as np
import pandas as pd
import torchvision.transforms as transforms
import shap

import gc
from .model_factory import *
from torch.utils import data
from torch.utils.data import DataLoader, TensorDataset
from sklearn.model_selection import KFold, LeaveOneOut, StratifiedKFold, cross_val_score
from sklearn.metrics import accuracy_score, precision_score, recall_score, f1_score, confusion_matrix


# torch data loader 에 넣어주기 위한 Dataset
class My_Dataset(data.Dataset):
    def __init__(self, data, labels, transform):
        super().__init__()
        self.data = data
        self.labels = labels
        self.transform = transform

    def __len__(self):
        return len(self.data)

    def __getitem__(self, idx):

        if self.transform is not None:
            self.data[idx] = self.transform(self.data[idx])


        return self.data[idx], self.labels[idx]


class Model_Learner():

    def __init__(self, DEVICE, cfg, logger, learn_type='ml'):
        self.DEVICE = DEVICE
        self.cfg = cfg
        self.logger = logger
        self.learn_type = learn_type
        self.train_dict = {'cnn': self.cnn_run, 'ml': self.ml_run}  # 각 model type에 따라 train 함수를 다르게 호출한다.

        self.transform = transforms.Compose(
                                            [transforms.ToTensor(),
                                            transforms.Normalize((0.5, 0.5, 0.5), (0.5, 0.5, 0.5))])

    # 모델 별로 학습을 하기 위한 함수
    def run_learning(self, data_in):
        self.data_in = data_in
        self.train_dict[self.learn_type]()


    def ml_run(self):
        model_list = {'xgb':set_xgb, 'svc':set_svc}
        n_splits = self.cfg['data_size']['n1']
        kfold = KFold(n_splits=n_splits)
    
        mean_accuracy = 0
        mean_precision = 0
        mean_recall = 0
        mean_f1 = 0

        classifier = model_list[self.cfg['default_ml_model']](self.cfg['model_params'][self.cfg['default_ml_model']]) ##필요시 params 입력

        metric_df = pd.DataFrame(columns=['model', 'accuracy', 'precision', 'recall', 'f1_score'])
        y_pred_prob_list = []
        
        list_shap_values = list()
        list_test_sets = list()
        X, y = self.data_in['data_x'], self.data_in['data_y']

        for num, (train_idx, val_idx) in enumerate(kfold.split(X)):
            X_train, X_val = X[train_idx, :], X[val_idx, :]
            y_train, y_val = y[train_idx], y[val_idx]

            classifier.fit(X_train, y_train)

            y_pred = classifier.predict(X_val)
            y_pred_prob = classifier.predict_proba(X_val)

            accuracy = accuracy_score(y_val, y_pred)
            precision = precision_score(y_val, y_pred, average='macro')
            recall = recall_score(y_val, y_pred, average='macro')
            f1 = f1_score(y_val, y_pred, average='macro')

            metric_df.loc[len(metric_df)] = [f'model_{num+1}', accuracy, precision, recall, f1]
            
            # roc-auc score 계산을 위해 각 클래스별 예측 확률을 저장한다
            y_pred_prob_list.extend(y_pred_prob)

            # explaining model
            explainer = shap.TreeExplainer(classifier)
            shap_values = explainer.shap_values(X_val)
            
            list_shap_values.append(shap_values)
            list_test_sets.append(val_idx)

            # 평균 performance metric을 구한다
            mean_accuracy += accuracy
            mean_precision += precision
            mean_recall += recall 
            mean_f1 += f1

            print(f'fold {num} test accuracy : {accuracy}')

        mean_accuracy = mean_accuracy / n_splits
        mean_precision = mean_precision / n_splits
        mean_recall = mean_recall / n_splits
        mean_f1 = mean_f1 / n_splits

        print()
        print('mean accuracy : ', mean_accuracy)
        print('mean precision : ', mean_precision)
        print('mean recall : ', mean_recall)
        print('mean f1 : ', mean_f1)
        print()

        metric_df.loc[len(metric_df)] = ['mean', mean_accuracy, mean_precision, mean_recall, mean_f1]

        metric_df.to_csv(f"{self.cfg['default_ml_model']}_label_num_{self.cfg['data_size']['n1']}.csv",index=False)


    def cnn_run(self):
        
        ls_dict = self.cfg['model_params'][self.learn_type]

        n_splits = self.cfg['data_size']['n1']
        kfold = KFold(n_splits=n_splits)
        
        mean_accuracy = 0
        mean_precision = 0
        mean_recall = 0
        mean_f1 = 0

        X = torch.tensor(self.data_in['data_x'], dtype=torch.float32)

        y = torch.tensor(self.data_in['data_y'], dtype=torch.long)
        metric_df = pd.DataFrame(columns=['model', 'accuracy', 'precision', 'recall', 'f1_score'])

        for num, (train_idx, val_idx) in enumerate(kfold.split(X)):
            nn_model = set_cnn(input_size=self.data_in['input_channel'], num_out=self.data_in['output_size'], feature_size=self.data_in['feature_size'], DEVICE=self.DEVICE)
    
            # 손실 함수와 옵티마이저 정의

            optimizer = torch.optim.Adam(nn_model.parameters(), lr=ls_dict['learning_rate'])
            criterion = torch.nn.CrossEntropyLoss().to(self.DEVICE)
            
            # 훈련 및 검증 데이터 분할
            X_train, X_test = X[train_idx], X[val_idx]
            y_train, y_test = y[train_idx], y[val_idx]
            
            # DataLoader를 사용하여 데이터 로드
            train_dataset = TensorDataset(X_train, y_train)
            train_loader = DataLoader(train_dataset, batch_size=10, shuffle=True)

            # 모델 훈련
            for epoch in range(ls_dict['epoch']):
                running_loss = 0.0
                for i,(inputs, labels) in enumerate(train_loader):
                    inputs , labels = inputs.to(self.DEVICE), labels.to(self.DEVICE)
                    optimizer.zero_grad()
                    outputs = nn_model(inputs)
                    loss = criterion(outputs, labels)
                    
                    loss.backward()
                    optimizer.step()

                    running_loss += loss.item()
                    if i % 500 == 0:   
                        print(f'[{epoch + 1}, {i + 1:5d}] loss: {running_loss / 500:.3f}')
                        running_loss = 0.0

            # # 모델 평가
            with torch.no_grad():
                nn_model.eval()
                X_test = X_test.to(self.DEVICE)
                test_output = nn_model(X_test)
                predicted = torch.argmax(test_output, dim=1)
                accuracy = (predicted == y_test).sum().item() / y_test.size(0)


                accuracy = accuracy_score(y_test, predicted)
                precision = precision_score(y_test, predicted, average='macro')
                recall = recall_score(y_test, predicted, average='macro')
                f1 = f1_score(y_test, predicted, average='macro')

                metric_df.loc[len(metric_df)] = [f'model_{num+1}', accuracy, precision, recall, f1]
                print(f'fold {num} test accuracy : {accuracy}')

                mean_accuracy += accuracy
                mean_precision += precision
                mean_recall += recall 
                mean_f1 += f1

            del nn_model
            gc.collect()

        mean_accuracy = mean_accuracy / n_splits
        mean_precision = mean_precision / n_splits
        mean_recall = mean_recall / n_splits
        mean_f1 = mean_f1 / n_splits

        print()
        print('mean accuracy : ', mean_accuracy)
        print('mean precision : ', mean_precision)
        print('mean recall : ', mean_recall)
        print('mean f1 : ', mean_f1)
        print()

        metric_df.loc[len(metric_df)] = ['mean', mean_accuracy, mean_precision, mean_recall, mean_f1]

        metric_df.to_csv(f"cnn_label_num_{self.cfg['data_size']['n1']}.csv",index=False)



