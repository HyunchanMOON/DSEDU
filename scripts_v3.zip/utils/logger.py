
import datetime
import logging
import os
import sys

from pathlib import Path


class AppLogger:
    def __init__(self, log_path):
        log_file_name = datetime.datetime.now().strftime("%Y%m%d_%H%M")
        dir_log = log_path

        try:
            if not os.path.exists(dir_log):
                os.mkdir(dir_log)
        except Exception as ex:
            print("Exception in AppLogger {0}", ex)

        filename = "{0}.log".format(log_file_name)
        dir_log_path = Path(dir_log)
        if sys.version_info < (3, 6, 0):
            dir_log_path = str(dir_log_path)

        if os.path.exists(dir_log_path) is False:
            os.makedirs(dir_log_path)

        log_file_name = os.path.join(dir_log_path, filename)
        print("log_file_name : ", str(log_file_name))
        self.logger = logging.getLogger("ml_log")
        file_handler = logging.FileHandler(log_file_name, 'w', 'utf-8')
        console_handler = logging.StreamHandler()
        logging.basicConfig(level=logging.INFO,
                            handlers=[file_handler, console_handler],
                            format='%(asctime)s-[%(filename)s:%(funcName)s:%(lineno)d]-%(name)s-%(levelname)s-%(message)s',
                            datefmt='%Y-%m-%d %H:%M:%S')

    def get_logger(self):
        return self.logger
