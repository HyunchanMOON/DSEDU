import numpy as np
import optuna
import torch
from sklearn.metrics import mean_absolute_error, mean_squared_error, mean_squared_log_error, make_scorer
from sklearn.ensemble import GradientBoostingRegressor

from sklearn.multioutput import MultiOutputRegressor
from xgboost import XGBRegressor
import lightgbm as lgb

GPU_USE = torch.cuda.is_available()
if GPU_USE:
    GPU_ID = torch.cuda.current_device()

    print(GPU_USE, GPU_ID)


def nrmse(y, y_pred):
    return -1 * np.sqrt(mean_squared_error(y, y_pred))


def rmse(y, y_pred):
    return np.sqrt(mean_squared_error(y, y_pred))


def mae(y, y_pred):
    return mean_absolute_error(y, y_pred)


def mse(y, y_pred):
    return mean_squared_error(y, y_pred)


def rmsle(y, y_pred):
    return np.sqrt(mean_squared_log_error(y, y_pred))


class optm():
    def __init__(self):
        pass

    def run_optm(self, x_train, y_train, x_val, y_val, n_trial=10, direction='maximize', model='XGB'):
        self.x_train = x_train
        self.y_train = y_train
        self.x_val = x_val
        self.y_val = y_val
        model_dict = {'GBR': self.gbr_objective,
                      'LGB': self.lgbr_objective,
                      'XGB': self.xgbr_objective
                      }
        optuna.logging.set_verbosity(0)
        self.study = optuna.create_study(direction=direction)
        self.study.optimize(model_dict[model], n_trials=n_trial)

        bestparams = self.study.best_params
        best_score = self.study.best_value

        print(f"Best score:{best_score} \nOptimized parameters: {bestparams}")

        return bestparams, best_score

    def plot_optm(self):

        optuna.visualization.plot_optimization_history(self.study)
        optuna.visualization.plot_param_importances(self.study)

    def gbr_objective(self, trial):
        gbm_params = {
            'n_estimators': trial.suggest_int('n_estimators', 50, 3000),
            'learning_rate': trial.suggest_loguniform("learning_rate", 1e-4, 1e-1),
            'max_depth': trial.suggest_int('max_depth', 1, 20),
            'max_features': trial.suggest_categorical('max_features', [None, 'sqrt']),
            'min_samples_leaf': trial.suggest_int('min_samples_leaf', 1, 20),
            'min_samples_split': trial.suggest_int('min_samples_split', 2, 20),
            'min_weight_fraction_leaf': trial.suggest_float('min_weight_fraction_leaf', 0.0, 0.5),
            'min_impurity_decrease': trial.suggest_int('min_impurity_decrease', 0, 10),
            #        'loss': trial.suggest_categorical("loss", ["ls", "lad", "huber", "quantile"])
            'alpha': trial.suggest_float("alpha", 0, 1),
            'max_leaf_nodes': trial.suggest_int("max_leaf_nodes", 2, 20),
            #        'warm_start': trial.suggest_int("warm_start", ["True", "False"])
            'validation_fraction': trial.suggest_float("validation_fraction", 0, 1),
            'subsample': trial.suggest_float('subsample', np.spacing(1), 1.0, step=0.1),
            'random_state': 42
        }

        self.model = GradientBoostingRegressor(**gbm_params)

        score = make_scorer(nrmse, greater_is_better=True)

        self.model = self.model.fit(self.x_train, self.y_train)
        score = score(self.model, self.x_val, self.y_val)

        return score

    def lgbr_objective(self, trial):
        lgbm_params = {
            'n_estimators': trial.suggest_int('n_estimators', 50, 3000),
            'learning_rate': trial.suggest_loguniform("learning_rate", 1e-4, 1e-1),
            'num_leaves': trial.suggest_int('num_leaves', 2, 256),
            'colsample_bytree': trial.suggest_float('colsample_bytree', 0.6, 1.0, step=0.1),
            'max_depth': trial.suggest_int('max_depth', -1, 20),
            'bagging_freq': trial.suggest_int('bagging_freq', 1, 10),
            'subsample': trial.suggest_float('subsample', 0.1, 1.0, step=0.1),  # bagging_fraction
            'reg_alpha': trial.suggest_float('reg_alpha', 1.0, 5.0),  # lambda_l1
            'reg_lambda': trial.suggest_float('reg_lambda', 1.0, 5.0),  # lambda_l2
            'min_child_weight': trial.suggest_float('min_child_weight', 0.001, 0.6),
            'max_bin': trial.suggest_int('max_bin', 200, 400),
            'min_data_in_leaf': trial.suggest_int('min_data_in_leaf', 1, 100),
            'feature_fraction_seed': trial.suggest_int('feature_fraction_seed', 1, 10),
            'cat_smooth': trial.suggest_float('cat_smooth', 0, 5),
            'min_split_gain': trial.suggest_float('min_split_gain', 0, 10),
            'random_state': 42
        }
        #         if GPU_USE:
        #             lgbm_params['device'] = 'gpu'

        self.model = lgb.LGBMRegressor(**lgbm_params)

        score = make_scorer(nrmse, greater_is_better=True)

        self.model = self.model.fit(self.x_train, self.y_train)
        score = score(self.model, self.x_val, self.y_val)

        return score

    def xgbr_objective(self, trial):
        xgb_params = {
            'n_estimators': trial.suggest_int('n_estimators', 50, 500),
            'learning_rate': trial.suggest_loguniform("learning_rate", 1e-4, 1e-1),
            'max_depth': trial.suggest_int('max_depth', 3, 10),
            'min_child_weight': trial.suggest_int('min_child_weight', 1, 9),
            'colsample_bytree': trial.suggest_float('colsample_bytree', 0.5, 1.0, step=0.1),
            'subsample': trial.suggest_float('subsample', 0.5, 1.0, step=0.1),
            'gamma': trial.suggest_float('gamma', 0.0, 5.0, step=0.1),
            'reg_alpha': trial.suggest_float('reg_alpha', 1.0, 5.0),  # lambda_l1
            'reg_lambda': trial.suggest_float('reg_lambda', 1.0, 5.0),  # lambda_l2
            'random_state': 42
        }
        if GPU_USE:
            xgb_params['tree_method'] = 'gpu_hist'
            xgb_params['gpu_id'] = GPU_ID
        self.model = MultiOutputRegressor(XGBRegressor(**xgb_params))

        score = make_scorer(nrmse, greater_is_better=True)

        self.model = self.model.fit(self.x_train, self.y_train)
        score = score(self.model, self.x_val, self.y_val)

        return score
