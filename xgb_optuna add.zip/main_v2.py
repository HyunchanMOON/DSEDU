################################################################################################################

import os
import os.path as osp
import sys

import h5py
import matplotlib
from collections import defaultdict
import pandas as pd
from utility.cal_dist import *
import warnings
from Model_learner import Learn_module
from sklearn.metrics import r2_score, mean_squared_error

### global var ###

warnings.filterwarnings("ignore", "(?s).*MATPLOTLIBDATA.*", category=UserWarning)
warnings.simplefilter(action='ignore', category=UserWarning)

DEVICE = Learn_module.set_device()

pd.set_option('display.max_columns', 500)

matplotlib.use('TkAgg')
sys.path.append(osp.join(osp.dirname(osp.abspath(__file__)), '..'))
################################################################################################################

data_folder = 'data'

files = [f for f in os.listdir(data_folder) if osp.isdir(osp.join(data_folder, f)) and not f.endswith('_paired')]


outfolder = osp.abspath('./magnet_viz')

calculate_average = False

if not osp.exists(outfolder):
    os.makedirs(outfolder)

def mk_fig():
    if not calculate_average:
        fig, ax = plt.subplots(1, 1, figsize=(20, 12))
    return ax

################################################################################################################

def change_cf(ori, vectors):
    """
    Euler-Rodrigous formula v'=v+2s(rxv)+2rx(rxv)
    :param ori: quaternion [n]x4
    :param vectors: vector nx3
    :return: rotated vector nx3
    """
    assert ori.shape[-1] == 4
    assert vectors.shape[-1] == 3

    if len(ori.shape) == 1:
        ori = np.repeat([ori], vectors.shape[0], axis=0)
    q_s = ori[:, :1]
    q_r = ori[:, 1:]

    tmp = np.cross(q_r, vectors)
    vectors = np.add(np.add(vectors, np.multiply(2, np.multiply(q_s, tmp))), np.multiply(2, np.cross(q_r, tmp)))
    return vectors

################################################################################################################

def get_window_signal(magnet_input, window, threshold=0.7):
    out_sig = magnet_input
    dim = out_sig.shape[1]
    x_size = window*dim
    all_len = out_sig.shape[0]

    split_num = all_len // window + 1
    s , n = 0, window
    return_dict = {}
    same_win = []
    different_win = []

    for i in range(split_num):
        cut_sig = out_sig[s:n, :]
        x_data = cut_sig.reshape(1,-1)

        if cut_sig.shape[0] >= window*threshold:
            same_win.append(cut_sig) if cut_sig.shape[0] == window else different_win.append(cut_sig)

        s, n = n, n+window
        if x_data.shape[1] != x_size:
            continue

        x_set = x_data if i == 0 else np.vstack([x_set, x_data])

    return_dict['same_win'] = np.asarray(same_win)
    return_dict['diff_win'] = np.asarray(different_win)
    return_dict['x_dset'] = x_set

    return return_dict

################################################################################################################
def df_to_csv(dataframe, file_name):
    if os.path.exists(file_name) == False:
        dataframe.to_csv(file_name)

def main():
    sframe, eframe = 0, -1

    average_vector = np.asarray([2.37530259, -18.93004064, -48.90972049])
    max_magnitude = np.linalg.norm(average_vector)
    i = 1
    magnet_dict = dict()
    magnet_dict['dd'] = defaultdict(list)

    avg_vectors = []
    DEFAULT_PLOTLY_COLORS = ['red', 'orange', 'yellow', 'green', 'cyan', 'navy', 'purple']

    label = ['x', 'y', 'z']
    for data in files:
        with h5py.File(osp.join(data_folder, data, "data.hdf5"), 'r') as f:
            pos = np.copy(f["pose/tango_pos"])[sframe:eframe]
            ori = np.copy(f["pose/tango_ori"])[sframe:eframe]
            magnet = np.copy(f["synced/magnet"])[sframe:eframe]

            if not calculate_average:
                glob_magnet = (change_cf(ori, magnet) - average_vector) / max_magnitude
                #glob_magnet = change_cf(ori, magnet) / max_magnitude
                #glob_magnet = change_cf(ori, magnet)
                print(data)
                # ax.scatter(pos[:, 1], pos[:, 0], c=glob_magnet[:, i], vmin=-1.0, vmax=1.0, cmap='rainbow', alpha=0.4,s=.2)

            else:
                glob_magnet = change_cf(ori, magnet)
                median_vector = np.median(glob_magnet, axis=0)
                avg_vectors.append(median_vector)

            max_m, mid_m = max(np.linalg.norm(glob_magnet, axis=1)), np.median(np.linalg.norm(glob_magnet, axis=1))
    ################################################################################################################

        if calculate_average:
            avg_vectors = np.asarray(avg_vectors)
            avg = np.average(avg_vectors, axis=0)
            print(avg)

        else:
            window = 20
            ls_dict = {'learning_rate': 0.001, 'EPOCHS': 100, 'BATCH_SIZE': 500, 'patience': 5}
            Model = 'XGB'

            if Model == 'LSTM':
                X = glob_magnet
                Y = pos[:, :2]

            else:
                windowing_dict = get_window_signal(magnet_input=glob_magnet, window=window)
                magnet_df = pd.DataFrame(windowing_dict['same_win'].reshape(window, -1))
                cols = list(magnet_df.columns)
                col_x = [data + f'_{i}_x' for i in range(magnet_df.shape[1] // 3)]
                col_y = [data + f'_{i}_y' for i in range(magnet_df.shape[1] // 3)]
                col_z = [data + f'_{i}_z' for i in range(magnet_df.shape[1] // 3)]
                cols[0::3], cols[1::3], cols[2::3] = col_x, col_y, col_z
                magnet_df.columns = cols
                target = pos[window - 1::window][:, :2]
                X, Y = windowing_dict['x_dset'], target

            manager = Learn_module.Learn_manager(X=X, Y=Y, window=10, DEVICE=DEVICE, Model=Model)

            model, pred_y = manager(hyper_tune=True, trial=1)

            pred_y_df = pd.DataFrame(pred_y, columns=['Predict_x', 'Predict_y'])

            real_y_df = pd.DataFrame(manager.train_test_dict['test_y'], columns=['Real_x', 'Real_y'])
            mse = np.round(np.mean(np.square(pred_y - manager.train_test_dict['test_y']), axis=0), 2)
            mse_all = np.round(np.mean(np.square(pred_y - manager.train_test_dict['test_y'])), 2)
            R2 = r2_score(manager.train_test_dict['test_y'], pred_y, )

            print('X AXIS MSE :', mse[0])
            print('Y AXIS MSE :', mse[-1])

            print('MSE All:', mse_all)
            print('X AXIS RMSE :', np.sqrt(mse[0]))
            print('Y AXIS RMSE :', np.sqrt(mse[-1]))
            print('R2 :', R2)

            # print(pred_y_df)
            # print(real_y_df)
            fig, ax = plt.subplots(2, 1)
            ax[0].plot(pred_y_df['Predict_x'], 'b.',label='Prediction Set')
            ax[0].plot(real_y_df['Real_x'], 'r.',label='Real Set')
            ax[1].plot(pred_y_df['Predict_y'], 'b.',label='Prediction Set')
            ax[1].plot(real_y_df['Real_y'], 'r.',label='Real Set')

            plt.suptitle(f'{data}_window_{window}, MSE: {mse_all}')
            plt.grid()
            plt.show()

if __name__ == '__main__':
    main()