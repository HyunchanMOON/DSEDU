import matplotlib.pyplot as plt
import matplotlib.patches as plp
from matplotlib.widgets import SpanSelector
import numpy as np


def index_to_range(indices):
    p0 = 0
    ranges = []
    for p1 in range(1, indices.shape[0]):
        if indices[p1] - indices[p1-1] > 1:
            ranges.append([indices[p0], indices[p1-1]])
            p0 = p1
    if p0 < indices.shape[0]:
        ranges.append([indices[p0], indices[-1]])
    return ranges


class MaskSelector:
    def __init__(self):
        self.mask = None
        self.ax = None
        self.fig = None
        self.rects = []
        self.is_adding = 1
        self.x_offset = 0

    def range_select_callback(self, xmin, xmax):
        xmin = int(max(0, xmin - self.x_offset))
        xmax = int(min(self.mask.shape[0], xmax - self.x_offset))
        self.mask[int(xmin):int(xmax)] = self.is_adding
        ranges = index_to_range(np.where(self.mask == 1)[0])
        for r in self.rects:
            r.remove()

        self.rects = []
        y_range = self.ax.get_ylim()
        for r in ranges:
            rec = plp.Rectangle((r[0]+self.x_offset, y_range[0]), r[1] - r[0], y_range[1] - y_range[0],
                                alpha=0.5, color='r')
            self.rects.append(rec)
            self.ax.add_patch(rec)
        plt.draw()

    def key_press_callback(self, event):
        if event.key == 'a':
            self.is_adding = 1
            print('Adding')
        elif event.key == 'd':
            self.is_adding = 0
            print('Removing')

    def __call__(self, data, title='Select range', x_offset=0, ymin=-20, ymax=20, legends=None, init_mask=None):
        self.mask = np.zeros(data.shape[0], dtype=np.int)
        self.fig, self.ax = plt.subplots(figsize=(12, 8))

        plt.title(title)
        plt.ylim(ymin, ymax)
        self.x_offset = x_offset
        x = np.arange(0, data.shape[0]) + self.x_offset
        self.ax.plot(x, data)
        if init_mask is not None:
            init_ranges = index_to_range(np.where(init_mask)[0])
            for r in init_ranges:
                self.range_select_callback(r[0], r[1])
        self.fig.canvas.mpl_connect('key_press_event', self.key_press_callback)

        span = SpanSelector(self.ax, self.range_select_callback, 'horizontal', useblit=True,
                            span_stays=False)
        if legends is not None:
            plt.legend(legends)
        plt.tight_layout()
        plt.show()

        return self.mask


if __name__ == '__main__':
    import pandas
    from os import path as osp
    from scipy.ndimage.filters import gaussian_filter1d

    test_path = '../../../data_practice/hang_practice1'
    data_all = pandas.read_csv(osp.join(test_path, 'processed/data.csv'))

    linacce = data_all[['linacce_x', 'linacce_y', 'linacce_z']].values
    filter_sigma = 30.0
    linacce = gaussian_filter1d(linacce, sigma=filter_sigma, axis=0)

    time_window = 12000
    overlap = 600
    start_f = 0

    mask_selector = MaskSelector()
    mask = np.zeros(linacce.shape[0])
    for start_f in range(0, linacce.shape[0], time_window - overlap):
        end_f = min(start_f + time_window, linacce.shape[0])
        local_mask = mask_selector(linacce[start_f:end_f])
        mask[start_f:end_f] = local_mask

    pos_ranges = index_to_range(np.where(mask == 1)[0])
    fig, ax = plt.subplots(figsize=(12, 8))
    ax.plot(linacce)
    yr = ax.get_ylim()
    for r in pos_ranges:
        ax.add_patch(plp.Rectangle((r[0], yr[0]), r[1] - r[0], yr[1] - yr[0], alpha=0.5, color='r'))
    plt.title('Selected range')
    plt.tight_layout()
    plt.show()

