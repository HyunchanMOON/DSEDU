clear;
close all;
clc;
ii = sqrt(-1);

MC_trial = 10000;
SNR = -10:2:10; % dB
length_snr = length(SNR);

%%%%%%%%%%%%%%%%%%%%%%%%%
E_s = 1;
bitpersym = 2;
PSK_order = 4;

SER_simulation = zeros(1, length_snr);

for idx_P = 1:length_snr
    sigma_n2 = 10^(-SNR(idx_P)/10);
    
    N_bit_err = 0;
    N_sym_err = 0;
    
    for n_trial = 1:MC_trial
        H = sqrt(1/2) * (randn(1, 1) + ii * randn(1, 1)); % Rayleigh fading channel
        
        % Generate random message bits
        msgBit = randi([0 1], 1, bitpersym);
        
        % Convert message bits to symbol index
        msgSym = bi2de(msgBit, 'left-msb');
        
        % Modulation
        Sym = Sym_Mod(msgSym, PSK_order);
        
        % AWGN channel
        sigma_n = sqrt(sigma_n2);
        y = H * Sym + sigma_n/sqrt(2) * (randn(1, 1) + ii*randn(1, 1));
        
        % Receiver
        r = y / H; % Divide by channel coefficient for Rayleigh fading channel
        dec_idx = Sym_Demod(r, PSK_order);
        msgBit_hat = de2bi(dec_idx, bitpersym, 'left-msb');
        
        % Count symbol and bit errors
        total_errors = sum(sum(xor(msgBit_hat, msgBit)));
        if total_errors ~= 0
            N_sym_err = N_sym_err + 1;
        end
        N_bit_err = N_bit_err + total_errors;
    end
    
    SER_simulation(idx_P) = N_sym_err/MC_trial;
end

semilogy(SNR, SER_simulation, '-o', 'LineWidth', 2)
xlabel('SNR (dB)')
ylabel('Symbol Error Rate (SER)')
title('Average SER Curve for QPSK with Rayleigh Flat Fading Channel')
grid on;


%%

clear;
close all;
clc;
ii = sqrt(-1);

MC_trial = 10000;
SNR = 0:2:20; % dBm
length_snr = length(SNR);

%%%%%%%%%%%%%%%%%%%%%%%%%
E_s = 1;
bitpersym = 2;
QPSK_order = 2^bitpersym;

QPSK_sqrt = sqrt(QPSK_order);

SER_awgn = zeros(1, length_snr);
SER_rayleigh = zeros(1, length_snr);

for idx_P = 1:length_snr
    sigma_n2 = 10^(-SNR(idx_P)/10);
    
    N_bit_err_awgn = 0;
    N_bit_err_rayleigh = 0;
    
    for n_trial = 1:MC_trial
        % Generate random message bits
        msgBit = randi([0 1], 1, bitpersym);
        
        % Convert message bits to symbol index
        msgSym = bi2de(msgBit, 'left-msb');
        
        % Modulation
        Sym = Sym_Mod(msgSym, QPSK_order);
        
        % AWGN channel
        sigma_n = sqrt(sigma_n2);
        y_awgn = Sym + sigma_n/sqrt(2) * (randn(1, 1) + ii*randn(1, 1));
        
        % Rayleigh flat fading channel
        H = (randn(1, 1) + ii*randn(1, 1))/sqrt(2);
        y_rayleigh = Sym * H + sigma_n/sqrt(2) * (randn(1, 1) + ii*randn(1, 1));
        
        % Receiver for AWGN channel
        r_awgn = y_awgn; % for AWGN channel
        dec_idx_awgn = Sym_Demod(r_awgn, QPSK_order);
        msgBit_hat_awgn = de2bi(dec_idx_awgn, bitpersym, 'left-msb');
        
        % Receiver for Rayleigh flat fading channel
        r_rayleigh = y_rayleigh / H; % equalization
        dec_idx_rayleigh = Sym_Demod(r_rayleigh, QPSK_order);
        msgBit_hat_rayleigh = de2bi(dec_idx_rayleigh, bitpersym, 'left-msb');
        
        % Count bit errors
        bit_errors_awgn = sum(sum(xor(msgBit_hat_awgn, msgBit)));
        bit_errors_rayleigh = sum(sum(xor(msgBit_hat_rayleigh, msgBit)));
        
        N_bit_err_awgn = N_bit_err_awgn + bit_errors_awgn;
        N_bit_err_rayleigh = N_bit_err_rayleigh + bit_errors_rayleigh;
    end
    
    % Calculate SER for AWGN and Rayleigh flat fading channels
    SER_awgn(idx_P) = N_bit_err_awgn / (MC_trial * bitpersym);
    SER_rayleigh(idx_P) = N_bit_err_rayleigh / (MC_trial * bitpersym);
end

% Plot SER comparison
semilogy(SNR, SER_awgn, '-o', SNR, SER_rayleigh, '-s', 'LineWidth', 2)
xlabel('SNR (dB)')
ylabel('Symbol Error Rate (SER)')
title('SER Comparison: AWGN vs Rayleigh Flat Fading')
legend('AWGN', 'Rayleigh Flat Fading')
grid on;
