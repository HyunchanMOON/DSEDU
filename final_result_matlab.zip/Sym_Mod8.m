
function Sym = Sym_Mod8(msgSym, M)
%
% 8PSK Symbol Modulation
%

%%% Signal candidates generation
if (M == 8)
    Sa = [exp(1i*0) exp(1i*pi/4) exp(1i*pi/2) exp(1i*3*pi/4) exp(1i*pi) exp(1i*5*pi/4) exp(1i*3*pi/2) exp(1i*7*pi/4)];
    kmod = sqrt(1);
else
    error('Unsupported modulation order');
end

Sym = kmod * Sa(msgSym + 1);

end