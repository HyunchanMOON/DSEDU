clear;
close all;
clc;
ii = sqrt(-1);

MC_trial = 10000;
SNR = 0:2:10; % dB

SER_simulation = zeros(1, length(SNR));

%%%%%%%%%%%%%%%%%%%%%%%%%
E_s = 1;
bitpersym = 3;
PSK_order = 8;

for idx_P = 1:length(SNR)
    sigma_n2 = 10^(-SNR(idx_P)/10);
    
    N_bit_err = 0;
    N_sym_err = 0;
    
    for n_trial = 1:MC_trial
        H = 1;
        
        msgBit = randi([0 1], 1, bitpersym);
        msgSym = bi2de(msgBit, 'left-msb');
        Sym = Sym_Mod8(msgSym, PSK_order);
        sigma_n = sqrt(sigma_n2);
        
        % AWGN
        y = H*Sym + sigma_n/sqrt(2)*(randn(1, 1) + ii*randn(1, 1));
        
        % Receiver
        r = y; % for AWGN channel
        dec_idx = Sym_Demod8(r, PSK_order);
        msgBit_hat = de2bi(dec_idx, bitpersym, 'left-msb');
        
        total_errors = sum(sum(xor(msgBit_hat, msgBit)));
        if total_errors ~= 0
            N_sym_err = N_sym_err + 1;
        end
        N_bit_err = N_bit_err + total_errors;
    end
    
    SER_simulation(idx_P) = N_sym_err / MC_trial;
end

semilogy(SNR, SER_simulation, '-x', 'LineWidth', 2)
xlabel('SNR (dB)')
ylabel('SER')
title('SER Performance of 8PSK in AWGN Channel')
grid on;




%% 8PSK B

clear;
close all;
clc;
ii = sqrt(-1);

MC_trial = 10000;
SNR = [4, 14]; % dBm

%%%%%%%%%%%%%%%%%%%%%%%%%
E_s = 1;
bitpersym = 3;
PSK_order = 8;

for idx_P = 1:length(SNR)
    sigma_n2 = 10^(-SNR(idx_P)/10);
    
    N_bit_err = 0;
    N_sym_err = 0;
    
    % Initialize arrays for storing real and imaginary parts
    real_parts = zeros(1, MC_trial);
    imag_parts = zeros(1, MC_trial);
    
    for n_trial = 1:MC_trial
        H = 1;
        
        % Generate random message bits
        msgBit = randi([0 1], 1, bitpersym);
        
        % Convert message bits to symbol index
        msgSym = bi2de(msgBit, 'left-msb');
        
        % Modulation
        Sym = Sym_Mod8(msgSym, PSK_order);
        
        % AWGN channel
        sigma_n = sqrt(sigma_n2);
        y = Sym + sigma_n/sqrt(2) * (randn(1, 1) + ii*randn(1, 1));
        
        % Store real and imaginary parts
        real_parts(n_trial) = real(y);
        imag_parts(n_trial) = imag(y);
    end
    
    % Plot constellation points
    figure;
    scatter(real_parts, imag_parts, 'filled');
    xlim([-2, 2]);
    ylim([-2, 2]);
    title(['Constellation Plot for 8PSK at SNR = ', num2str(SNR(idx_P)), 'dB']);
    xlabel('Real Part');
    ylabel('Imaginary Part');
    grid on;
end

%%

clear;
close all;
clc;
ii = sqrt(-1);

MC_trial = 10000;
SNR = 0:2:10; % dBm
length_snr = length(SNR);

%%%%%%%%%%%%%%%%%%%%%%%%%
E_s = 1;
bitpersym = 3;
PSK_order = 8;

SER_analysis_near = zeros(1, length_snr);
SER_analysis_union = zeros(1, length_snr);
SER_analysis_exact = zeros(1, length_snr);
SER_simulation = zeros(1, length_snr);

for idx_P = 1:length_snr
    sigma_n2 = 10^(-SNR(idx_P)/10);
    
    gamma_bar_s = E_s/sigma_n2; % effective SNR
        
    % NNA (Near-Optimal Noncoherent Approximation)
    SER_analysis_near(idx_P) = 2 * (1 - 1 / sqrt(PSK_order)) * Q_fnc(sqrt(3 * gamma_bar_s / (PSK_order - 1)));
    
    % Union Upper Bound
    SER_analysis_union(idx_P) = 4 * (1 - 1 / sqrt(PSK_order)) * Q_fnc(sqrt(gamma_bar_s / (PSK_order - 1)));
    
    % Exact SER Calculation
    SER_analysis_exact(idx_P) = 1 - (1 - Q_fnc(sqrt(gamma_bar_s) * sin(pi/PSK_order))) / PSK_order;
    
    % Monte Carlo Simulation
    N_bit_err = 0;
    N_sym_err = 0;
    
    for n_trial = 1:MC_trial
        H = 1;
        
        % Generate random message bits
        msgBit = randi([0 1], 1, bitpersym);
        
        % Convert message bits to symbol index
        msgSym = bi2de(msgBit, 'left-msb');
        
        % Modulation
        Sym = Sym_Mod8(msgSym, PSK_order);
        
        % AWGN channel
        sigma_n = sqrt(sigma_n2);
        y = Sym + sigma_n/sqrt(2) * (randn(1, 1) + ii*randn(1, 1));
        
        % Receiver
        r = y; % for AWGN channel
        dec_idx = Sym_Demod8(r, PSK_order);
        msgBit_hat = de2bi(dec_idx, bitpersym, 'left-msb');
        
        % Count symbol and bit errors
        total_errors = sum(sum(xor(msgBit_hat, msgBit)));
        if total_errors ~= 0
            N_sym_err = N_sym_err + 1;
        end
        N_bit_err = N_bit_err + total_errors;
    end
    
    SER_simulation(idx_P) = N_sym_err/MC_trial;
end

semilogy(SNR, SER_analysis_exact, '-o', SNR, SER_analysis_near, '-s', SNR, SER_analysis_union, '-^', SNR, SER_simulation, 'x', 'LineWidth', 2)
xlabel('SNR (dB)')
ylabel('Symbol Error Rate (SER)')
title('SER Comparison for 8PSK')
legend('Exact SER', 'NNA Approximation', 'Union Upper Bound', 'Monte Carlo Simulation')
grid on;


function Q = Q_fnc(x)
    % Q function calculation
    Q = 0.5*erfc(x/sqrt(2));
end

