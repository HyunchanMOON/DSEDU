
function dec_idx = Sym_Demod8(r, M)
%
% 8PSK Symbol Demodulation
%

%%% Signal candidates generation
if (M == 8)
    Sa = [exp(1i*0) exp(1i*pi/4) exp(1i*pi/2) exp(1i*3*pi/4) exp(1i*pi) exp(1i*5*pi/4) exp(1i*3*pi/2) exp(1i*7*pi/4)];
else
    error('Unsupported modulation order');
end

%%% Symbol decision
diff = r - Sa;
[~, dec_idx] = min(abs(diff));

dec_idx = dec_idx - 1;

end