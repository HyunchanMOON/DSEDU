function [J, grad] = nnCostFunction(nn_params, input_layer_size, hidden_layer_size, num_labels, X, y, lambda)
    % Reshape nn_params back into the parameters Theta1 and Theta2
    Theta1 = reshape(nn_params(1:hidden_layer_size * (input_layer_size + 1)), hidden_layer_size, (input_layer_size + 1));
    Theta2 = reshape(nn_params((1 + (hidden_layer_size * (input_layer_size + 1))):end), num_labels, (hidden_layer_size + 1));

    m = size(X, 1);

    % Feedforward Propagation
    a1 = [ones(m, 1) X];
    z2 = a1 * Theta1';
    a2 = sigmoid(z2);
    a2 = [ones(size(a2, 1), 1) a2];
    z3 = a2 * Theta2';
    hx = sigmoid(z3);

    % Recode labels for training
    old_y = y;
    y = zeros(size(old_y, 1), size(Theta2, 1));
    y(sub2ind(size(y), 1:size(old_y, 1), old_y')) = 1;

    % Compute cost (unregularized)
    J = (-1/m) * sum(sum(y .* log(hx) + (1 - y) .* log(1 - hx), 2));

    % Regularization term
    reg_term = (lambda / (2 * m)) * (sum(sum(Theta1(:, 2:end).^2)) + sum(sum(Theta2(:, 2:end).^2)));

    % Regularized cost function
    J = J + reg_term;

    % Part 2: Backpropagation
    delta3 = hx - y;
    delta2 = (delta3 * Theta2(:, 2:end)) .* sigmoidGradient(z2);

    Delta1 = delta2' * a1;
    Delta2 = delta3' * a2;

    % Regularization term for gradient
    reg_term_grad1 = (lambda / m) * [zeros(size(Theta1, 1), 1) Theta1(:, 2:end)];
    reg_term_grad2 = (lambda / m) * [zeros(size(Theta2, 1), 1) Theta2(:, 2:end)];

    % Gradient
    Theta1_grad = (1/m) * Delta1 + reg_term_grad1;
    Theta2_grad = (1/m) * Delta2 + reg_term_grad2;

    % Unroll gradients
    grad = [Theta1_grad(:) ; Theta2_grad(:)];
end
