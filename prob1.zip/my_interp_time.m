function output = my_interp_time(input_datetime)

output = input_datetime;
for i = 2:numel(input_datetime)-1
    if isnat(input_datetime(i))
        output(i) = mean([input_datetime(i-1), input_datetime(i+1)]);
    end
end
end

