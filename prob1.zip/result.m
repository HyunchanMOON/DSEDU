clear;
clc;
close all;

fid = fopen('project_data.csv');
data = textscan(fid, '%q %f %f', 'Delimiter', ',', 'HeaderLines', 1);
fclose(fid);

date = data(:, 1);
date = date{1};

date = datetime(date);

date = my_interp_time(date);


load = cell2mat(data(:, 2));
power_gen = cell2mat(data(:, 3));

length(find(isnat(date)))
length(find(isnan(load)))
length(find(isnan(power_gen)))

load_total = my_interp(load);
res_out = my_interp(power_gen);

length(find(isnan(load_total)))
length(find(isnan(res_out)))

subplot(2, 1, 1)
plot(date, load_total)
xlabel('min')
ylabel('MW')
xtickformat("mm:ss")
subplot(2,1,2)
plot(date, res_out)

xlabel('min')
ylabel('MW')
xtickformat("mm:ss")



%%
net_load = load_total - res_out;
months = month(date);
is_summer = months >= 4 & months <= 10;  % 4월부터 10월까지를 하계로 설정
is_winter = ~is_summer;  % 하계를 제외한 나머지를 동계로 설정

% 동계와 하계 데이터 분리
winter_load_data = net_load(is_winter);
summer_load_data = net_load(is_summer);

winter_hour_load = mean(reshape(winter_load_data, 12, []))';
winter_date = date(is_winter);
winter_date = winter_date(1:12:length(winter_load_data));

summer_hour_load = mean(reshape(summer_load_data, 12, []))';
summer_date = date(is_summer);
summer_date = summer_date(1:12:length(summer_load_data));

% 그래프 그리기
figure

% 동계
subplot(2, 1, 1)

plot(winter_date, winter_hour_load)
xlabel('시간(hour)')
ylabel('평균 순부하(MW)')

%xticks(winter_date)
xtickangle(45)
xtickformat("HH:mm:ss")
title('동계')
% 하계
subplot(2, 1, 2)

plot(summer_date, summer_hour_load)
xlabel('시간(hour)')
ylabel('평균 순부하(MW)')
title('하계')
%xticks(summer_date)
xtickformat("HH:mm:ss")
xtickangle(45)
% 그래프 간격 조정
sgtitle('2021년 시간대별 평균 순부하')