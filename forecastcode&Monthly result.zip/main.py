import os
import warnings
from models.modeling import *
from multiprocessing import Pool
from utils.file_interface import read_json_file
from utils.data_preprocess import Input_preprocessor
from config import set_config

global args

warnings.filterwarnings("ignore")
config_dir = os.path.join(os.path.abspath('config/'), 'config.json')

def get_config(file_path):
    config_info = read_json_file(file_path=file_path)
    return config_info

def excel_parser(cfg):
    global args

    learner = {'ml': Execute_ml, 'nn': Execute_nn}
    parser = Input_preprocessor(config_info=cfg)
    parser.get_sales_data(parser.df_type, args.model_type)
    p = Pool(processes=parser.cores)
    learner[args.model_type](args=args).parallel_runner(p=p, instance=parser)


def main():
    global args
    parser = set_config()
    args = parser.parse_args()
    cfg = get_config(file_path=args.cfg_path)
    excel_parser(cfg=cfg)

if __name__ == "__main__":
    main()