import json


def read_json_file(file_path):
    with open(file_path, 'r', encoding='UTF-8') as f:
        json_object = json.load(f)

    return json_object




