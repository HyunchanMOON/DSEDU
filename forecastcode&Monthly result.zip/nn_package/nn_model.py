import torch
import torch.nn as nn


class LSTM(nn.Module):
    def __init__(self, input_size, hidden_dim, layers, n_out):
        super().__init__()
        self.hidden_dim = hidden_dim
        self.layers = layers
        self.n_out = n_out

        self.hn = torch.zeros(self.layers, 1, hidden_dim)
        self.cn = torch.zeros(self.layers, 1, hidden_dim)

        self.lstm = nn.LSTM(input_size=input_size, hidden_size=self.hidden_dim, num_layers=self.layers,
                            batch_first=True)  # LSTM layer

        self.fc = nn.Linear(self.hidden_dim, self.n_out)

    def forward(self, x, hn, cn):
        X = x.reshape(1, x.shape[0], x.shape[1])
        out_longer, (hn, cn) = self.lstm(X, (hn.detach(), cn.detach()))
        out = out_longer.view(x.shape[0], x.shape[1], out_longer.shape[2])
        out = self.fc(out[:, -1, :])
        return out.unsqueeze(-1), (hn, cn)