import torch
import numpy as np

from torch.utils import data

class EarlyStopping:
    """주어진 patience 이후로 validation loss가 개선되지 않으면 학습을 조기 중지"""

    def __init__(self, patience=7, verbose=False, delta=0, path='checkpoint.pt'):
        """
        Args:
            patience (int): validation loss가 개선된 후 기다리는 기간
                            Default: 7
            verbose (bool): True일 경우 각 validation loss의 개선 사항 메세지 출력
                            Default: False
            delta (float): 개선되었다고 인정되는 monitered quantity의 최소 변화
                            Default: 0
            path (str): checkpoint저장 경로
                            Default: 'checkpoint.pt'
        """

        self.patience = patience
        self.verbose = verbose
        self.counter = 0
        self.best_score = None
        self.early_stop = False
        self.val_loss_min = np.Inf
        self.delta = delta
        self.path = path

    def __call__(self, val_loss, model):
        score = -val_loss

        if self.best_score is None:
            self.best_score = score
            self.best_model = model
            self.save_checkpoint(val_loss, model)
        elif score < self.best_score + self.delta:
            self.counter += 1
            print(f'EarlyStopping counter: {self.counter} out of {self.patience}')
            if self.counter >= self.patience:
                self.early_stop = True
            self.best_score = score
            return self.best_model
        else:
            print(f'Validation loss decreased ({-self.best_score:.6f} --> {val_loss:.6f}).')
            self.best_score = score
            self.best_model = model
            # self.save_checkpoint(val_loss, model)
            self.counter = 0
            return self.best_model

    def save_checkpoint(self, val_loss, model):
        '''validation loss가 감소하면 모델을 저장한다.'''
        if self.verbose:
            print(f'Validation loss decreased ({self.val_loss_min:.6f} --> {val_loss:.6f}).')
        # torch.save(model.state_dict(), self.path)
        self.val_loss_min = val_loss


# torch data loader 에 넣어주기 위한 Dataset

class My_Dataset(data.Dataset):
    def __init__(self, data, labels):
        super().__init__()
        self.data = data
        self.labels = labels

    def __len__(self):
        return len(self.data)

    def __getitem__(self, idx):
        return self.data[idx], self.labels[idx]


class Model_Learner():

    def __init__(self, DEVICE, type='lstm'):
        self.DEVICE = DEVICE
        self.type = type
        self.train_dict = {'dnn': self.dnn_train, 'lstm': self.lstm_train}  # 각 model type에 따라 train 함수를 다르게 호출한다.
        self.eval_dict = {'dnn': self.dnn_evaluate, 'lstm': self.lstm_evaluate}  # 각 model type에 따라 evaluate 함수를 다르게 호출한다.
        self.loss_dict = {'dnn': torch.nn.L1Loss, 'lstm': torch.nn.MSELoss}  # 각 model type에 따라 loss 함수를 다르게 호출한다.

    # 모델 별로 학습을 하기 위한 함수
    def nn_learning(self, nn_model, ls_dict, data_dict):

        optimizer = torch.optim.Adam(nn_model.parameters(), lr=ls_dict['learning_rate'])

        self.train_loader = torch.utils.data.DataLoader(dataset=My_Dataset(data_dict['train_x'], data_dict['train_y']),
                                                        # 시계열 데이터 이므로 shuffle 도 하지 않고, batch로 나누어지지 않는 값 또한 drop 하지 않는다.
                                                        batch_size=ls_dict['BATCH_SIZE'], shuffle=False,
                                                        drop_last=False)

        self.test_loader = torch.utils.data.DataLoader(dataset=My_Dataset(data_dict['test_x'], data_dict['test_y']),
                                                       # 시계열 데이터 이므로 shuffle 도 하지 않고, batch로 나누어지지 않는 값 또한 drop 하지 않는다.
                                                       batch_size=ls_dict['BATCH_SIZE'], shuffle=False, drop_last=False)

        criterion = self.loss_dict[self.type]().to(self.DEVICE)

        patience = ls_dict['patience']

        self.avg_train_losses = []
        self.avg_valid_losses = []

        early_stopping = EarlyStopping(patience=patience, verbose=True)
        best_model = None

        for epoch in range(1, ls_dict['EPOCHS'] + 1):
            train_loss = self.train_dict[self.type](nn_model, self.train_loader, optimizer, criterion)
            test_loss = self.eval_dict[self.type](nn_model, self.test_loader, criterion)

            self.avg_train_losses.append(train_loss)
            self.avg_valid_losses.append(test_loss)

            if epoch % 10 == 0:
                print('epoch:{} train_loss:{:.4f}'.format(epoch, train_loss))
                print('validation_loss:{:.4f}'.format(test_loss))
                best_model = early_stopping(test_loss, nn_model)
                if early_stopping.early_stop:
                    print("Early stopping")
                    break

        if best_model is None: best_model = nn_model

        best_model.eval()

        return best_model

    def dnn_train(self, model, train_loader, optimizer, criterion):
        try:
            model.train()
            train_loss = 0

            for batch_idx, (data, target) in enumerate(train_loader):
                data, target = data.to(self.DEVICE), target.type(torch.float32).to(self.DEVICE)
                optimizer.zero_grad()
                hypothesis = model(data.type(torch.float32)).squeeze()
                loss = criterion(hypothesis, target)
                train_loss += loss
                loss.backward()
                optimizer.step()
            train_loss /= len(train_loader.dataset)
            return train_loss

        except Exception as e:
            print('train:', e)

    def lstm_train(self, model, train_loader, optimizer, criterion):
        try:
            model.train()
            train_loss = 0
            hn = model.hn
            cn = model.cn

            for batch_idx, (data, target) in enumerate(train_loader):
                data = data.reshape(data.shape[0], 1, data.shape[1])

                data, target = data.to(self.DEVICE), target.type(torch.float32).to(self.DEVICE)
                hypothesis, (hn, cn) = model(data.type(torch.float32), hn, cn)

                loss = criterion(hypothesis, target)

                optimizer.zero_grad()
                train_loss += loss
                loss.backward()
                optimizer.step()
            train_loss /= len(train_loader.dataset)
            return train_loss

        except Exception as e:
            print('train:', e)

    def dnn_evaluate(self, model, test_loader, criterion):
        try:
            model.eval()
            test_loss = 0

            with torch.no_grad():
                for data, target in test_loader:
                    data, target = data.to(self.DEVICE), target.type(torch.float32).to(self.DEVICE)

                    hypothesis = model(data.type(torch.float32)).squeeze()
                    test_loss += criterion(hypothesis, target)

            test_loss /= len(test_loader.dataset)

            return test_loss
        except Exception as e:
            print('evaluate', e)

    def lstm_evaluate(self, model, test_loader, criterion):
        try:
            model.eval()
            test_loss = 0

            hn = model.hn
            cn = model.cn
            with torch.no_grad():
                for data, target in test_loader:
                    data, target = data.to(self.DEVICE), target.type(torch.float32).to(self.DEVICE)

                    hypothesis, (hn, cn) = model(data.type(torch.float32), hn, cn)
                    test_loss += criterion(hypothesis, target)

            test_loss /= len(test_loader.dataset)

            return test_loss
        except Exception as e:
            print('evaluate', e)