clear;
clc;
close all;
% 주파수 전달함수의 매개변수 정의
wn = 1;                     % 자연진동수
zeta_values = [0.1, 0.2, 0.3, 0.5, 0.707]; % 감쇠비 값들

% figure 생성
figure;

% 게인곡선 subplot
subplot(1, 1, 1);
hold on;
for i = 1:length(zeta_values)
    % 감쇠비 값에 따른 전달함수 계수 정의
    zeta = zeta_values(i);
    num = [wn^2];                         % 분자 계수
    den = [1, 2*zeta*wn, wn^2];           % 분모 계수
    sys = tf(num, den);                   % 전달함수 생성
    
    % 게인곡선 그리기
    bode(sys);
    hold on;
end
hold off;
grid;
title('Bode Plot');
legend('zeta = 0.1', 'zeta = 0.2', 'zeta = 0.3', 'zeta = 0.5', 'zeta = 0.707');
hold off;



%%
clear;
clc;
close all;

% 주파수 전달함수의 매개변수 정의
wn = 1;                     % 자연진동수
zeta_values = [0.1, 0.2, 0.3, 0.5, 0.707]; % 감쇠비 값들

% 주파수 범위 정의
w = logspace(-2, 2, 1000); % 로그 스케일로 주파수 범위 생성

% figure 생성
figure;

% 게인곡선과 위상곡선 그리기
for i = 1:length(zeta_values)
    % 감쇠비 값에 따른 전달함수 계수 정의
    zeta = zeta_values(i);
    num = [wn^2];                         % 분자 계수
    den = [1, 2*zeta*wn, wn^2];           % 분모 계수
    
    % 주파수 응답 계산
    H = freqs(num, den, w);
    gain = 20*log10(abs(H));    % 게인곡선 계산
    phase = angle(H);           % 위상곡선 계산
    
    % 게인곡선 그리기
    subplot(2, 1, 1);
    semilogx(w, gain);
    hold on;
    
    % 위상곡선 그리기
    subplot(2, 1, 2);
    semilogx(w, rad2deg(phase));
    hold on;
end
hold off;

% 그래프 설정
subplot(2, 1, 1);
grid on;
title('Gain');
ylabel('Gain (dB)');
legend('zeta = 0.1', 'zeta = 0.2', 'zeta = 0.3', 'zeta = 0.5', 'zeta = 0.707');

subplot(2, 1, 2);
grid on;
title('Phase');
xlabel('Frequency (rad/s)');
ylabel('Phase (degrees)');
legend('zeta = 0.1', 'zeta = 0.2', 'zeta = 0.3', 'zeta = 0.5', 'zeta = 0.707');
